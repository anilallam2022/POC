﻿using NLog;
using NLog.Config;
using System;

namespace HeliumEdge.Logging
{
    public static class AsyncLogger 
    {
        private static readonly Logger _logger;
        private const string _DEFAULTLOGGER = "HeliumEdgeLogger";
        static readonly LoggingConfiguration config = new LoggingConfiguration();
        static AsyncLogger()
        {
            try
            {
                _logger = LogManager.GetLogger(_DEFAULTLOGGER) ?? LogManager.GetCurrentClassLogger();

                //FileTarget fileTarget = new FileTarget("file");
                //var wrapper = new AsyncTargetWrapper(fileTarget, 5000, AsyncTargetWrapperOverflowAction.Discard);
                //fileTarget.FileName = @"C:\Projects\HeliumEdge\NLog\Test.log";
                //fileTarget.Layout = "${message}";

                //DatabaseTarget db = new DatabaseTarget("database");
                //db.ConnectionString = "Server=tcp:heldev.database.windows.net,1433;Initial Catalog=HeliumEdgeDev;Persist Security Info=False;User ID=Heldev;Password=Helium01;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";
                //db.CommandText = @"INSERT INTO [dbo].[ApplicationLog] 
                //([Logged],[Level],[Message],[Logger],[Exception])
                //VALUES (@logged,@level,@message,@logger,@exception);";

                //db.Parameters.Add(new DatabaseParameterInfo("@logged", "${date}"));
                //db.Parameters.Add(new DatabaseParameterInfo("@level", "${level}"));
                //db.Parameters.Add(new DatabaseParameterInfo("@message", "${message}"));
                //db.Parameters.Add(new DatabaseParameterInfo("@logger", "${logger}"));
                //db.Parameters.Add(new DatabaseParameterInfo("@exception", "${exception:tostring}"));

                //LoggingRule rule = new LoggingRule("*", LogLevel.Debug, db);
                //config.LoggingRules.Add(rule);

                //LogManager.Configuration = config;
                //LogManager.Configuration.AddTarget(db);
                //LogManager.Configuration.LoggingRules.Add(rule);

            }
            catch (Exception ex)
            {
                return;
            }
        }

        #region Public Methods

        /// <summary>
        /// This method writes the Debug information to trace file
        /// </summary>
        /// <param name="message"></param>

        public static void Debug(String message)
        {
            //if (!_logger.IsDebugEnabled) return;
            _logger.Debug(message);
        }

        /// <summary>
        /// This method writes the Information to trace file
        /// </summary>
        /// <param name="message"></param>

        public static void Info(String message)
        {
            // if (!_logger.IsInfoEnabled) return;
            _logger.Info(message);
        }

        /// <summary>
        /// This method writes the Warning information to trace file
        /// </summary>
        /// <param name="message"></param>

        public static void Warn(String message)
        {
            //if (!_logger.IsWarnEnabled) return;
            _logger.Warn(message);
        }

        /// <summary>
        /// This method writes the Error Information to trace file
        /// </summary>
        /// <param name="error"></param>
        /// <param name="exception"></param>
        public static void Error(String message, Exception exception = null)
        {
            //if (!_logger.IsErrorEnabled) return;
            _logger.Error(exception, message);
        }

        /// <summary>
        /// This method writes the Fatal exception information to trace target
        /// </summary>
        /// <param name="message"></param>

        public static void Fatal(String message)
        {
            //if (!_logger.IsFatalEnabled) return;
            _logger.Warn(message);
        }

        /// <summary>
        /// This method writes the trace information to trace target
        /// </summary>
        /// <param name="message"></param>

        public static void Trace(String message)
        {
            //if (!_logger.IsTraceEnabled) return;
            _logger.Trace(message);
        }
        public static void Log(string message, Exception ex = null)
        {
            _logger.Error(ex, message);
        }

        #endregion
    }
}
