﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;

namespace HeliumEdge.Logging
{
    public class NLogAsyncLoggerFactory : IAsyncLoggerFactory
    {
        private readonly ILoggerFactory loggerFactory;
        private readonly IDictionary<Type, object> loggers = new Dictionary<Type, object>();

        public NLogAsyncLoggerFactory(ILoggerFactory loggerFactory)
        {
            this.loggerFactory = loggerFactory;
        }

        public IAsyncLogger<T> GetLogger<T>() where T : class
        {
            if (!loggers.ContainsKey(typeof(T)))
            {
                loggers.Add(typeof(T), new NLogAsyncLogger<T>(loggerFactory.CreateLogger<T>()));
            }
            return (IAsyncLogger<T>)loggers[typeof(T)];
        }
    }
}
