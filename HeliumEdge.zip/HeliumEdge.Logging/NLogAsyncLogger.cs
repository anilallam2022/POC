﻿using Microsoft.Extensions.Logging;
using System;

namespace HeliumEdge.Logging
{
    public class NLogAsyncLogger<T> : IAsyncLogger<T> where T : class
    {
        private readonly ILogger<T> logger;

        public NLogAsyncLogger(ILogger<T> logger)
        {
            this.logger = logger;
        }

        public void Debug(string message, params object[] args)
        {
            logger.LogDebug(message, args);
        }

        public void Info(string message, params object[] args)
        {
            logger.LogInformation(message, args);
        }

        public void Warn(string message, params object[] args)
        {
            logger.LogWarning(message);
        }

        public void Error(string message, Exception exception = null, params object[] args)
        {
            logger.LogError(exception, message, args);
        }

        public void Fatal(string message, Exception exception = null, params object[] args)
        {
            logger.LogCritical(exception, message, args);
        }
    }
}
