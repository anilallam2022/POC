﻿using System;

namespace HeliumEdge.Logging
{
    public interface IAsyncLogger<T> where T: class
    {
        void Debug(String message, params object[] args);
        void Info(String message, params object[] args);
        void Warn(String message, params object[] args);
        void Error(String message, Exception exception = null, params object[] args);
        void Fatal(String message, Exception exception = null, params object[] args);
    }
}
