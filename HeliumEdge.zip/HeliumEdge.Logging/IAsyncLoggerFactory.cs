﻿namespace HeliumEdge.Logging
{
    public interface IAsyncLoggerFactory
    {
        IAsyncLogger<T> GetLogger<T>() where T : class;
    }
}
