﻿using Dapper;
using DapperExtensions;
using HeliumEdge.DataObjects.ATS;
using HeliumEdge.DataObjects.ATS.ViewModels;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace HeliumEdge.DataAccess.ATS
{
    public class ContactRepository : BaseRepository
    {     
        private readonly IDbContext dbContext;
        public ContactRepository(IDbContext dbContext): base(dbContext)
        {
            this.dbContext = dbContext;
        }
        
        public async Task<dynamic> GetContactList()
        {
            try
            {
                using (var db = dbContext.Connection)
                {
                    return (await db.QueryAsync<dynamic>("select Id [key], (FirstName + ' ' + LastName) [text] from Contact").ConfigureAwait(false))?.ToList();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public async Task<Contact> GetAsync(int id)
        {
            using (var db = dbContext.Connection)
            {
                var contact = await db.GetAsync<Contact>(id).ConfigureAwait(false);
                if (contact == null)
                    return null;
                await PopulateContactDetailsAsync(contact).ConfigureAwait(false);
                return contact;
            }
        }

        public async Task<IEnumerable<Contact>> GetAllByNameAsync(string name)
        {
            IEnumerable<Contact> contacts = null;
            using (var db = dbContext.Connection)
            {
                PredicateGroup namePredicateGroup = new PredicateGroup()
                {
                    Predicates = new List<IPredicate>()
                    {
                        Predicates.Field<Contact>(contact=>contact.FirstName,Operator.Like, $"%{name}%"),
                        Predicates.Field<Contact>(contact=>contact.MiddleName,Operator.Like,$"%{name}%"),
                        Predicates.Field<Contact>(contact=>contact.LastName,Operator.Like,$"%{name}%")
                    },
                    Operator = GroupOperator.Or
                };

                contacts = await db.GetListAsync<Contact>(namePredicateGroup).ConfigureAwait(false);
            }

            return contacts;
        }

        private async Task PopulateContactDetailsAsync(Contact contact)
        {
            using (var db = dbContext.Connection)
            {
                //Get contact details
                var predicateForContactDetails = Predicates.Field<ContactDetails>(model => model.ContactId, Operator.Eq, contact.Id);
                contact.ContactDetails = (await db.GetListAsync<ContactDetails>(predicateForContactDetails).ConfigureAwait(false))?.ToList();

                var predicateForContactPhoto = Predicates.Field<Attachment>(model => model.ReferencedEntityName, Operator.Eq, "Contact");
                var predicateAddressGroup = new PredicateGroup()
                {
                    Predicates = new List<IPredicate>() {
                        Predicates.Field<Attachment>(model => model.ReferencedEntityName, Operator.Eq, "Contact"),
                        Predicates.Field<Attachment>(model => model.ReferencedEntityId, Operator.Eq, contact.Id)
                    },
                    Operator = GroupOperator.And
                };
                contact.Photo = (await db.GetListAsync<Attachment>(predicateAddressGroup).ConfigureAwait(false))?.FirstOrDefault();
                var predicateForContactCompanyDetails = Predicates.Field<CompanyContact>(model => model.ContactId, Operator.Eq, contact.Id);
                contact.CompanyContact = (await db.GetListAsync<CompanyContact>(predicateForContactCompanyDetails).ConfigureAwait(false))?.FirstOrDefault();
            }
        }

        public async Task<dynamic> SearchUnassigned(string text)
        {
            try
            {                
                using (IDbConnection db = dbContext.Connection)
                {
                    return await db.QueryAsync(@"select Id, FirstName+' '+LastName [Name] from Contact c
                                                where c.isdeleted=0 and c.TypeId is null and c.id not in (select contactId from companycontact) 
                                                and (Firstname like @searchText or lastname like @searchText or middlename like @searchText)", param: new { searchText = $"%{text}%" });
                }
            }
            catch (Exception ex)
            {
                //TODO
            }
            return null;
        }

        public async Task<bool> ChangeStatusAsync(EntitiesStatus model)
        {
            try
            {                
                using (IDbConnection db = dbContext.Connection)
                {
                    return (await db.ExecuteAsync(@"update Contact set statusId=@NewStatusId where TypeId is null and id in @EntityIds", model)) > 0;
                }
            }
            catch (Exception ex)
            {
                //TODO
            }
            return false;
        }

        public async Task<dynamic> Search(string text)
        {
            try
            {
                using (IDbConnection db = dbContext.Connection)
                {
                    return await db.QueryAsync(@"select Id, FirstName+' '+LastName [Name] from Contact where isDeleted=0 and (Firstname like @searchText or lastname like @searchText or middlename like @searchText)", param: new { searchText = $"%{text}%" });
                }
            }
            catch (Exception ex)
            {
                //TODO
            }
            return null;
        }

        public async Task<ContactView> GetViewById(int id)
        {
            using (IDbConnection db = dbContext.Connection)
            {
                return await db.GetAsync<ContactView>(id).ConfigureAwait(false);
            }
        }

        public async Task<bool> CreateAsync(Contact model)
        {
            IDbTransaction transaction = null; 
            try
            {
                using (var db = dbContext.Connection)
                {
                    db.Open();
                    using (transaction = db.BeginTransaction())
                    {
                        model.Id = await db.InsertAsync(model, transaction).ConfigureAwait(false);
                        foreach(var detail in model.ContactDetails)
                        {
                            detail.ContactId = model.Id;
                            detail.Id = await db.InsertAsync(detail, transaction).ConfigureAwait(false);
                        }
                        if (model.CompanyContact!=null)
                        {
                            model.CompanyContact.ContactId = model.Id;
                            model.CompanyContact.Id = await db.InsertAsync(model.CompanyContact, transaction).ConfigureAwait(false);
                        }
                        if (model.Photo != null)
                        {
                            model.Photo.ReferencedEntityId = model.Id;
                            model.Photo.Id = await db.InsertAsync(model.Photo, transaction).ConfigureAwait(false);
                        }
                        transaction.Commit();
                    }
                    return true;
                }
            }
            catch (System.Exception e)
            {
                transaction?.Rollback(); //DO WE REALLY NEED THIS?
                return false;
            }
        }
        

        public async Task<bool> DeleteAsync(List<int> Ids)
        {
            IDbTransaction transaction = null;
            try
            {
                using (IDbConnection db = dbContext.Connection)
                {
                    db.Open();
                    var predicateGroup = new PredicateGroup { Operator = GroupOperator.Or, Predicates = new List<IPredicate>() };
                    Ids.ForEach(j => predicateGroup.Predicates.Add(Predicates.Field<Contact>(f => f.Id, Operator.Eq, j)));
                    bool isDeleted = false;
                    using (transaction = db.BeginTransaction())
                    {
                        var lisCon = (await db.GetListAsync<Contact>(predicateGroup, null, transaction).ConfigureAwait(false)).ToList();
                        foreach (var item in lisCon)
                        {
                            item.IsDeleted = true;
                            isDeleted |= await db.UpdateAsync<Contact>(item, transaction).ConfigureAwait(false); //returns atleast one is true then true. else false
                        }
                        transaction.Commit();
                    }
                    return isDeleted;
                }
            }
            catch (Exception ex)
            {
                transaction.Rollback();

                //TODO
            }
            return false;
        }

        public async Task<dynamic> SearchByCompanyId(int companyId, string text)
        {
            try
            {
                using (IDbConnection db = dbContext.Connection)
                {
                    return await db.QueryAsync(@"select a.Id, a.FirstName+' '+a.LastName [Name] from  Contact a inner join CompanyContact b on a.Id = b.ContactId and a.isdeleted=0
                                                            Inner Join Company c on c.isdeleted=0 and c.Id = b.CompanyId and c.Id = " + companyId.ToString() + " where c.isDeleted=0 and (a.Firstname like @searchText or a.lastname like @searchText or a.middlename like @searchText)", param: new { searchText = $"%{text}%" });
                }
            }
            catch (Exception ex)
            {
                //TODO
            }
            return null;
        }


    }
}
