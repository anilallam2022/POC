﻿using Dapper;
using DapperExtensions;
using HeliumEdge.DataObjects.ATS;
using HeliumEdge.DataObjects.ATS.ViewModels;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Dynamic;
using System.Linq;
using System.Threading.Tasks;

namespace HeliumEdge.DataAccess.ATS
{
    public class CandidateRepository : BaseRepository
    {
        private readonly IDbContext dbContext;
        public CandidateRepository(IDbContext dbContext) : base(dbContext)
        {
            this.dbContext = dbContext;
        }

        public async Task<dynamic> GetViewListItems()
        {
            try
            {
                using (IDbConnection db = dbContext.Connection)
                {
                    // TODO to get the logged-in user ID
                    return (await db.GetListAsync<ListPageUserColumn>().ConfigureAwait(false)).Where(x => x.UserId == 1 && x.Entity == "Candidate").Select(s => new { key = s.Id, value = s.ListName }).ToList();
                }
            }
            catch (Exception ex)
            {
                //TODO
            }
            return null;
        }

        public async Task<bool> ChangeStatusAsync(EntitiesStatus model)
        {
            try
            {
                using (IDbConnection db = dbContext.Connection)
                {
                    return (await db.ExecuteAsync(@"update contact set StatusId=@NewStatusId where id in (select ContactId from Candidate where id in @EntityIds)", model)) > 0;
                }
            }
            catch (Exception ex)
            {
                //TODO
            }
            return false;
        }

        public async Task<dynamic> Search(string text)
        {
            try
            {                
                using (IDbConnection db = dbContext.Connection)
                {
                    return await db.QueryAsync(@"select a.Id, FirstName+' '+LastName [Name] from Candidate a
                                                inner join Contact b on b.Id = a.ContactId where a.isDeleted=0 and (Firstname like @searchText or lastname like @searchText or middlename like @searchText)", param: new { searchText = $"%{text}%" });
                }
            }
            catch (Exception ex)
            {
                //TODO
            }
            return null;
        }

        public async Task<CandidateView> GetViewById(int id)
        {
            using (IDbConnection db = dbContext.Connection)
            {
                return await db.GetAsync<CandidateView>(id).ConfigureAwait(false);
            }
        }

        public async Task<CandidateModel> GetAsync(int id)
        {
            CandidateModel model = null;
            try
            {
                using (IDbConnection db = dbContext.Connection)
                {
                    var candidate = await db.GetAsync<Candidate>(id).ConfigureAwait(false);

                    if (candidate != null)
                    {
                        model = new CandidateModel { Candidate = candidate };
                        Contact contact = await db.GetAsync<Contact>(candidate.ContactId).ConfigureAwait(false);
                        model.Contact = contact;
                        
                        var predicate = Predicates.Field<CandidateCertificate>(f => f.CandidateId, Operator.Eq, candidate.Id);
                        IEnumerable<CandidateCertificate> certificates = await db.GetListAsync<CandidateCertificate>(predicate).ConfigureAwait(false);
                        model.CandidateCertificates = certificates?.ToList();

                        predicate = Predicates.Field<CandidateEducation>(f => f.CandidateId, Operator.Eq, candidate.Id);
                        IEnumerable<CandidateEducation> educations = await db.GetListAsync<CandidateEducation>(predicate).ConfigureAwait(false);
                        model.CandidateEducations = educations?.ToList();

                        predicate = Predicates.Field<CandidateExperience>(f => f.CandidateId, Operator.Eq, candidate.Id);
                        IEnumerable<CandidateExperience> experiences = await db.GetListAsync<CandidateExperience>(predicate).ConfigureAwait(false);
                        model.CandidateExperiences = experiences?.ToList();

                        predicate = Predicates.Field<CandidateSkill>(f => f.CandidateId, Operator.Eq, candidate.Id);
                        IEnumerable<CandidateSkill> skills = await db.GetListAsync<CandidateSkill>(predicate).ConfigureAwait(false);
                        model.CandidateSkills = skills?.ToList();

                        var predicateAttachmentsGroup = new PredicateGroup { Operator = GroupOperator.And, Predicates = new List<IPredicate>() };
                        predicateAttachmentsGroup.Predicates.Add(Predicates.Field<Attachment>(f => f.ReferencedEntityId, Operator.Eq, model.Candidate.Id));
                        predicateAttachmentsGroup.Predicates.Add(Predicates.Field<Attachment>(f => f.ReferencedEntityName, Operator.Eq, "Candidate"));
                        var resumeAttachments = await db.GetListAsync<Attachment>(predicateAttachmentsGroup).ConfigureAwait(false);
                        if (resumeAttachments != null && resumeAttachments.Any(a => a.Type.Equals("Resume")))
                        {
                            model.Candidate.Resume = resumeAttachments.First(a => a.Type.Equals("Resume"));
                        }
                        predicateAttachmentsGroup = new PredicateGroup { Operator = GroupOperator.And, Predicates = new List<IPredicate>() };
                        predicateAttachmentsGroup.Predicates.Add(Predicates.Field<Attachment>(f => f.ReferencedEntityId, Operator.Eq, model.Contact.Id));
                        predicateAttachmentsGroup.Predicates.Add(Predicates.Field<Attachment>(f => f.ReferencedEntityName, Operator.Eq, "Contact"));
                        var photosAttachments = await db.GetListAsync<Attachment>(predicateAttachmentsGroup).ConfigureAwait(false);
                        if (photosAttachments != null && photosAttachments.Any(a => a.Type.Equals("Photo")))
                        {
                            model.Contact.Photo = photosAttachments.First(a => a.Type.Equals("Photo"));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return model;
        }

        public async Task<bool> CreateAsync(CandidateModel model)
        {
            IDbTransaction transaction = null;

            try
            {
                using (IDbConnection db = dbContext.Connection)
                {
                    if (db.State != ConnectionState.Open)
                        db.Open();

                    using (transaction = db.BeginTransaction())
                    {
                        var contactId = await db.InsertAsync(model.Contact, transaction).ConfigureAwait(false);

                        model.Candidate.ContactId = contactId;
                        if (model.Contact.ContactDetails != null)
                        {
                            foreach (var data in model.Contact.ContactDetails)
                            {
                                data.ContactId = contactId;
                                await db.InsertAsync(data, transaction).ConfigureAwait(false);
                            }
                        }
                        var candidateId = await db.InsertAsync(model.Candidate, transaction).ConfigureAwait(false);

                        if (model.CandidateCertificates != null)
                        {
                            foreach (var data in model.CandidateCertificates)
                            {
                                data.CandidateId = candidateId;
                                await db.InsertAsync(data, transaction).ConfigureAwait(false);
                            }
                        }

                        if (model.CandidateEducations != null)
                        {
                            foreach (var data in model.CandidateEducations)
                            {
                                data.CandidateId = candidateId;
                                await db.InsertAsync(data, transaction).ConfigureAwait(false);
                            }
                        }

                        if (model.CandidateExperiences != null)
                        {
                            foreach (var data in model.CandidateExperiences)
                            {
                                data.CandidateId = candidateId;
                                await db.InsertAsync(data, transaction).ConfigureAwait(false);
                            }
                        }

                        if (model.CandidateSkills != null)
                        {
                            foreach (var data in model.CandidateSkills)
                            {
                                data.CandidateId = candidateId;
                                await db.InsertAsync(data, transaction).ConfigureAwait(false);
                            }
                        }

                        if (model.Contact.Photo != null)
                        {
                            model.Contact.Photo.ReferencedEntityId = model.Contact.Id;
                            await db.InsertAsync(model.Contact.Photo, transaction).ConfigureAwait(false);
                        }
                        if (model.Candidate.Resume != null)
                        {
                            model.Candidate.Resume.ReferencedEntityId = model.Candidate.Id;
                            await db.InsertAsync(model.Candidate.Resume, transaction).ConfigureAwait(false);
                        }

                        transaction.Commit();                        
                    }
                    return true;
                    
                }
            }
            catch (Exception e)
            {
                transaction?.Rollback();//DO WE REALLY NEED THIS?
                return false;
            }
            
        }


        public async Task<bool> DeleteAsync(List<int> Ids)
        {
            IDbTransaction transaction = null;
            try
            {
                using (IDbConnection db = dbContext.Connection)
                {
                    db.Open();
                    var predicateGroup = new PredicateGroup { Operator = GroupOperator.Or, Predicates = new List<IPredicate>() };
                    Ids.ForEach(j => predicateGroup.Predicates.Add(Predicates.Field<Candidate>(f => f.Id, Operator.Eq, j)));
                    bool isDeleted = false;
                    using (transaction = db.BeginTransaction())
                    {
                        var lisCan = (await db.GetListAsync<Candidate>(predicateGroup, null, transaction).ConfigureAwait(false)).ToList();
                        foreach (var item in lisCan)
                        {
                            item.IsDeleted = true;
                            isDeleted |= await db.UpdateAsync<Candidate>(item, transaction).ConfigureAwait(false); //returns atleast one is true then true. else false
                        }
                        transaction.Commit();
                    }
                    return isDeleted;
                }
            }
            catch (Exception ex)
            {
                transaction.Rollback();

                //TODO
            }
            return false;
        }



    }
}
