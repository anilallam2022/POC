﻿using Dapper;
using DapperExtensions;
using HeliumEdge.DataObjects.ATS;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace HeliumEdge.DataAccess.ATS
{
    public class NoteRepository : BaseRepository
    {
        private readonly IDbContext dbContext;
        public NoteRepository(IDbContext dbContext) : base(dbContext)
        {
            this.dbContext = dbContext;
        }

        public async Task<IEnumerable<Note>> GetAllAsync()
        {
            List<Note> lstModel = null;
            using (IDbConnection db = dbContext.Connection)
            {
                var noteIds = await db.QueryAsync<int>("select Id from Note").ConfigureAwait(false);
                if (noteIds?.Count() > 0)
                {
                    lstModel = new List<Note>();

                    foreach (var Id in noteIds)
                    {
                        var data = await GetAsync(Id).ConfigureAwait(false);
                        if (data != null)
                        {
                            lstModel.Add(data);
                        }
                    }
                }
            }
            return lstModel;
        }

        public async Task<Note> GetAsync(int id)
        {
            Note model = null;
            try
            {
                using (IDbConnection db = dbContext.Connection)
                {
                    var note= await db.GetAsync<Note>(id).ConfigureAwait(false);

                    if (note != null)
                    {
                        //model = new Note();
                        model = note;
                        var predicateGroup = new PredicateGroup { Operator = GroupOperator.And, Predicates = new List<IPredicate>() };
                        predicateGroup.Predicates.Add(Predicates.Field<TagView>(f => f.ReferenceEntityId, Operator.Eq, id));
                        predicateGroup.Predicates.Add(Predicates.Field<TagView>(f => f.ReferenceEntityName, Operator.Eq, "Note"));
                        model.Tags = (await db.GetListAsync<TagView>(predicateGroup).ConfigureAwait(false)).ToList<Tag>(); 
                    }
                }
            }
            catch (Exception ex)
            {
                //TODO
            }
            return model;
        }

        public async Task<bool> CreateAsync(Note model)
        {
            IDbTransaction transaction = null;
            try
            {
                using (IDbConnection db = dbContext.Connection)
                {
                    if (db.State != ConnectionState.Open)
                        db.Open();

                    using (transaction = db.BeginTransaction())
                    {
                        model.Id = await db.InsertAsync(model, transaction).ConfigureAwait(false);

                        if (model.Tags?.Count() > 0)
                        {
                            foreach (Tag tag in model.Tags)
                            {
                                tag.ReferenceEntityId = model.Id;
                                tag.Id = await db.InsertAsync(tag, transaction).ConfigureAwait(false);
                            }
                        }
                        if(model.Attachments?.Count()> 0)
                        {
                            foreach (var attachment in model.Attachments)
                            {
                                attachment.ReferencedEntityId = model.Id;
                                attachment.Id = await db.InsertAsync(attachment, transaction).ConfigureAwait(false);
                            }
                        }
                        transaction.Commit();
                    }
                    return true;
                }
            }
            catch (Exception e)
            {
                transaction?.Rollback();
                return false;
            }
        }
    }
}
