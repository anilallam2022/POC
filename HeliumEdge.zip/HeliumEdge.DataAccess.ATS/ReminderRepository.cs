﻿using DapperExtensions;
using HeliumEdge.DataObjects.ATS;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace HeliumEdge.DataAccess.ATS
{
    public class ReminderRepository : BaseRepository
    {
        private readonly IDbContext dbContext;
        public ReminderRepository(IDbContext dbContext) : base(dbContext)
        {
            this.dbContext = dbContext;
        }

        public async Task<List<ReminderModel>> GetAllAsync()
        {
            List<ReminderModel> lstModel = null;
            using (IDbConnection db = dbContext.Connection)
            {
                var result = await db.GetListAsync<Reminder>().ConfigureAwait(false);
                if (result?.Count() > 0)
                {
                    lstModel = new List<ReminderModel>();
                    foreach (var note in result)
                    {
                        var data = await GetAsync(note.Id).ConfigureAwait(false);
                        if (data != null)
                        {
                            lstModel.Add(data);
                        }
                    }
                }
            }
            return lstModel;
        }

        public async Task<ReminderModel> GetAsync(int id)
        {
            ReminderModel model = null;
            try
            {
                using (IDbConnection db = dbContext.Connection)
                {
                    var reminder = await db.GetAsync<Reminder>(id).ConfigureAwait(false);
                    if (reminder != null)
                    {
                        model = new ReminderModel { Reminder = reminder };
                        var predicateGroup = new PredicateGroup { Operator = GroupOperator.And, Predicates = new List<IPredicate>() };
                        predicateGroup.Predicates.Add(Predicates.Field<TagView>(f => f.ReferenceEntityId, Operator.Eq, id));
                        predicateGroup.Predicates.Add(Predicates.Field<TagView>(f => f.ReferenceEntityName, Operator.Eq, "Reminder"));
                        model.Tags = (await db.GetListAsync<TagView>(predicateGroup).ConfigureAwait(false)).ToList<Tag>();
                    }
                }
            }
            catch (Exception ex)
            {
                //TODO
            }
            return model;
        }

        public async Task<bool> CreateAsync(ReminderModel model)
        {
            IDbTransaction transaction = null;
            try
            {
                using (IDbConnection db = dbContext.Connection)
                {
                    if (db.State != ConnectionState.Open)
                        db.Open();

                    using (transaction = db.BeginTransaction())
                    {
                        model.Reminder.Id = await db.InsertAsync(model.Reminder, transaction).ConfigureAwait(false);

                        if (model.Tags?.Count() > 0)
                        {
                            foreach (Tag tag in model.Tags)
                            {
                                tag.ReferenceEntityId = model.Reminder.Id;
                                tag.Id = await db.InsertAsync(tag, transaction).ConfigureAwait(false);
                            }
                        }
                        transaction.Commit();
                    }
                    return true;

                }
            }
            catch (Exception e)
            {
                transaction?.Rollback(); // DO WE NEED THIS
                return false;
            }            
        }
    }
}
