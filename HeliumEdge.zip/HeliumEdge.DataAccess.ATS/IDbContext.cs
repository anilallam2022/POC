﻿using System.Data;

namespace HeliumEdge.DataAccess.ATS
{
    public interface IDbContext
    {
        IDbConnection Connection { get; }
    }
}
