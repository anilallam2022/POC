﻿using Dapper;
using DapperExtensions;
using HeliumEdge.DataObjects.ATS;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace HeliumEdge.DataAccess.ATS
{
    public class TaskRepository : BaseRepository
    {
        private readonly IDbContext dbContext;
        public TaskRepository(IDbContext dbContext) : base(dbContext)
        {
            this.dbContext = dbContext;
        }

        public async Task<IEnumerable<TaskModel>> GetAllAsync()
        {
            List<TaskModel> lstModel = null;
            using (IDbConnection db = dbContext.Connection)
            {
                var taskIds = await db.QueryAsync<int>("select Id from TaskEntity").ConfigureAwait(false);
                if (taskIds?.Count() > 0)
                {
                    lstModel = new List<TaskModel>();
                    foreach (var Id in taskIds)
                    {
                        var data = await GetAsync(Id).ConfigureAwait(false);
                        if (data != null)
                        {
                            lstModel.Add(data);
                        }
                    }
                }
            }
            return lstModel;
        }

        public async Task<TaskModel> GetAsync(int id)
        {
            TaskModel model = null;
            try
            {
                using (IDbConnection db = dbContext.Connection)
                {
                    var taskEntity = await db.GetAsync<TaskEntity>(id).ConfigureAwait(false);
                    if (taskEntity != null)
                    {
                        model = new TaskModel { TaskEntity = taskEntity };                        
                        var predicateGroup = new PredicateGroup { Operator = GroupOperator.And, Predicates = new List<IPredicate>() };
                        predicateGroup.Predicates.Add(Predicates.Field<TagView>(f => f.ReferenceEntityId, Operator.Eq, id));
                        predicateGroup.Predicates.Add(Predicates.Field<TagView>(f => f.ReferenceEntityName, Operator.Eq, "TaskEntity"));
                        model.Tags = (await db.GetListAsync<TagView>(predicateGroup).ConfigureAwait(false)).ToList<Tag>();
                    }

                    //await db.QueryAsync<TaskEntity, Tag, TaskModel>(
                    //     "select * from TaskEntity task left join Tag tag on task.id=tag.ReferenceEntityId where task.id=" + id,
                    //     (te, tag) =>
                    //     {
                    //         model.TaskEntity = te;
                    //         model.Tags.ToList().Add(tag);
                    //         return model;
                    //     }, splitOn: "Id");                    
                }
            }
            catch (Exception ex)
            {
               //TODO
            }
            return model;
        }

        public async Task<bool> CreateAsync(TaskModel model)
        {
            IDbTransaction transaction = null;
            try
            {
                using (IDbConnection db = dbContext.Connection)
                {
                    if (db.State != ConnectionState.Open)
                        db.Open();

                    using (transaction = db.BeginTransaction())
                    {
                        model.TaskEntity.Id = await db.InsertAsync(model.TaskEntity, transaction).ConfigureAwait(false);

                        if (model.Tags?.Count() > 0)
                        {
                            foreach (Tag tag in model.Tags)
                            {
                                tag.ReferenceEntityId = model.TaskEntity.Id;
                                tag.Id = await db.InsertAsync(tag, transaction).ConfigureAwait(false);
                            }
                        }
                        if((model.Attachments?.Count ?? 0) > 0)
                        {
                            foreach (var attachment in model.Attachments)
                            {
                                attachment.ReferencedEntityId = model.TaskEntity.Id;
                                attachment.Id = await db.InsertAsync(attachment, transaction).ConfigureAwait(false);
                            }
                        }
                        transaction.Commit();
                    }
                    return true;
                }
            }
            catch (Exception e)
            {
                transaction?.Rollback();
                throw;
            }            
        }
    }
}
