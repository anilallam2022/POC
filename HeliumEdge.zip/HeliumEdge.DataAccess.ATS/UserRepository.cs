﻿using Dapper;
using DapperExtensions;
using HeliumEdge.DataObjects.ATS;
using System;
using System.Data;
using System.Threading.Tasks;

namespace HeliumEdge.DataAccess.ATS
{
    public class UserRepository : BaseRepository
    {
        private readonly IDbContext dbContext;
        public UserRepository(IDbContext dbContext) : base(dbContext)
        {
            this.dbContext = dbContext;
        }

        public async Task<dynamic> Search(string text)
        {
            try
            {
                using (IDbConnection db = dbContext.Connection)
                {
                    return await db.QueryAsync(@"select u.Id, FirstName+' '+LastName [Name] from [User] u
                    where (FirstName like @searchText or LastName like @searchText or Email like @searchText)",
                    param: new { searchText = $"%{text}%" });
                }
            }
            catch (Exception ex)
            {
                //TODO
            }
            return null;
        }

        public async Task<int> CreateUserAsync(User model)
        {
            IDbTransaction transaction = null;            
            try
            {
                int id;
                using (IDbConnection db = dbContext.Connection)
                {
                    if (db.State != ConnectionState.Open)
                        db.Open();

                    using (transaction = db.BeginTransaction())
                    {
                        id = await db.InsertAsync(model, transaction).ConfigureAwait(false);
                        transaction.Commit();
                    }
                }
                return id;
            }
            catch (Exception e)
            {
                transaction?.Rollback();
                throw;
            }
        }
    }
}
