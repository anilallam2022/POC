﻿using System.Data;
using System.Data.SqlClient;

namespace HeliumEdge.DataAccess.ATS
{
    public class DbContext : IDbContext
    {
        private readonly string connectionString;
        public DbContext(string connectionString)
        {
            this.connectionString = connectionString;
        }

        public IDbConnection Connection
        {
            get
            {
                return new SqlConnection(connectionString);
            }
        }
    }
}
