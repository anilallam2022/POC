﻿using Dapper;
using DapperExtensions;
using HeliumEdge.DataObjects.ATS;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace HeliumEdge.DataAccess.ATS
{
    public class ListPageColumnRepository : BaseRepository
    {
        private readonly IDbContext dbContext;
        public ListPageColumnRepository(IDbContext dbContext) : base(dbContext)
        {
            this.dbContext = dbContext;
        }

        public async Task<IEnumerable<ListPageColumn>> GetColumnListByEntity(string entity)
        {
            using (IDbConnection db = dbContext.Connection)
            {
                var predicate = Predicates.Field<ListPageColumn>(f => f.Entity, Operator.Eq, entity);
                return (await db.GetListAsync<ListPageColumn>(predicate).ConfigureAwait(false));
            }
        }

        public async Task<IEnumerable<ListPageColumn>> GetUserColumnListByEntity(string entity, int userId)
        {
            using (IDbConnection db = dbContext.Connection)
            {
                string query = @"select a.Id,a.ColumnName, a.DisplayText from ListPageColumns a
                                    inner join ListPageUserColumns b on b.entity=@entity and b.UserId=@userId
                                    where a.id in(select value from string_split(b.ColumnIds,'|'))";
                return await db.QueryAsync<ListPageColumn>(query, new { entity, userId }).ConfigureAwait(false);
            }
        }
    }
}
