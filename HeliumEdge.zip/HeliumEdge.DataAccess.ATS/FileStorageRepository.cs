﻿using HeliumEdge.DataObjects.ATS;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using DapperExtensions;

namespace HeliumEdge.DataAccess.ATS
{
    public class FileStorageRepository : BaseRepository
    {
        private readonly IDbContext dbContext;

        public FileStorageRepository(IDbContext dbContext) : base(dbContext)
        {
            this.dbContext = dbContext;
        }

        public async Task<Attachment> GetAsync(int id)
        {
            Attachment attachment = null;
            try
            {
                using (IDbConnection db = dbContext.Connection)
                {
                    attachment = await db.GetAsync<Attachment>(id).ConfigureAwait(false);
                }
            }
            catch (Exception)
            {
                //TODO
            }

            return attachment;
        }
    }
}
