﻿using Dapper;
using DapperExtensions;
using HeliumEdge.DataObjects.ATS;
using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace HeliumEdge.DataAccess.ATS
{
    public class RoleRepository : BaseRepository
    {
        private readonly IDbContext dbContext;
        public RoleRepository(IDbContext dbContext) : base(dbContext)
        {
            this.dbContext = dbContext;
        }

        public async Task<Role> GetRole(int id)
        {
            try
            {
                using (IDbConnection db = dbContext.Connection)
                {
                    var predicate = Predicates.Field<Role>(f => f.Id, Operator.Eq, id);
                    IEnumerable<Role> result = await db.GetListAsync<Role>(predicate).ConfigureAwait(false);
                    if(result != null)
                    {
                        return result.AsList()[0];
                    }
                }
            }
            catch (Exception ex)
            {
                //TODO
            }
            return null;
        }

        public async Task<IEnumerable<Role>> GetRoles()
        {
            try
            {
                using (IDbConnection db = dbContext.Connection)
                {
                    return await db.GetListAsync<Role>().ConfigureAwait(false);
                }
            }
            catch (Exception ex)
            {
                //TODO
            }
            return null;
        }

    }
}
