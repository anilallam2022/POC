﻿using DapperExtensions;
using Dapper;
using HeliumEdge.DataObjects.ATS;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System;

namespace HeliumEdge.DataAccess.ATS
{
    public class MasterDataRepository : BaseRepository
    {
        private readonly IDbContext dbContext;
        public MasterDataRepository(IDbContext dbContext) : base(dbContext)
        {
            this.dbContext = dbContext;
        }

        public async Task<dynamic> GetLookUpItemsByModule(string moduleName)
        {
            using (IDbConnection db = dbContext.Connection)
            {
                var predicate = Predicates.Field<ApplicationLookup>(f => f.ModuleName, Operator.Eq, moduleName);
                var result = (await db.GetListAsync<ApplicationLookup>(predicate).ConfigureAwait(false))
                    .OrderBy(x => x.OrderId)
                    .GroupBy(x => x.Type)
                    .Select(g => new
                    {
                        Name = g.Key,
                        Bindings = g.Select(t => new { Key = t.Id, Text = t.Description, t.IsDefault })
                    });
                return result;
            }
        }

        public async Task<int> GetDefaultLookupIdAsync(string moduleName, string type)
        {
            using (IDbConnection db = dbContext.Connection)
            {
                try
                {
                    var defaultId = await db.ExecuteScalarAsync<int>($"select Id from ApplicationLookup where ModuleName='{moduleName}' and Type='{type}' and IsActive=1 and IsDefault=1").ConfigureAwait(false);
                    return defaultId;
                }
                catch (Exception ex)
                {
                    return 0;
                }
            }
        }

        public async Task<dynamic> GetActiveUsers()
        {
            using (IDbConnection db = dbContext.Connection)
            {
                return (await db.GetListAsync<User>().ConfigureAwait(false))?.Select(x => new { key = x.Id, text = x.Id })?.ToList();
            }
        }
    }
}
