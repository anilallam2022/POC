﻿using Dapper;
using DapperExtensions;
using HeliumEdge.DataObjects.ATS;
using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace HeliumEdge.DataAccess.ATS
{
    public class SecurityRepository: BaseRepository
    {
        private readonly IDbContext dbContext;

        public SecurityRepository(IDbContext dbContext) : base(dbContext)
        {
            this.dbContext = dbContext;
        }
        public async Task<User> GetUserAsync(int id)
        {
            try
            {
                using (IDbConnection db = dbContext.Connection)
                {
                    if (db.State != ConnectionState.Open)
                        db.Open();

                    var predicate = Predicates.Field<User>(f => f.Id, Operator.Eq, id);
                    IEnumerable<User> result = await db.GetListAsync<User>(predicate).ConfigureAwait(false);

                    if (result != null)
                    {
                        return result.AsList()[0];
                    }
                }
            }
            catch (Exception ex)
            {
                //TODO
            }

            return null;
        }

        public async Task<User> GetUserByEmailAsync(string email)
        {
            try
            {
                using (IDbConnection db = dbContext.Connection)
                {
                    if (db.State != ConnectionState.Open)
                        db.Open();

                    var predicate = Predicates.Field<User>(f => f.Email, Operator.Eq, email);
                    IEnumerable<User> result = await db.GetListAsync<User>(predicate).ConfigureAwait(false);

                    if (result != null)
                    {
                        return result.AsList()[0];
                    }
                }
            }
            catch (Exception ex)
            {
                //TODO
            }

            return null;
        }

        public async Task<List<RolePermissions>> GetUserPermissionsAsync(int id)
        {
            var permissions = new List<RolePermissions>();
            var user = await GetUserAsync(id);

            try
            {
                using (IDbConnection db = dbContext.Connection)
                {
                    if (db.State != ConnectionState.Open)
                        db.Open();

                    var predicate = Predicates.Field<RolePermissions>(f => f.RoleId, Operator.Eq, user.RoleId);
                    return (await db.GetListAsync<RolePermissions>(predicate).ConfigureAwait(false)).AsList();
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}
