﻿using Dapper;
using DapperExtensions;
using HeliumEdge.DataObjects.ATS;
using HeliumEdge.DataObjects.ATS.ViewModels;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace HeliumEdge.DataAccess.ATS
{
    public class CompanyRepository : BaseRepository
    {
        private readonly IDbContext dbContext;

        public CompanyRepository(IDbContext dbContext) : base(dbContext)
        {
            this.dbContext = dbContext;
        }

        public async Task<dynamic> GetCompaniesList()
        {
            try
            {
                using (IDbConnection db = dbContext.Connection)
                {
                    return (await db.QueryAsync<dynamic>("select Id [key], CompanyName [text] from Company").ConfigureAwait(false))?.ToList();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public async Task<dynamic> GetViewListItems()
        {
            try
            {
                using (IDbConnection db = dbContext.Connection)
                {
                    // TODO to get the logged-in user ID
                    return (await db.GetListAsync<ListPageUserColumn>().ConfigureAwait(false)).Where(x => x.UserId == 1 && x.Entity == "Company").Select(s => new { key = s.Id, value = s.ListName }).ToList();
                }
            }
            catch (Exception ex)
            {
                //TODO
            }
            return null;
        }

        public async Task<CompanyView> GetViewById(int id)
        {
            try
            {
                using (IDbConnection db = dbContext.Connection)
                {
                    return await db.GetAsync<CompanyView>(id).ConfigureAwait(false);
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public async Task<CompanyModel> GetAsync(int id)
        {
            CompanyModel model = null;
            try
            {
                using (IDbConnection db = dbContext.Connection)
                {
                    var company = await db.GetAsync<Company>(id).ConfigureAwait(false);
                    if (company != null)
                    {
                        model = new CompanyModel() { Company = company, };

                        var predicate = Predicates.Field<CompanyDetails>(f => f.CompanyId, Operator.Eq, id);
                        IEnumerable<CompanyDetails> companyDetails = await db.GetListAsync<CompanyDetails>(predicate).ConfigureAwait(false);
                        model.CompanyDetails = companyDetails?.ToList();

                        predicate = Predicates.Field<CompanyContact>(f => f.CompanyId, Operator.Eq, id);
                        IEnumerable<CompanyContact> companyContact = await db.GetListAsync<CompanyContact>(predicate).ConfigureAwait(false);
                        model.CompanyContact = companyContact?.ToList();

                    }
                }
            }
            catch (Exception ex)
            {
                //TODO
            }
            return model;
        }

        public async Task<dynamic> Search(string text)
        {
            try
            {
                using (IDbConnection db = dbContext.Connection)
                {
                    return await db.QueryAsync(@"select Id,companyname [Name] from Company where isDeleted=0 and companyname like @searchtext", param: new { searchText = $"%{text}%" });
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public async Task<IEnumerable<CompanyModel>> GetAllByNameAsync(string name)
        {
            List<CompanyModel> lstModel = null;
            using (IDbConnection db = dbContext.Connection)
            {
                var companies = await db.GetListAsync<Company>(Predicates.Field<Company>(comp => comp.CompanyName, Operator.Like, $"%{name}%")).ConfigureAwait(false);
                if (companies?.Count() > 0)
                {
                    lstModel = new List<CompanyModel>();
                    foreach (var comp in companies)
                    {
                        lstModel.Add(new CompanyModel { Company = comp });
                    }
                }
            }

            return lstModel;
        }

        public async Task<bool> CreateAsync(CompanyModel model)
        {
            IDbTransaction transaction = null;
            try
            {
                using (IDbConnection db = dbContext.Connection)
                {
                    if (db.State != ConnectionState.Open)
                        db.Open();

                    using (transaction = db.BeginTransaction())
                    {
                        model.Company.Id = await db.InsertAsync(model.Company, transaction).ConfigureAwait(false);
                        if (model.CompanyDetails?.Count() > 0)
                        {
                            foreach (CompanyDetails cmpDtls in model.CompanyDetails)
                            {
                                cmpDtls.CompanyId = model.Company.Id;
                                await db.InsertAsync(cmpDtls, transaction).ConfigureAwait(false);
                            }
                        }
                        if (model.CompanyContact?.Count() > 0)
                        {
                            foreach (CompanyContact cmpCont in model.CompanyContact)
                            {
                                cmpCont.CompanyId = model.Company.Id;
                                await db.InsertAsync(cmpCont, transaction).ConfigureAwait(false);
                            }
                        }
                        if (model.Company.Logo != null)
                        {
                            model.Company.Logo.ReferencedEntityId = model.Company.Id;
                            await db.InsertAsync(model.Company.Logo, transaction).ConfigureAwait(false);
                        }
                        transaction.Commit();
                    }
                    return true;
                }
            }
            catch (Exception e)
            {
                transaction?.Rollback();//DO WE REALLY NEED THIS?
                return false;
            }
        }

        public async Task<bool> DeleteAsync(List<int> Ids)
        {
            IDbTransaction transaction = null;
            try
            {
                using (IDbConnection db = dbContext.Connection)
                {
                    db.Open();
                    var predicateGroup = new PredicateGroup { Operator = GroupOperator.Or, Predicates = new List<IPredicate>() };
                    Ids.ForEach(j => predicateGroup.Predicates.Add(Predicates.Field<Company>(f => f.Id, Operator.Eq, j)));
                    bool isDeleted = false;
                    using (transaction = db.BeginTransaction())
                    {
                        var lisComp = (await db.GetListAsync<Company>(predicateGroup, null, transaction).ConfigureAwait(false)).ToList();
                        foreach (var item in lisComp)
                        {
                            item.IsDeleted = true;
                            isDeleted |= await db.UpdateAsync<Company>(item, transaction).ConfigureAwait(false); //returns atleast one is true then true. else false
                        }
                        transaction.Commit();
                    }
                    return isDeleted;
                }
            }
            catch (Exception ex)
            {
                transaction.Rollback();

                //TODO
            }
            return false;
        }

        public async Task<decimal?> GetPlacementFee(int Id)
        {
            try
            {
                using (IDbConnection db = dbContext.Connection)
                {
                    return (await db.GetAsync<Company>(Id).ConfigureAwait(false))?.PlacementFee;
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public async Task<bool> ChangeStatusAsync(EntitiesStatus model)
        {
            try
            {
                using (IDbConnection db = dbContext.Connection)
                {
                    return (await db.ExecuteAsync(@"update Company set statusId=@NewStatusId where Id in @EntityIds", model)) > 0;
                }
            }
            catch (Exception ex)
            {
                //TODO
            }
            return false;
        }

    }
}
