﻿using Dapper;
using HeliumEdge.DataObjects.ATS.ViewModels;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Dynamic;
using System.Linq;
using System.Threading.Tasks;

namespace HeliumEdge.DataAccess.ATS
{
    public abstract class BaseRepository 
    {
        private readonly IDbContext dbContext;
        public BaseRepository()
        {
            
        }
        public BaseRepository(IDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public virtual async Task<dynamic> GetAllAsync(ListPageCriteria listPageCriteria)
        {
            using (var db = dbContext.Connection)
            {
                var parameters = new DynamicParameters();
                parameters.Add("@viewId", listPageCriteria.ViewId);
                parameters.Add("@pageNumber", listPageCriteria.PageNumber);
                parameters.Add("@pageSize", listPageCriteria.PageSize);
                parameters.Add("@sortOrder", listPageCriteria.SortOrder);
                parameters.Add("@sortColumn", listPageCriteria.SortColumn);
                parameters.Add("@entityName", listPageCriteria.Entity);
                parameters.Add("@count", dbType: DbType.Int32, direction: ParameterDirection.Output);

                var reader = await db.QueryMultipleAsync("[FetchListByEntityName]", param: parameters, commandType: CommandType.StoredProcedure).ConfigureAwait(false);
                var displayColumns = (await reader.ReadAsync<dynamic>().ConfigureAwait(false)).ToList();
                var viewList = (await reader.ReadAsync<dynamic>().ConfigureAwait(false)).ToList();
                var totalRecordCount = parameters.Get<int>("@count");
                var resultObject = new ExpandoObject();
                var resultObjectAttr = resultObject as IDictionary<string, object>;
                resultObjectAttr["TotalRecordCount"] = totalRecordCount;
                resultObjectAttr["Headers"] = displayColumns.ToDictionary(col => col.ColumnName, col => col.DisplayText);
                resultObjectAttr["FieldData"] = viewList;

                return resultObject;
            }
        }
    }
}
