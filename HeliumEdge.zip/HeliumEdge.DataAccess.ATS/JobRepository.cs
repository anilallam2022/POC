﻿using Dapper;
using DapperExtensions;
using HeliumEdge.DataObjects.ATS;
using HeliumEdge.DataObjects.ATS.ViewModels;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Dynamic;
using System.Linq;
using System.Threading.Tasks;

namespace HeliumEdge.DataAccess.ATS
{
    public class JobRepository : BaseRepository
    {
        private readonly IDbContext dbContext;
        public JobRepository(IDbContext dbContext) : base(dbContext)
        {
            this.dbContext = dbContext;
        }

        public async Task<JobModel> GetAsync(int id)
        {
            JobModel jobModel = null;
            try
            {
                using (IDbConnection db = dbContext.Connection)
                {
                    var job = await db.GetAsync<Job>(id).ConfigureAwait(false);
                    if (job != null)
                    {
                        jobModel = new JobModel { Job = job };
                        var jobDetailPredicate = Predicates.Field<JobDetails>(f => f.JobId, Operator.Eq, id);
                        jobModel.JobDetails = (await db.GetListAsync<JobDetails>(jobDetailPredicate).ConfigureAwait(false)).ToList();
                    }
                }
            }
            catch (Exception ex)
            {
                //TODO
            }
            return jobModel;
        }

        public async Task<bool> CreateAsync(JobModel model)
        {
            IDbTransaction transaction = null;
            try
            {
                using (IDbConnection db = dbContext.Connection)
                {
                    if (db.State != ConnectionState.Open)
                        db.Open();

                    using (transaction = db.BeginTransaction())
                    {
                        model.Job.Id = await db.InsertAsync(model.Job, transaction).ConfigureAwait(false);

                        if (model.JobDetails?.Count() > 0)
                        {
                            //TODO: need to add updated userId and TenantId
                            foreach (var jobDetail in model.JobDetails)
                            {
                                jobDetail.JobId = model.Job.Id;
                                jobDetail.Id = await db.InsertAsync(jobDetail, transaction).ConfigureAwait(false);
                            }
                        }

                        transaction.Commit();
                    }
                    return true;
                }
            }
            catch (Exception e)
            {
                transaction?.Rollback(); //DO WE NEED THIS?
                return false;
            }
        }

        public async Task<dynamic> Search(string text)
        {
            try
            {
                using (IDbConnection db = dbContext.Connection)
                {
                    return await db.QueryAsync(@"select Id, Title [Name] from Job where isDeleted=0 and Title like @searchText", param: new { searchText = $"%{text}%" });
                }
            }
            catch (Exception ex)
            {
                //TODO
            }
            return null;
        }

        public async Task<dynamic> GetViewListItems(int userId)
        {
            try
            {
                using (IDbConnection db = dbContext.Connection)
                {
                    // TODO to get the logged-in user ID
                    return (await db.GetListAsync<ListPageUserColumn>().ConfigureAwait(false)).Where(x => x.UserId == userId && x.Entity == "Job").Select(s => new { key = s.Id, value = s.ListName }).ToList();
                }
            }
            catch (Exception ex)
            {
                //TODO
            }
            return null;
        }


        public async Task<bool> DeleteAsync(List<int> Ids)
        {
            IDbTransaction transaction = null;
            try
            {
                using (IDbConnection db = dbContext.Connection)
                {
                    db.Open();
                    var predicateGroup = new PredicateGroup { Operator = GroupOperator.Or, Predicates = new List<IPredicate>() };
                    Ids.ForEach(j => predicateGroup.Predicates.Add(Predicates.Field<Job>(f => f.Id, Operator.Eq, j)));
                    bool isDeleted = false;
                    using (transaction = db.BeginTransaction())
                    {
                        var lisJob = (await db.GetListAsync<Job>(predicateGroup, null, transaction).ConfigureAwait(false)).ToList();
                        foreach (var item in lisJob)
                        {
                            item.IsDeleted = true;
                            isDeleted |= await db.UpdateAsync<Job>(item, transaction).ConfigureAwait(false); //returns atleast one is true then true. else false
                        }
                        transaction.Commit();
                    }
                    return isDeleted;
                }
            }
            catch (Exception ex)
            {
                transaction.Rollback();

                //TODO
            }
            return false;
        }

        public async Task<bool> GetDuplicateCheckAsync(string title, int companyId)
        {
            try
            {
                using (IDbConnection db = dbContext.Connection)
                {
                    db.Open();
                    PredicateGroup grp = new PredicateGroup { Operator = GroupOperator.And, Predicates = new List<IPredicate>() };
                    grp.Predicates.Add(Predicates.Field<Job>(f => f.Title, Operator.Eq, title));
                    grp.Predicates.Add(Predicates.Field<Job>(f => f.HiringCompanyId, Operator.Eq, companyId));
                    var job = (await db.GetListAsync<Job>(grp).ConfigureAwait(false));
                    return job.Count() > 0;
                }
            }
            catch (Exception ex)
            {
                //TODO
            }
            return false;
        }

        public async Task<JobModel> GetCloneAsync(int id)
        {
            JobModel jobModel = null;
            try
            {
                using (IDbConnection db = dbContext.Connection)
                {
                    var job = await db.GetAsync<Job>(id).ConfigureAwait(false);
                    job.StatusId = 0;
                    job.Id = 0;
                    job.OrderId = string.Empty;
                    if (job != null)
                    {
                        jobModel = new JobModel { Job = job };
                        var jobDetailPredicate = Predicates.Field<JobDetails>(f => f.JobId, Operator.Eq, id);
                        jobModel.JobDetails = (await db.GetListAsync<JobDetails>(jobDetailPredicate).ConfigureAwait(false)).ToList();
                        foreach (JobDetails jobDtls in jobModel.JobDetails)
                        {
                            jobDtls.Id = 0;
                            jobDtls.JobId = 0;
                        }
                    }
                    return jobModel;
                }
            }
            catch (Exception ex)
            {
                //TODO
            }
            return jobModel;
        }

        public async Task<bool> StatusAsync(List<int> Ids, int statusId, string categoryName, string reason)
        {
            IDbTransaction transaction = null;
            try
            {
                using (IDbConnection db = dbContext.Connection)
                {
                    db.Open();
                    var predicateGroup = new PredicateGroup { Operator = GroupOperator.Or, Predicates = new List<IPredicate>() };
                    Ids.ForEach(j => predicateGroup.Predicates.Add(Predicates.Field<Job>(f => f.Id, Operator.Eq, j)));


                    bool isUpdate = false;
                    using (transaction = db.BeginTransaction())
                    {
                        var lisJob = (await db.GetListAsync<Job>(predicateGroup, null, transaction).ConfigureAwait(false)).ToList();
                        foreach (Job item in lisJob)
                        {
                            if (categoryName == "Status")
                            {
                                item.StatusId = statusId;
                                if (reason.Trim() != string.Empty)
                                    item.Reason = reason;
                            }
                            else if (categoryName == "Priority")
                                item.PriorityId = statusId;
                            isUpdate |= await db.UpdateAsync<Job>(item, transaction).ConfigureAwait(false); //returns atleast one is true then true. else false
                        }
                        transaction.Commit();
                    }
                    return isUpdate;

                    //TODO
                }
            }
            catch (Exception ex)
            {
                return false;
            }
        }


        public async Task<dynamic> GetCompanyDetailsById(int Id)
        {
            using (var db = dbContext.Connection)
            {
                dynamic resultObject = new ExpandoObject();

                resultObject.Contacts = (await db.QueryAsync<dynamic>(@"select a.Id [key], (FirstName + ' ' + isnull(LastName, '')) [text] 
                                                            from Contact a inner join CompanyContact b on a.Id = b.ContactId and a.isdeleted=0
                                                            Inner Join Company c on c.isdeleted=0 and c.Id = b.CompanyId and c.Id = " + Id.ToString()).ConfigureAwait(false))?.ToList();
                Company companyEntity = (await db.GetAsync<Company>(Id).ConfigureAwait(false));
                resultObject.AccountOwnerId = companyEntity?.AccountOwnerId;
                resultObject.PlacementFee = companyEntity?.PlacementFee > 0 ? companyEntity?.PlacementFee : null;
                if (companyEntity?.AccountOwnerId > 0)
                {
                    var contact = (await db.GetAsync<Contact>(companyEntity?.AccountOwnerId).ConfigureAwait(false));
                    resultObject.AccountOwnerName = contact?.FirstName + " - " + contact?.LastName;
                }
                return resultObject;
            }
        }
        public async Task<JobView> GetView(int jobId)
        {
            using (var db = dbContext.Connection)
            {
                return (await db.GetAsync<JobView>(jobId).ConfigureAwait(false));
            }
        }

    }
}
