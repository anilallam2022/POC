using System;
using Xunit;

namespace HeliumEdge.Infrastructure.Tests
{
    public class InfrastructureTests
    {
        [Fact]
        public void QueueDataInsertTest()
        {

        }

        [Fact]
        public void CacheDataInsertTest()
        {

        }
    }
}
