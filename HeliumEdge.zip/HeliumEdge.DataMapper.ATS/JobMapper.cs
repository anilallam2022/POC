﻿using HeliumEdge.DataObjects.ATS;
using HeliumEdge.DataObjects.ATS.ViewModels;
using HeliumEdge.DataTransfer.ATS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HeliumEdge.DataMappers.ATS
{
    public static class JobMapper
    {
        public static JobDTO ToDTO(this JobModel model)
        {
            var dto = new JobDTO
            {
                Id=model.Job.Id,
                OrderId = model.Job.OrderId,
                CanTeleCommute = model.Job.CanTeleCommute,
                HiringCompanyId = model.Job.HiringCompanyId,
                Title = model.Job.Title,
                Description = model.Job.Description,
                Requirement = model.Job.Requirement,
                NoOfOpenings = model.Job.NoOfOpenings,
                StatusId = model.Job.StatusId,
                PriorityId = model.Job.PriorityId,
                ExperienceLevelId = model.Job.ExperienceLevelId,
                SalaryFrom = model.Job.SalaryFrom,
                SalaryTo = model.Job.SalaryTo,
                SalaryUnitId = model.Job.SalaryUnitId,
                TravelRequirementId = model.Job.TravelRequirementId,
                StartDate = model.Job.StartDate,
                Duration = model.Job.Duration,
                DurationUnitId = model.Job.DurationUnitId,
                IndustryId = model.Job.IndustryId,
                DepartmentId = model.Job.DepartmentId,
                PlacementFee = model.Job.PlacementFee,
                PlacementFeeTypeId = model.Job.PlacementFeeTypeId,
                Tags = !string.IsNullOrWhiteSpace(model.Job.Tags) ? model.Job.Tags.Split("|") : null,
                Locations=new List<LocationDTO>(),
                AssignedRecruiterIds=new List<int?>(),
                PrimaryContactIds=new List<int?>()
            };
            foreach (var detail in model.JobDetails)
            {
                if (detail.Location != null)
                {
                    dto.Locations.Add(new LocationDTO() { Location = detail.Location });
                }
                if (detail.PrimaryContactId > 0)
                {
                    dto.PrimaryContactIds.Add(detail.PrimaryContactId);
                }
                if (detail.AssignedRecruiterId > 0)
                {
                    dto.AssignedRecruiterIds.Add(detail.AssignedRecruiterId);
                }
                if (detail.EmploymentTypeId > 0)
                {
                    dto.EmploymentTypeIds.Add(detail.EmploymentTypeId);
                }

            }
            return dto;
        }
        public static JobModel ToDataObject(this JobDTO dto)
        {
            var model = new JobModel
            {
                Job = new Job
                {
                    OrderId = dto.OrderId,
                    CanTeleCommute = dto.CanTeleCommute,
                    HiringCompanyId = dto.HiringCompanyId,
                    Title = dto.Title,
                    Description = dto.Description,
                    Requirement = dto.Requirement,
                    NoOfOpenings = dto.NoOfOpenings,
                    StatusId = dto.StatusId,
                    PriorityId = dto.PriorityId,
                    ExperienceLevelId = dto.ExperienceLevelId,
                    SalaryFrom = dto.SalaryFrom,
                    SalaryTo = dto.SalaryTo,
                    SalaryUnitId = dto.SalaryUnitId,
                    TravelRequirementId = dto.TravelRequirementId,
                    StartDate = dto.StartDate,
                    Duration = dto.Duration,
                    DurationUnitId = dto.DurationUnitId,
                    IndustryId = dto.IndustryId,
                    DepartmentId = dto.DepartmentId,
                    PlacementFee = dto.PlacementFee,
                    PlacementFeeTypeId = dto.PlacementFeeTypeId,
                    Tags = dto.Tags == null ? null : string.Join("|", dto.Tags)
                },
                JobDetails = new List<JobDetails>()                
            };

            //dto.Locations?.ToList().ForEach(j => model.JobDetails.Add(new JobDetails { Location = j.Location }));
            //dto.PrimaryContactIds?.ToList().ForEach(j => model.JobDetails.Add(new JobDetails { PrimaryContactId = j }));
            //dto.AssignedRecruiterIds?.ToList().ForEach(j => model.JobDetails.Add(new JobDetails { AssignedRecruiterId = j }));

            var maxCount = (new List<int> { dto.Locations?.Count() ?? 0, dto.PrimaryContactIds?.Count() ?? 0, dto.AssignedRecruiterIds?.Count() ?? 0, dto.EmploymentTypeIds?.Count() ?? 0 }).Max();

            for (int i = 0; i < maxCount; i++)
            {
                var jobDetails = new JobDetails();
                if (dto.Locations?.Count() > i)
                {
                    jobDetails.Location = dto.Locations.ToList()[i].Location;
                }
                if (dto.PrimaryContactIds?.Count() > i)
                {
                    jobDetails.PrimaryContactId = dto.PrimaryContactIds.ToList()[i];
                }
                if (dto.AssignedRecruiterIds?.Count() > i)
                {
                    jobDetails.AssignedRecruiterId = dto.AssignedRecruiterIds.ToList()[i];
                }
                if (dto.EmploymentTypeIds?.Count() > i)
                {
                    jobDetails.EmploymentTypeId = dto.EmploymentTypeIds.ToList()[i];
                }
                model.JobDetails.Add(jobDetails);
            }

            return model;
        }
        public static JobViewDTO ToViewDTO(this JobView model)
        {
            var dto = new JobViewDTO
            {
                Id = model.Id,
                CompanyId = model.CompanyId,
                CompanyName = model.CompanyName,
                NoOfOpenings = model.NoOfOpenings,
                Status = model.Status,
                Priority = model.Priority,
                StartDate = model.StartDate,
                Duration = model.Duration,
                ExperienceLevel = model.ExperienceLevel,
                TeleCommute = model.TeleCommute,
                SalaryFrom = model.SalaryFrom,
                SalaryTo = model.SalaryTo,
                SalaryUnit = model.SalaryUnit,
            };

            if (!string.IsNullOrWhiteSpace(model.Locations))
                dto.Locations = model.Locations.Split("|");

            if (!string.IsNullOrWhiteSpace(model.EmploymentTypes))
                dto.EmploymentTypes = model.EmploymentTypes.Split("|");

            if (!string.IsNullOrWhiteSpace(model.PrimaryContactNames))
                dto.PrimaryContactNames = model.PrimaryContactNames.Split("|");

            return dto;
        }

    }
}
