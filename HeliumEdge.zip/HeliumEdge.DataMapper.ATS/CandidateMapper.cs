﻿using HeliumEdge.DataObjects.ATS;
using HeliumEdge.DataObjects.ATS.ViewModels;
using HeliumEdge.DataTransfer.ATS;
using System;
using System.Collections.Generic;
using System.Linq;

namespace HeliumEdge.DataMappers.ATS
{
    public static class CandidateMapper
    {
        public static CandidateDTO ToDTO(this CandidateModel model)
        {
            var dto = new CandidateDTO
            {
                Id = model.Candidate.Id,
                FirstName = model.Contact.FirstName,
                MiddleName = model.Contact.MiddleName,
                LastName = model.Contact.LastName,
                CandidateOwnerId = model.Contact.ContactOwnerId,
                CandidateSourceId = model.Candidate.CandidateSourceId,
                DesiredEmploymentTypes = model.Candidate.DesiredEmploymentTypes,
                DesiredLocation = model.Candidate.DesiredLocation,
                DesiredSalary = model.Candidate.DesiredSalary,
                ExperienceLevelId = model.Candidate.ExperienceLevelId,
                ProfileTitle = model.Candidate.ProfileTitle,
                Rating = model.Candidate.Rating,
                RatingComment = model.Candidate.RatingComment,
                TravelPreferencesId = model.Candidate.TravelPreferencesId,
                VisaStatusId = model.Candidate.VisaStatusId,
                AvailabilityId = model.Candidate.AvailabilityId,
                Fax = model.Candidate.Fax,
                Relocate = model.Candidate.Relocate,
                Photo = model.Contact.Photo != null ? new AttachmentDTO { FileName = model.Contact.Photo.FileName, Type = model.Contact.Photo.Type, StorageFileName = model.Contact.Photo.StorageFileName } : null,
                Resume = model.Candidate.Resume != null ? new AttachmentDTO { FileName = model.Candidate.Resume.FileName, Type = model.Candidate.Resume.Type,StorageFileName = model.Candidate.Resume.StorageFileName } : null,
                CandidateCertificates = new List<CandidateCertificateDTO>(),
                CandidateEducations = new List<CandidateEducationDTO>(),
                CandidateExperiences = new List<CandidateExperienceDTO>(),
                CandidateSkills = new List<CandidateSkillDTO>(),                
                Emails = new List<EmailDTO>(),
                PhoneNumbers = new List<PhoneNumberDTO>(),
                WebAddresses = new List<WebAddressDTO>(),
                Addresses = new List<AddressDTO>(),
                FacebookId = model.Contact.FacebookId,
                LinkedInId = model.Contact.LinkedInId,                
                SkypeId = model.Contact.SkypeId,                
                Description=model.Contact.Description,
                Tags = !string.IsNullOrWhiteSpace(model.Contact.Tags) ? model.Contact.Tags.Split("|") : null,
            };
            if (model.Contact.ContactDetails != null && model.Contact.ContactDetails.Any())
            {
                dto.Emails = model.Contact.ContactDetails.Where(cd => !string.IsNullOrWhiteSpace(cd.Email)).Select(email => new EmailDTO { Id = email.Id, Email = email.Email, TypeId = email.EmailTypeId }).ToList();
                dto.PhoneNumbers = model.Contact.ContactDetails.Where(cd => !string.IsNullOrWhiteSpace(cd.PhoneNumber)).Select(phone => new PhoneNumberDTO { Id = phone.Id, PhoneNumber = phone.PhoneNumber, Extension = phone.PhoneExtension, CountryCode = phone.CountryCode, TypeId = phone.PhoneTypeId }).ToList();
                dto.Addresses = model.Contact.ContactDetails.Where(cd => !string.IsNullOrWhiteSpace(cd.Address)).Select(address => new AddressDTO { Id = address.Id, Address = address.Address, TypeId = address.AddressTypeId }).ToList();
                dto.WebAddresses = model.Contact.ContactDetails.Where(cd => !string.IsNullOrWhiteSpace(cd.WebAddress)).Select(address => new WebAddressDTO { Id = address.Id, Url = address.WebAddress, TypeId = address.WebAddressTypeId }).ToList();
            }
            return dto;
        }

        public static CandidateViewDTO ToViewDTO(this CandidateView model)
        {
            var dto = new CandidateViewDTO
            {
                Id = model.Id,
                FirstName = model.FirstName,
                MiddleName = model.MiddleName,
                LastName = model.LastName,
                CandidateOwnerId = model.OwnerId,
                CandidateOwner = model.Owner,
                CandidateSourceId = model.SourceId,
                CandidateSource = model.Source,
                DesiredEmploymentTypes = model.DesiredEmploymentTypes,
                DesiredLocation = model.DesiredLocation,
                DesiredSalary = model.DesiredSalary,
                ExperienceLevelId = model.ExperienceLevelId,
                ExperienceLevel = model.ExperienceLevel,
                ProfileTitle = model.ProfileTitle,
                Rating = model.Rating,
                TravelPreferencesId = model.TravelPreferencesId,
                TravelPreferences = model.TravelPreferences,
                VisaStatusId = model.VisaStatusId,
                VisaStatus = model.VisaStatus,
                AvailabilityId = model.AvailabilityId,
                Availability = model.Availability,
                Fax = model.Fax,
                Relocate = model.Relocate,
                FacebookId = model.FacebookId,
                LinkedInId = model.LinkedInId,
                SkypeId = model.SkypeId,               
                Tags = !string.IsNullOrWhiteSpace(model.Tags) ? model.Tags.Split("|") : null
            };


            if (!string.IsNullOrWhiteSpace(model.Photo))
            {
                var photos = model.Photo.Split("|");
                if (photos.Length > 0)
                {
                    var photoItems = photos[0].Split("^");
                    dto.Photo = new AttachmentDTO
                    {
                        FileName = photoItems.Length > 0 ? photoItems[0] : null,
                        Type = photoItems.Length > 1 ? photoItems[1] : null,
                        StorageFileName = photoItems.Length > 2 ? photoItems[2] : null,
                        FilePath = photoItems.Length > 3 ? photoItems[3] : null
                    };
                }
            }

            if (!string.IsNullOrWhiteSpace(model.Resume))
            {
                var resumes = model.Resume.Split("|");
                if (resumes.Length > 0)
                {
                    var resumeItems = resumes[0].Split("^");
                    dto.Resume = new AttachmentDTO
                    {
                        FileName = resumeItems.Length > 0 ? resumeItems[0] : null,
                        Type = resumeItems.Length > 1 ? resumeItems[1] : null,
                        StorageFileName = resumeItems.Length > 2 ? resumeItems[2] : null,
                        FilePath = resumeItems.Length > 3 ? resumeItems[3] : null
                    };
                }
            }

            if (!string.IsNullOrWhiteSpace(model.Emails))
            {
                var emails = model.Emails.Split("|");
                dto.Emails = emails.Select(email =>
                {
                    var emailItems = email.Split("^");
                    return new EmailViewDTO { Email = emailItems[0], TypeId = emailItems.Length > 1 ? Convert.ToInt32(emailItems[1]) : 0, Type = emailItems.Length > 2 ? emailItems[2] : null };
                }).ToList();                
            }
            if (!string.IsNullOrWhiteSpace(model.PhoneNumbers))
            {
                var phoneNumbers = model.PhoneNumbers.Split("|");
                dto.PhoneNumbers = phoneNumbers.Select(phoneNumber =>
                {
                    var phoneNumberItems = phoneNumber.Split("^");
                    return new PhoneNumberViewDTO { CountryCode = phoneNumberItems[0], PhoneNumber = phoneNumberItems.Length > 1 ? phoneNumberItems[1] : null, Extension = phoneNumberItems.Length > 2 ? phoneNumberItems[2] : null, TypeId = phoneNumberItems.Length > 3 ? Convert.ToInt32(phoneNumberItems[3]) : 0, Type = phoneNumberItems.Length > 4 ? phoneNumberItems[4] : null };
                }).ToList();
            }
            if (!string.IsNullOrWhiteSpace(model.Addresses))
            {
                var addresses = model.Addresses.Split("|");
                dto.Addresses = addresses.Select(address =>
                {
                    var addressItems = address.Split("^");
                    return new AddressViewDTO { Address = addressItems[0], TypeId = addressItems.Length > 1 ? Convert.ToInt32(addressItems[1]) : 0, Type = addressItems.Length > 2 ? addressItems[2] : null };
                }).ToList();
            }
            if (!string.IsNullOrWhiteSpace(model.WebAddresses))
            {
                var addresses = model.Addresses.Split("|");
                dto.WebAddresses = addresses.Select(address =>
                {
                    var addressItems = address.Split("^");
                    return new WebAddressViewDTO {  Url = addressItems[0], TypeId = addressItems.Length > 1 ? Convert.ToInt32(addressItems[1]) : 0, Type = addressItems.Length > 2 ? addressItems[2] : null };
                }).ToList();
            }
            if (!string.IsNullOrWhiteSpace(model.Educations))
            {
                var educations = model.Educations.Split("|");
                dto.Educations = educations.Select(education =>
                {
                    var educationItems = education.Split("^");
                    return new CandidateEducationDTO { Degree = educationItems[0], Institution = educationItems[1], StartDate = Convert.ToDateTime(educationItems[2]), EndDate = Convert.ToDateTime(educationItems[3]), Location = educationItems[4], CurrentlyAttending = educationItems[5] == "1" };
                }).ToList();
            }
            if (!string.IsNullOrWhiteSpace(model.Skills))
            {
                var skills = model.Skills.Split("|");
                dto.Skills = skills.Select(skill =>
                {
                    var skillItems = skill.Split("^");
                    return new CandidateSkillDTO { Skill = skillItems[0], YearsOfExp= Convert.ToInt32(skillItems[1]) };
                }).ToList();
            }
            if (!string.IsNullOrWhiteSpace(model.Certificates))
            {
                var certificates = model.Educations.Split("|");
                dto.Certifications = certificates.Select(certificate =>
                {
                    var certificateItems = certificate.Split("^");
                    return new CandidateCertificateDTO { Name = certificateItems[0], Number = certificateItems[1], Date = Convert.ToDateTime(certificateItems[2]), Authority = certificateItems[3] };
                }).ToList();
            }
            return dto;
        }

        public static CandidateModel ToDataObject(this CandidateDTO dto)
        {
            var model = new CandidateModel
            {
                Candidate = new Candidate
                {
                    DesiredEmploymentTypes = dto.DesiredEmploymentTypes,
                    DesiredLocation = dto.DesiredLocation,
                    DesiredSalary = dto.DesiredSalary,
                    ExperienceLevelId = dto.ExperienceLevelId,
                    ProfileTitle = dto.ProfileTitle,
                    Rating = dto.Rating,
                    RatingComment = dto.RatingComment,
                    TravelPreferencesId = dto.TravelPreferencesId,
                    VisaStatusId = dto.VisaStatusId,
                    Fax = dto.Fax,
                    Relocate = dto.Relocate,
                    AvailabilityId = dto.AvailabilityId,
                    CandidateSourceId = dto.CandidateSourceId,
                    Resume = dto.Resume != null ? new Attachment
                    {
                        FileName = dto.Resume.FileName,
                        Type = "Resume",
                        StorageFileName = dto.Resume.StorageFileName,
                        ReferencedEntityName = "Candidate",
                        FilePath = "Candidate"
                    } : null
                },
                CandidateCertificates = new List<CandidateCertificate>(),
                CandidateEducations = new List<CandidateEducation>(),
                CandidateExperiences = new List<CandidateExperience>(),
                CandidateSkills = new List<CandidateSkill>(),
                Contact = new Contact
                {
                    TypeId= 1, //indicates its a candidate contact
                    FirstName = dto.FirstName,
                    MiddleName = dto.MiddleName,
                    LastName = dto.LastName,
                    ContactDetails = new List<ContactDetails>(),
                    FacebookId=dto.FacebookId,
                    LinkedInId=dto.LinkedInId,
                    SkypeId=dto.SkypeId,
                    ContactOwnerId = dto.CandidateOwnerId,
                    Description =dto.Description,
                    Photo = dto.Photo != null ? new Attachment
                    {
                        FileName = dto.Photo.FileName,
                        Type = "Photo",
                        StorageFileName = dto.Photo.StorageFileName,
                        ReferencedEntityName = "Contact",
                        FilePath = "Candidate"
                    } : null  
                }
            };

            var contactDetails = new List<ContactDetails>();

            dto.Addresses?.ToList().ForEach(c =>
            {
                if (contactDetails.Any(x => x.Address == null))
                {
                    var detail = contactDetails.First(x => string.IsNullOrEmpty(x.Address));
                    detail.Address = c.Address;
                    detail.AddressTypeId = c.TypeId;
                }
                else
                {
                    contactDetails.Add(new ContactDetails { Address = c.Address, AddressTypeId = c.TypeId });
                }
            });

            dto.Emails?.ToList().ForEach(c =>
            {
                if (contactDetails.Any(x => x.Email == null))
                {
                    var detail = contactDetails.First(x => string.IsNullOrEmpty(x.Email));
                    detail.Email = c.Email;
                    detail.EmailTypeId = c.TypeId;
                }
                else
                {
                    contactDetails.Add(new ContactDetails { Email = c.Email, EmailTypeId = c.TypeId });
                }
            });

            dto.PhoneNumbers?.ToList().ForEach(c =>
            {
                if (contactDetails.Any(x => x.PhoneNumber == null))
                {
                    var detail = contactDetails.First(x => string.IsNullOrEmpty(x.PhoneNumber));
                    detail.CountryCode = c.CountryCode;
                    detail.PhoneNumber = c.PhoneNumber;
                    detail.PhoneTypeId = c.TypeId;
                    detail.PhoneExtension = c.Extension;
                }
                else
                {
                    contactDetails.Add(new ContactDetails { CountryCode = c.CountryCode, PhoneNumber = c.PhoneNumber, PhoneTypeId = c.TypeId, PhoneExtension = c.Extension });
                }
            });
            dto.WebAddresses?.ToList().ForEach(c =>
            {
                if (contactDetails.Any(x => x.WebAddress == null))
                {
                    var detail = contactDetails.First(x => string.IsNullOrEmpty(x.WebAddress));
                    detail.WebAddress = c.Url;
                    detail.WebAddressTypeId = c.TypeId;
                }
                else
                {
                    contactDetails.Add(new ContactDetails { WebAddress = c.Url, WebAddressTypeId = c.TypeId });
                }
            });
            model.Contact.ContactDetails = contactDetails;
            dto.CandidateCertificates?.ToList().ForEach(c => model.CandidateCertificates.Add(new CandidateCertificate { Name = c.Name, Number = c.Number, Authority = c.Authority, Date = c.Date }));
            dto.CandidateEducations?.ToList().ForEach(c => model.CandidateEducations.Add(new CandidateEducation { Degree = c.Degree, Institution = c.Institution, StartDate = c.StartDate, EndDate = c.EndDate, Location = c.Location, CurrentlyAttending = c.CurrentlyAttending }));
            dto.CandidateExperiences?.ToList().ForEach(c => model.CandidateExperiences.Add(new CandidateExperience { Employer = c.Employer, Role = c.Role, Location = c.Location, StartDate = c.StartDate, EndDate = c.EndDate, Responsibilities = c.Responsibilities, Remarks = c.Remarks, CurrentlyWorking = c.CurrentlyWorking }));
            dto.CandidateSkills?.ToList().ForEach(c => model.CandidateSkills.Add(new CandidateSkill { Skill = c.Skill, YearsOfExp = c.YearsOfExp }));

            return model;
        }
    }
}
