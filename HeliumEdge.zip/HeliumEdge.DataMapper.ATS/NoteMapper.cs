﻿using HeliumEdge.DataObjects.ATS;
using HeliumEdge.DataTransfer.ATS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HeliumEdge.DataMappers.ATS
{
    public static class NoteMapper
    {
        public static NoteViewDTO ToDTO(this Note model)
        {
            var dto = new NoteViewDTO
            {
                Id = model.Id,
                Description = model.Description,
                TypeIds = model.TypeIds == null ? null : model.TypeIds.Split('|').Select(x => Convert.ToInt32(x)).ToArray(),
                Tags = new List<TagViewDTO>()
            };
            model.Tags?.ToList().ForEach(n => dto.Tags.Add(new TagViewDTO
            {
                Type = n.Type,
                ReferenceItems = !string.IsNullOrWhiteSpace(n.Tags) ? n.Tags.Split("|").
                    Select(tags => { var pair = tags.Split('^'); return new PairDTO { Id = Convert.ToInt32(pair[0]), Name = pair[1] }; }) : null
            }));
            return dto;
        }

        public static Note ToDataObject(this NoteDTO dto)
        {
            var model = new Note
            {
                Description = dto.Description,
                TypeIds = dto.TypeIds == null ? null : string.Join('|', dto.TypeIds),
                Tags = new List<Tag>(),
                Attachments = dto.Attachments?.Select(file=> new DataObjects.ATS.Attachment
                {
                    StorageFileName = file.StorageFileName,
                    FileName = file.FileName,
                    Type = "Attachment",
                    ReferencedEntityName = "Note",
                    FilePath = "Note"
                }).ToList()
            };
            dto.Tags?.ToList().ForEach(n => model.Tags.Add(new Tag { Type = n.Type, Tags = string.Join("|", n.ReferenceIds), ReferenceEntityName = "Note", Id = n.Id }));
            return model;
        }
    }
}
