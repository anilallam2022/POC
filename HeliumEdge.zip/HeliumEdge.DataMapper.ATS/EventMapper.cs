﻿using HeliumEdge.DataObjects.ATS;
using HeliumEdge.DataTransfer.ATS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HeliumEdge.DataMappers.ATS
{
    public static class EventMapper
    {
        public static EventViewDTO ToDTO(this EventModel model)
        {
            var dto = new EventViewDTO
            {
                EventTypeId = model.Event.EventTypeId,
                Title = model.Event.Title,
                Attendies = model.Event.Attendies,
                InterviewTypeId = model.Event.InterviewTypeId,
                Description = model.Event.Description,
                EndDate = model.Event.EndDate,
                IsPersonal = model.Event.IsPersonal,
                IsRepeat = model.Event.IsRepeat,
                Location = model.Event.Location,
                MonthDates = model.Event.MonthDates,
                OrganizerId = model.Event.OrganizerId,
                PhoneNumber = model.Event.PhoneNumber,
                ReminderInMinutes = model.Event.ReminderInMinutes,
                RepeatFrequencyId = model.Event.RepeatFrequencyId,
                StartDate = model.Event.StartDate,
                Tags = new List<TagViewDTO>(),
                TimeZone = model.Event.TimeZone,
                WebAddress = model.Event.WebAddress,
                WeekDays = model.Event.WeekDays,
                WeekFrequency = model.Event.WeekFrequency,
                YearMonthDates = model.Event.YearMonthDates,
                YearMonths = model.Event.YearMonths
            };
            model.Tags?.ToList().ForEach(t => dto.Tags.Add(new TagViewDTO
            {
                Type = t.Type,
                ReferenceItems = !string.IsNullOrWhiteSpace(t.Tags) ? t.Tags.Split("|").
                    Select(tags => { var pair = tags.Split('^'); return new PairDTO { Id = Convert.ToInt32(pair[0]), Name = pair[1] }; }) : null
            }));
            return dto;
        }
        public static EventModel ToDataObject(this EventDTO dto)
        {
            var model = new EventModel
            {
                Event = new Event
                {
                    EventTypeId = dto.EventTypeId,
                    Title = dto.Title,
                    Attendies = dto.Attendies,
                    InterviewTypeId = dto.InterviewTypeId,
                    Description = dto.Description,
                    EndDate = dto.EndDate,
                    IsPersonal = dto.IsPersonal,
                    IsRepeat = dto.IsRepeat,
                    Location = dto.Location,
                    MonthDates = dto.MonthDates,
                    OrganizerId = dto.OrganizerId,
                    PhoneNumber = dto.PhoneNumber,
                    ReminderInMinutes = dto.ReminderInMinutes,
                    RepeatFrequencyId = dto.RepeatFrequencyId,
                    StartDate = dto.StartDate,
                    TimeZone = dto.TimeZone,
                    WebAddress = dto.WebAddress,
                    WeekDays = dto.WeekDays,
                    WeekFrequency = dto.WeekFrequency,
                    YearMonthDates = dto.YearMonthDates,
                    YearMonths = dto.YearMonths
                },
                Tags = new List<Tag>()
            };
            dto.Tags?.ToList().ForEach(t => model.Tags.Add(new Tag { Tags = string.Join("|", t.ReferenceIds), Type = t.Type, ReferenceEntityName = "Event" }));
            return model;
        }
    }
}
