﻿using HeliumEdge.DataObjects.ATS;
using HeliumEdge.DataTransfer.ATS;
using System;

namespace HeliumEdge.DataMappers.ATS
{
    public static class ListPageColumnMapper
    {
        public static ListPageColumnDTO ToDTO(this ListPageColumn model)
        {
            return new ListPageColumnDTO { Id = model.Id, IsLocked = model.IsLocked, Name = model.ColumnName, DisplayText = model.DisplayText };
        }

        public static ListPageColumn ToDataObject(this ListPageColumnDTO dto)
        {
            throw new NotImplementedException();
        }
    }
}
