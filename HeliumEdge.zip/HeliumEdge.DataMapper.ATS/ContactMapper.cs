﻿using System;
using System.Collections.Generic;
using System.Linq;
using HeliumEdge.DataObjects.ATS;
using HeliumEdge.DataObjects.ATS.ViewModels;
using HeliumEdge.DataTransfer.ATS;

namespace HeliumEdge.DataMappers.ATS
{
    public static class ContactMapper
    {
        public static ContactDTO ToDTO(this Contact model)
        {
            var dto = new ContactDTO
            {
                Id = model.Id,
                FirstName = model.FirstName,
                LastName = model.LastName,
                MiddleName = model.MiddleName,
                IsPrivateContact = model.IsPrivateContact,
                ContactOwnerId = model.ContactOwnerId,
                ContactSourceId = model.ContactSourceId,
                ContactTypeIds = string.IsNullOrWhiteSpace(model.ContactTypeIds) ? null : model.ContactTypeIds.Split('|').Select(x => Convert.ToInt32(x)).ToArray(),
                LinkedInId = model.LinkedInId,
                SkypeId = model.SkypeId,
                PreferredMethodOfContactIds = string.IsNullOrWhiteSpace(model.PreferredMethodOfContactIds) ? null : model.PreferredMethodOfContactIds.Split('|').Select(x => Convert.ToInt32(x)).ToArray(),
                PreferredTimeToContact = model.PreferredTimeToContact,
                Description = model.Description,
                Tags = string.IsNullOrWhiteSpace(model.Tags) ? null : model.Tags.Split('|'),
                Photo = model.Photo != null ? new AttachmentDTO
                {
                    FileName = model.Photo.FileName,
                    Type = "Photo",
                    StorageFileName = model.Photo.StorageFileName,
                } : null,
                CompanyContact = model.CompanyContact != null ? new CompanyContactDTO
                {
                    Id = model.CompanyContact.Id,
                    Role = model.CompanyContact.Role,
                    CompanyId = model.CompanyContact.CompanyId,
                    ContactId = model.CompanyContact.ContactId,
                    DepartmentId = model.CompanyContact.DepartmentId
                } : null
            };
            if (model.ContactDetails != null && model.ContactDetails.Any())
            {
                dto.Emails = model.ContactDetails.Where(cd => !string.IsNullOrWhiteSpace(cd.Email)).Select(email => new EmailDTO { Id = email.Id, Email = email.Email, TypeId = email.EmailTypeId }).ToList();
                dto.PhoneNumbers = model.ContactDetails.Where(cd => !string.IsNullOrWhiteSpace(cd.PhoneNumber)).Select(phone => new PhoneNumberDTO { Id = phone.Id, PhoneNumber = phone.PhoneNumber, Extension = phone.PhoneExtension, CountryCode = phone.CountryCode, TypeId = phone.PhoneTypeId }).ToList();
                dto.Addresses = model.ContactDetails.Where(cd => !string.IsNullOrWhiteSpace(cd.Address)).Select(address => new AddressDTO { Id = address.Id, Address = address.Address, TypeId = address.AddressTypeId }).ToList();
                dto.WebAddresses = model.ContactDetails.Where(cd => !string.IsNullOrWhiteSpace(cd.WebAddress)).Select(address => new WebAddressDTO { Id = address.Id, Url = address.WebAddress, TypeId = address.WebAddressTypeId }).ToList();
            }
            return dto;
        }

        public static Contact ToDataObject(this ContactDTO dto)
        {
            var model = new Contact
            {
                Id = dto.Id,
                FirstName = dto.FirstName,
                LastName = dto.LastName,
                MiddleName = dto.MiddleName,
                IsPrivateContact = dto.IsPrivateContact,
                ContactOwnerId = dto.ContactOwnerId,
                ContactSourceId = dto.ContactSourceId,
                ContactTypeIds = dto.ContactTypeIds != null ? string.Join("|", dto.ContactTypeIds) : string.Empty,
                LinkedInId = dto.LinkedInId,
                SkypeId = dto.SkypeId,
                FacebookId = dto.FacebookId,
                PreferredMethodOfContactIds = dto.PreferredMethodOfContactIds != null ? string.Join("|", dto.PreferredMethodOfContactIds) : string.Empty,
                PreferredTimeToContact = dto.PreferredTimeToContact,
                Description = dto.Description,
                Tags = dto.Tags != null ? string.Join("|", dto.Tags) : string.Empty,
                ContactDetails = new List<ContactDetails>(),
                TenantId = 0,
                CompanyContact = dto.CompanyContact != null && dto.CompanyContact.CompanyId.HasValue ? new CompanyContact
                {
                    CompanyId = dto.CompanyContact.CompanyId,
                    ContactId = dto.CompanyContact.ContactId,
                    DepartmentId = dto.CompanyContact.DepartmentId,
                    Role = dto.CompanyContact.Role
                } : null,
                Photo = dto.Photo != null && !string.IsNullOrWhiteSpace(dto.Photo.StorageFileName) ? new DataObjects.ATS.Attachment
                {
                    FileName = dto.Photo.FileName,
                    Type = "Photo",
                    StorageFileName = dto.Photo.StorageFileName,
                    ReferencedEntityName = "Contact",
                    FilePath = "Contact"
                } : null
            };
            dto.Addresses?.ToList().ForEach(address => model.ContactDetails.Add(new ContactDetails { Address = address.Address, AddressTypeId = address.TypeId }));
            dto.WebAddresses?.ToList().ForEach(address => model.ContactDetails.Add(new ContactDetails { WebAddress = address.Url, WebAddressTypeId = address.TypeId }));
            dto.Emails?.ToList().ForEach(email => model.ContactDetails.Add(new ContactDetails { Email = email.Email, EmailTypeId = email.TypeId }));
            dto.PhoneNumbers?.ToList().ForEach(phone => model.ContactDetails.Add(new ContactDetails { PhoneNumber = phone.PhoneNumber, PhoneTypeId = phone.TypeId, PhoneExtension = phone.Extension, CountryCode = phone.CountryCode }));

            return model;
        }

        public static ContactViewDTO ToViewDTO(this ContactView model)
        {
            var dto = new ContactViewDTO
            {
                Id = model.Id,
                FirstName = model.FirstName,
                MiddleName = model.MiddleName,
                LastName = model.LastName,                
                CompanyId = model.CompanyId,
                CompanyName = model.CompanyName,
                ContactOwnerId = model.OwnerId,
                ContactOwner = model.Owner,
                IsPrivateContact = model.IsPrivateContact,                
                LinkedInId = model.LinkedInId,
                SkypeId = model.SkypeId,
                FacebookId = model.FacebookId,
                Department = model.Department,
                DepartmentId = model.DepartmentId,
                Types = model.Types,
                Description = model.Description,
                PreferredMethodOfContact = model.PreferredMethodOfContact,
                PreferredTimeToContact = model.PreferredTimeToContact,
                CreatedBy = model.CreatedBy,
                CreatedDate = model.CreatedDate,
                SourceId = model.SourceId,
                Suorce = model.Source,
                Tags = !string.IsNullOrWhiteSpace(model.Tags) ? model.Tags.Split("|") : null,
                RoleName = model.RoleName
            };

            if (!string.IsNullOrWhiteSpace(model.Photo))
            {
                var photos = model.Photo.Split("|");
                if (photos.Length > 0)
                {
                    var photoItems = photos[0].Split("^");
                    dto.Photo = new AttachmentDTO
                    {
                        FileName = photoItems.Length > 0 ? photoItems[0] : null,
                        Type = photoItems.Length > 1 ? photoItems[1] : null,
                        StorageFileName = photoItems.Length > 2 ? photoItems[2] : null,
                        FilePath = photoItems.Length > 3 ? photoItems[3] : null
                    };
                }
            }

            if (!string.IsNullOrWhiteSpace(model.Emails))
            {
                var emails = model.Emails.Split("|");
                dto.Emails = emails.Select(email =>
                {
                    var emailItems = email.Split("^");
                    return new EmailViewDTO { Email = emailItems[0], TypeId = emailItems.Length > 1 ? Convert.ToInt32(emailItems[1]) : 0, Type = emailItems.Length > 2 ? emailItems[2] : null };
                }).ToList();
            }
            if (!string.IsNullOrWhiteSpace(model.PhoneNumbers))
            {
                var phoneNumbers = model.PhoneNumbers.Split("|");
                dto.PhoneNumbers = phoneNumbers.Select(phoneNumber =>
                {
                    var phoneNumberItems = phoneNumber.Split("^");
                    return new PhoneNumberViewDTO { CountryCode = phoneNumberItems[0], PhoneNumber = phoneNumberItems.Length > 1 ? phoneNumberItems[1] : null, Extension = phoneNumberItems.Length > 2 ? phoneNumberItems[2] : null, TypeId = phoneNumberItems.Length > 3 ? Convert.ToInt32(phoneNumberItems[3]) : 0, Type = phoneNumberItems.Length > 4 ? phoneNumberItems[4] : null };
                }).ToList();
            }
            if (!string.IsNullOrWhiteSpace(model.Addresses))
            {
                var addresses = model.Addresses.Split("|");
                dto.Addresses = addresses.Select(address =>
                {
                    var addressItems = address.Split("^");
                    return new AddressViewDTO { Address = addressItems[0], TypeId = addressItems.Length > 1 ? Convert.ToInt32(addressItems[1]) : 0, Type = addressItems.Length > 2 ? addressItems[2] : null };
                }).ToList();
            }
            if (!string.IsNullOrWhiteSpace(model.WebAddresses))
            {
                var addresses = model.WebAddresses.Split("|");
                dto.WebAddresses = addresses.Select(address =>
                {
                    var addressItems = address.Split("^");
                    return new WebAddressViewDTO { Url = addressItems[0], TypeId = addressItems.Length > 1 ? Convert.ToInt32(addressItems[1]) : 0, Type = addressItems.Length > 2 ? addressItems[2] : null };
                }).ToList();
            }

            return dto;
        }
    }
}
