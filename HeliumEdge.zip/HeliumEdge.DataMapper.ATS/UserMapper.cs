﻿using HeliumEdge.DataObjects.ATS;
using HeliumEdge.DataTransfer.ATS;

namespace HeliumEdge.DataMappers.ATS
{
    public static class UserMapper
    {
        public static UserDTO ToDTO(this User model)
        {
            var dto = new UserDTO
            {
                Id = model.Id,
                TenantId = model.TenantId
            };

            return dto;
        }

        public static User ToDataObject(this UserDTO dto)
        {
            return new User
            {
                Id = dto.Id,
                RoleId = dto.RoleId,
                TenantId = dto.TenantId,
                Email = dto.Email,
                FirstName = dto.FirstName,
                LastName = dto.LastName,
                Password = dto.Password
            };
        }
    }
}
