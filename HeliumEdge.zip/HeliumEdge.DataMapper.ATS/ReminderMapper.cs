﻿using HeliumEdge.DataObjects.ATS;
using HeliumEdge.DataTransfer.ATS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HeliumEdge.DataMappers.ATS
{
    public static class ReminderMapper
    {
        public static ReminderViewDTO ToDTO(this ReminderModel model)
        {
            var dto = new ReminderViewDTO
            {
                Id = model.Reminder.Id,
                Date = model.Reminder.Date,
                Description = model.Reminder.Description,
                RemindBefore = model.Reminder.RemindBefore,
                Title = model.Reminder.Title,
                Tags = new List<TagViewDTO>()
            };
            model.Tags?.ToList().ForEach(t => dto.Tags.Add(new TagViewDTO
            {
                Type = t.Type,
                ReferenceItems = !string.IsNullOrWhiteSpace(t.Tags) ? t.Tags.Split("|").
                    Select(tags => { var pair = tags.Split('^'); return new PairDTO { Id = Convert.ToInt32(pair[0]), Name = pair[1] }; }) : null
            }));

            return dto;
        }
        public static ReminderModel ToDataObject(this ReminderDTO dto)
        {
            var model = new ReminderModel
            {
                Reminder = new Reminder
                {
                    Date = dto.Date,
                    Description = dto.Description,
                    RemindBefore = dto.RemindBefore,
                    Title = dto.Title
                },
                Tags = new List<Tag>()
            };
            dto.Tags?.ToList().ForEach(t => model.Tags.Add(new Tag { Tags = string.Join("|", t.ReferenceIds), Type = t.Type, ReferenceEntityName = "Reminder" }));

            return model;
        }
    }
}
