﻿using HeliumEdge.DataObjects.ATS;
using HeliumEdge.DataTransfer.ATS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HeliumEdge.DataMappers.ATS
{
    public static class TaskMapper
    {
        public static TaskViewDTO ToDTO(this TaskModel model)
        {
            var dto = new TaskViewDTO
            {
                Id = model.TaskEntity.Id,
                TypeId = model.TaskEntity.TypeId,
                Title = model.TaskEntity.Title,
                AssignedToUserId = model.TaskEntity.AssignedToUserId,
                PriorityId = model.TaskEntity.PriorityId,
                TaskDateTime = model.TaskEntity.TaskDateTime,
                IsRepeat = model.TaskEntity.IsRepeat,
                RepeatFrequencyId = model.TaskEntity.RepeatFrequencyId,
                WeekDays = model.TaskEntity.WeekDays == null ? null : model.TaskEntity.WeekDays.Split('|').Select(x => (int?)Convert.ToInt32(x)).ToArray(),
                WeekFrequency = model.TaskEntity.WeekFrequency,
                MonthDates = model.TaskEntity.MonthDates == null ? null : model.TaskEntity.MonthDates.Split('|').Select(x => (int?)Convert.ToInt32(x)).ToArray(),
                YearMonths = model.TaskEntity.YearMonths == null ? null : model.TaskEntity.YearMonths.Split('|').Select(x => (int?)Convert.ToInt32(x)).ToArray(),
                YearMonthDates = model.TaskEntity.YearMonthDates == null ? null : model.TaskEntity.YearMonthDates.Split('|').Select(x => (int?)Convert.ToInt32(x)).ToArray(),
                EndDate = model.TaskEntity.EndDate,
                ReminderInMinutesId = model.TaskEntity.ReminderInMinutesId,
                Description = model.TaskEntity.Description,
                Tags = new List<TagViewDTO>()
            };
            model.Tags?.ToList().ForEach(t => dto.Tags.Add(new TagViewDTO
            {
                Type = t.Type,
                ReferenceItems = !string.IsNullOrWhiteSpace(t.Tags) ? t.Tags.Split("|").
                    Select(tags => { var pair = tags.Split('^'); return new PairDTO { Id = Convert.ToInt32(pair[0]), Name = pair[1] }; }) : null
            }));
            return dto;
        }
        public static TaskModel ToDataObject(this TaskDTO dto)
        {
            var model = new TaskModel
            {
                TaskEntity = new TaskEntity
                {
                    TypeId = dto.TypeId,
                    Title = dto.Title,
                    AssignedToUserId = dto.AssignedToUserId,
                    PriorityId = dto.PriorityId,
                    TaskDateTime = dto.TaskDateTime,
                    IsRepeat = dto.IsRepeat,
                    RepeatFrequencyId = dto.RepeatFrequencyId,
                    WeekDays = dto.WeekDays == null ? null : string.Join('|', dto.WeekDays),
                    WeekFrequency = dto.WeekFrequency,
                    MonthDates = dto.MonthDates == null ? null : string.Join('|', dto.MonthDates),
                    YearMonths = dto.YearMonths == null ? null : string.Join('|', dto.YearMonths),
                    YearMonthDates = dto.YearMonthDates == null ? null : string.Join('|', dto.YearMonthDates),
                    EndDate = dto.EndDate,
                    ReminderInMinutesId = dto.ReminderInMinutesId,
                    Description = dto.Description
                },
                Tags = dto.Tags?.Select(tag => new Tag
                {
                    Type = tag.Type,
                    Tags = tag.ReferenceIds?.Count() > 0 ? string.Join("|", tag.ReferenceIds) : null,
                    ReferenceEntityName = "TaskEntity",
                    Id = tag.Id
                }).ToList(),
                Attachments = dto.Attachments?.Select(file => new DataObjects.ATS.Attachment
                {
                    StorageFileName = file.StorageFileName,
                    FileName = file.FileName,
                    Type = "Attachment",
                    ReferencedEntityName = "TaskEntity",
                    FilePath = "TaskEntity"
                }).ToList()
            };
            return model;
        }
    }
}
