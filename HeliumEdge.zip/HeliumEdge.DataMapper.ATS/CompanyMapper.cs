﻿using HeliumEdge.DataObjects.ATS;
using HeliumEdge.DataObjects.ATS.ViewModels;
using HeliumEdge.DataTransfer.ATS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HeliumEdge.DataMappers.ATS
{
    public static class CompanyMapper
    {
        public static CompanyDTO ToDTO(this CompanyModel model)
        {
            var dto = new CompanyDTO
            {
                Id = model.Company.Id,
                CompanyName = model.Company.CompanyName,
                CompanyTypeIds = !string.IsNullOrWhiteSpace(model.Company.CompanyTypeIds) ? model.Company.CompanyTypeIds.Split('|').Select(x => Convert.ToInt32(x)).ToArray(): null,
                AccountOwnerId = model.Company.AccountOwnerId,
                Description = model.Company.Description,
                EmploymentTypeIds = !string.IsNullOrWhiteSpace(model.Company.EmploymentTypeIds) ? model.Company.EmploymentTypeIds.Split('|').Select(x => Convert.ToInt32(x)).ToArray(): null,
                FacebookId = model.Company.FacebookId,
                FeeTypeId = model.Company.FeeTypeId,
                IndustryId = model.Company.IndustryId,
                LinkedInId = model.Company.LinkedInId,
                WebsiteUrl = model.Company.WebsiteUrl,
                PlacementFee = model.Company.PlacementFee,
                PaymentTermsId = model.Company.PaymentTermsId,
                Priority = model.Company.Priority,
                Tags = !string.IsNullOrWhiteSpace(model.Company.Tags) ? model.Company.Tags.Split("|") : null,
                CompanyContact = new List<CompanyContactDTO>(),
                Emails = new List<EmailDTO>(),
                PhoneNumbers = new List<PhoneNumberDTO>(),
                Addresses = new List<AddressDTO>(),
                Logo = model.Company.Logo != null ? new AttachmentDTO {
                    StorageFileName = model.Company.Logo.StorageFileName,
                    FileName = model.Company.Logo.FileName,
                    Type= model.Company.Logo.Type
                } : null
            };
            if (model.CompanyDetails != null && model.CompanyDetails.Any())
            {
                dto.Emails = model.CompanyDetails.Where(cd => !string.IsNullOrWhiteSpace(cd.Email)).Select(email => new EmailDTO { Id = email.Id, Email = email.Email, TypeId = email.EmailTypeId }).ToList();
                dto.PhoneNumbers = model.CompanyDetails.Where(cd => !string.IsNullOrWhiteSpace(cd.PhoneNumber)).Select(phone => new PhoneNumberDTO { Id = phone.Id, PhoneNumber = phone.PhoneNumber, Extension = phone.PhoneExtension, CountryCode = phone.CountryCode, TypeId = phone.PhoneTypeId }).ToList();
                dto.Addresses = model.CompanyDetails.Where(cd => !string.IsNullOrWhiteSpace(cd.Address)).Select(address => new AddressDTO { Id = address.Id, Address = address.Address, TypeId = address.AddressTypeId }).ToList();
            }
            model.CompanyContact?.ToList().ForEach(c => dto.CompanyContact.Add(new CompanyContactDTO { ContactId = c.ContactId, DepartmentId = c.DepartmentId, Role = c.Role }));
            return dto;
        }
        public static CompanyModel ToDataObject(this CompanyDTO dto)
        {
            var model = new CompanyModel
            {
                Company = new Company
                {
                    CompanyName = dto.CompanyName,
                    CompanyTypeIds = dto.CompanyTypeIds == null ? null : string.Join('|', dto.CompanyTypeIds),
                    AccountOwnerId = dto.AccountOwnerId,
                    Description = dto.Description,
                    EmploymentTypeIds = dto.EmploymentTypeIds == null ? null : string.Join('|', dto.EmploymentTypeIds),
                    FacebookId = dto.FacebookId,
                    FeeTypeId = dto.FeeTypeId,
                    IndustryId = dto.IndustryId,
                    LinkedInId = dto.LinkedInId,
                    WebsiteUrl = dto.WebsiteUrl,
                    PlacementFee = dto.PlacementFee,
                    PaymentTermsId = dto.PaymentTermsId,
                    Priority = dto.Priority,
                    StatusId = dto.StatusId,
                    Tags = dto.Tags == null ? null : string.Join('|', dto.Tags),
                    Logo = dto.Logo != null && !string.IsNullOrWhiteSpace(dto.Logo.StorageFileName) ? new DataObjects.ATS.Attachment
                    {
                        FileName = dto.Logo.FileName,
                        Type = "Logo",
                        StorageFileName = dto.Logo.StorageFileName,
                        ReferencedEntityName = "Company",
                        FilePath = "Company"
                    } : null
                },
                CompanyContact = new List<CompanyContact>(),
                CompanyDetails = new List<CompanyDetails>()
            };
            dto.CompanyContact?.ToList().ForEach(c => model.CompanyContact.Add(new CompanyContact { ContactId=c.ContactId,Role=c.Role }));
            var maxCount = (new List<int> { dto.Addresses?.Count() ?? 0, dto.Emails?.Count() ?? 0, dto.PhoneNumbers?.Count() ?? 0 }).Max();
            
            for (int i = 0; i < maxCount; i++)
            {
                var CompanyDetails = new CompanyDetails();
                if (dto.Addresses?.Count() > i)
                {
                    CompanyDetails.Address = dto.Addresses.ElementAt(i).Address;
                    CompanyDetails.AddressTypeId = dto.Addresses.ElementAt(i).TypeId;
                }
                if (dto.Emails?.Count() > i)
                {
                    CompanyDetails.Email = dto.Emails.ElementAt(i).Email;
                    CompanyDetails.EmailTypeId = dto.Emails.ElementAt(i).TypeId;
                }
                if (dto.PhoneNumbers?.Count() > i)
                {
                    CompanyDetails.CountryCode = dto.PhoneNumbers.ElementAt(i).CountryCode;
                    CompanyDetails.PhoneNumber = dto.PhoneNumbers.ElementAt(i).PhoneNumber;
                    CompanyDetails.PhoneExtension = dto.PhoneNumbers.ElementAt(i).Extension;
                    CompanyDetails.PhoneTypeId = dto.PhoneNumbers.ElementAt(i).TypeId;
                }
                model.CompanyDetails.Add(CompanyDetails);
            }

            return model;
        }
        public static CompanyViewDTO ToViewDTO(this CompanyView model)
        {
            var dto = new CompanyViewDTO
            {
                CompanyName = model.CompanyName,
                CompanyLogo = model.CompanyLogo,
                CompanyTypes = model.CompanyTypes?.Split('|')?.ToList(),
                Email = model.Email,
                Location = model.Location,
                PaymentTerms = model.PaymentTerms,
                Phone = model.Phone,
                PlacementFee = model.PlacementFee,
                PlacementFeeType = model.FeeType,
                EmployementTypes = model.EmploymentTypes?.Split('|')?.ToList(),
                PrimaryContact = model.PrimaryContact,
                FacebookId = model.FacebookId,
                LinkedinId = model.LinkedinId,
                Status = model.Status,
                Tags = model.Tags?.Split('|')?.ToList(),
                Website = model.WebsiteUrl
            };
            return dto;
        }
    }
}
