﻿using HeliumEdge.DataTransfer.ATS;
using HeliumEdge.Services.ATS;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.TestHost;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace HeliumEdge.ATS.Tests.Integration
{
    public class CompanyTest
    {
        private readonly HttpClient _client = new HttpClient();
        private readonly TestServer _server;

        public CompanyTest()
        {
            _server = new TestServer(new WebHostBuilder()
            .UseStartup<Startup>());
            _client = _server.CreateClient();
        }

        [Fact]
        public async Task Company_Get_List_Page1()
        {
            var listInput = new ListPageRequestDTO { PageSize = 4, PageNumber = 1, ViewId = 0, SortColumn = "Id", SortOrder = "DESC" };
            var content = JsonConvert.SerializeObject(listInput);
            var stringContent = new StringContent(content, Encoding.UTF8, "application/json");
            var response = await _client.PostAsync("api/Company/List", stringContent).ConfigureAwait(false);
            response.EnsureSuccessStatusCode();
            var responseString = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
            var listdata = JsonConvert.DeserializeObject<dynamic>(responseString);
            Assert.NotNull(listdata);            
        }

        [Fact]
        public async Task Company_Get_List_Page2()
        {
            var listInput = new ListPageRequestDTO { PageSize = 4, PageNumber = 2, ViewId = 0, SortColumn = "Id", SortOrder = "DESC" };
            var content = JsonConvert.SerializeObject(listInput);
            var stringContent = new StringContent(content, Encoding.UTF8, "application/json");
            var response = await _client.PostAsync("api/Company/List", stringContent).ConfigureAwait(false);
            response.EnsureSuccessStatusCode();
            var responseString = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
            var listdata = JsonConvert.DeserializeObject<dynamic>(responseString);
            Assert.NotNull(listdata);
        }

        [Fact]
        public async Task Company_Get_Specific()
        {
            var response = await _client.GetAsync("http://localhost:62604/api/Company/1").ConfigureAwait(false);
            response.EnsureSuccessStatusCode();
            var responseString = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
            var result = JsonConvert.DeserializeObject<CompanyDTO>(responseString);
            Assert.NotNull(result);
        }

        [Fact]
        public async Task<bool> Company_Insert()
        {
            var dto = new CompanyDTO
            {
                AccountOwnerId = 1,
                CompanyTypeIds = new int[] { 70, 71 },
                CompanyName = "HeliumEdge",
                Description = "Description",
                EmploymentTypeIds = new int[] { 168, 169 },
                FacebookId = "Facebook!",
                FeeTypeId = 186,
                IndustryId = 195,
                LinkedInId = "Lindin!",
                PlacementFee = Convert.ToDecimal(78.00),
                PaymentTermsId = 264,
                Priority = true,
                Tags = new string[] { "sad", "asd", "asda" },
                WebsiteUrl = "wwww.ggoggg.ccom",
                PhoneNumbers = new List<PhoneNumberDTO>
                {
                    new PhoneNumberDTO() { CountryCode="91", PhoneNumber = "2312", Extension = "223", TypeId=275},
                    new PhoneNumberDTO() { CountryCode="91", PhoneNumber = "2312123", Extension = "33", TypeId=274 }
                },
                Emails = new List<EmailDTO>
                {
                    new EmailDTO(){ Email = "abc@gmail.com", TypeId = 2, },
                    new EmailDTO(){ Email = "xyz@yahoo.com", TypeId = 2, }
                },
                Addresses = new List<AddressDTO>
                {
                    new AddressDTO(){ Address = "Address1"},
                    new AddressDTO(){ Address = "Address1" }
                }
            };
            var content = JsonConvert.SerializeObject(dto);
            var stringContent = new StringContent(content, Encoding.UTF8, "application/json");
            var response = await _client.PostAsync("/api/Company", stringContent).ConfigureAwait(false);
            response.EnsureSuccessStatusCode();
            var responseString = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
            var isInserted = Convert.ToBoolean(responseString);
            Assert.True(isInserted);
            return isInserted;
        }

        [Fact]
        public async Task GetPlacementFee()
        {
            var response = await _client.GetAsync("http://localhost:62604/api/Company/GetPlacementFee/1").ConfigureAwait(false);
            response.EnsureSuccessStatusCode();
            var responseString = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
            var result = JsonConvert.DeserializeObject<CompanyDTO>(responseString);
            Assert.NotNull(result);
        }

        [Fact]
        public async Task ChangeStatus()
        {
            EntitiesStatusDTO dto = new EntitiesStatusDTO
            {
                EntityIds = new List<int> { 18, 31 },
                NewStatusId = 1490
            };
            var content = JsonConvert.SerializeObject(dto);
            var stringContent = new StringContent(content, Encoding.UTF8, "application/json");
            var response = await _client.PostAsync("/api/Company/ChangeStatus", stringContent).ConfigureAwait(false);
            response.EnsureSuccessStatusCode();
            var responseString = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
            var isupdated = Convert.ToBoolean(responseString);
            Assert.True(isupdated);
            
        }
    }
}
