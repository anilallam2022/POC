﻿using HeliumEdge.Services.ATS;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.TestHost;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;
using Xunit;

namespace HeliumEdge.ATS.Tests.Integration
{
    public class FileUploadTests
    {
        private readonly HttpClient _client = new HttpClient();
        private readonly TestServer _server;

        public FileUploadTests()
        {
            _server = new TestServer(new WebHostBuilder()
            .UseStartup<Startup>());
            _client = _server.CreateClient();
        }

        //[Fact]
        //public async Task Upload_File()
        //{
        //    string uri = "http://localhost:62604/api/FileUpload/UploadMultipartUsingReader";

        //}
    }
}
