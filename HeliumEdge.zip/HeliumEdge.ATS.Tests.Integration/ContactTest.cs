﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.TestHost;
using Xunit;
using System;
using HeliumEdge.Services.ATS;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using HeliumEdge.DataObjects.ATS;
using HeliumEdge.DataTransfer.ATS;

namespace HeliumEdge.ATS.Tests.Integration
{
    public class ContactTest
    {
        private readonly HttpClient _client = new HttpClient();
        private readonly TestServer _server;

        public ContactTest()
        {
            _server = new TestServer(new WebHostBuilder()
            .UseStartup<Startup>());
            _client = _server.CreateClient();
        }
                
        [Fact]
        public async Task CreateContact()
        {
            //var responseLookupValues = await _client.GetAsync("http://localhost:62604/api/MasterData/GetKeyValByModule?modulename=contact");
            //responseLookupValues.EnsureSuccessStatusCode();
            //var responseString = await responseLookupValues.Content.ReadAsStringAsync();
            //var lookupValues = JsonConvert.DeserializeObject<List<ApplicationLookup>>(responseString);

            var contact = new ContactDTO
            {
                FirstName="FN",
                LastName="LN",
                MiddleName="MN",
                ContactOwnerId=1,
                ContactSourceId =1,
                ContactTypeIds = new int[] { 1, 2 },
                LinkedInId = "#linkedin",
                SkypeId = "testskype",
                PreferredMethodOfContactIds = new int[] { 1, 2 },
                PreferredTimeToContact ="10AM",
                Description="Test contact desription",
                Tags= new string[] { "Tag1", "Tag2" },
                PhoneNumbers=new List<PhoneNumberDTO> { new PhoneNumberDTO { CountryCode="91", PhoneNumber="1234555", Extension="999", TypeId=1} },
                Emails= new List<EmailDTO> { new EmailDTO { Email="aaa@gmail.com", TypeId=1} },
                Addresses=new List<AddressDTO> { new AddressDTO { Address="st1", TypeId=1} },
                WebAddresses=new List<WebAddressDTO> { new WebAddressDTO { Url = "http://abc.com", TypeId = 1 } }
            };

            var content = JsonConvert.SerializeObject(contact);
            var stringContent = new StringContent(content, Encoding.UTF8, "application/json");
            var response = await _client.PostAsync("http://localhost:62604/api/Contacts", stringContent).ConfigureAwait(false);
            response.EnsureSuccessStatusCode();
            var result = JsonConvert.DeserializeObject<bool>(response.Content.ReadAsStringAsync().Result);
            Assert.True(result);
        }

        [Fact]
        public async Task GetContactsForListPage()
        {
            var input = new ListPageRequestDTO { PageNumber = 1, PageSize = 10, SortColumn = "Id", SortOrder = "ASC", ViewId = 0 };
            var content = JsonConvert.SerializeObject(input);
            var stringContent = new StringContent(content, Encoding.UTF8, "application/json");
            var response = await _client.PostAsync("http://localhost:62604/api/Contacts/list", stringContent).ConfigureAwait(false);
            response.EnsureSuccessStatusCode();
            var responseString = await response.Content.ReadAsStringAsync().ConfigureAwait(true);
            var result = JsonConvert.DeserializeObject<List<ContactDTO>>(responseString);
            Assert.NotNull(result);
        }

        [Fact]
        public async Task GetContact()
        {
            var response = await _client.GetAsync("http://localhost:62604/api/Contacts/1").ConfigureAwait(false);
            response.EnsureSuccessStatusCode();
            var responseString = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
            var result = JsonConvert.DeserializeObject<ContactDTO>(responseString);
            Assert.NotNull(result);
        }
    }
}