using HeliumEdge.DataTransfer.ATS;
using HeliumEdge.Services.ATS;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.TestHost;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace HeliumEdge.ATS.Tests.Integration
{
    public class CandidateTest
    {
        private readonly HttpClient _client = new HttpClient();
        private readonly TestServer _server;

        public CandidateTest()
        {
            _server = new TestServer(new WebHostBuilder()
            .UseStartup<Startup>());
            _client = _server.CreateClient();
        }

        [Fact]
        public async Task Candidates_Get_All()
        {
            var response = await _client.GetAsync("http://localhost:62604/api/Candidate/").ConfigureAwait(false);
            response.EnsureSuccessStatusCode();
            var responseString = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
            var result = JsonConvert.DeserializeObject<List<CandidateDTO>>(responseString);            
            Assert.NotNull(result);
        }

        [Fact]
        public async Task Candidate_Get_Specific()
        {
            var response = await _client.GetAsync("http://localhost:62604/api/Candidate/35").ConfigureAwait(false);
            response.EnsureSuccessStatusCode();
            var responseString = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
            var result = JsonConvert.DeserializeObject<CandidateDTO>(responseString);
            Assert.NotNull(result);
        }


        [Fact]
        public async Task Candidates_Insert()
        {
            var dto = new CandidateDTO();

            dto.FirstName = "Joydip";
            dto.MiddleName = "";
            dto.LastName = "Kanjilal";
            dto.ProfileTitle = "Developer";
            dto.ExperienceLevelId = 1;
            dto.VisaStatusId = 1;
            dto.DesiredEmploymentTypes = "2|3";
            dto.DesiredSalary = 6000;
            dto.DesiredLocation = "Hyderabad";
            dto.Rating = 5;
            dto.RatingComment = "NA";
            dto.TravelPreferencesId = 1;
            dto.Description = "Test Description";
            
            List<CandidateSkillDTO> candidateSkills = new List<CandidateSkillDTO>();
            CandidateSkillDTO skill = new CandidateSkillDTO()
            {
                 Skill = "ASP.NET",
                 YearsOfExp = 5
            };
            candidateSkills.Add(skill);
            dto.CandidateSkills = candidateSkills;

            List<CandidateExperienceDTO> candidateExperiences = new List<CandidateExperienceDTO>();

            CandidateExperienceDTO experience = new CandidateExperienceDTO()
            {
                 Employer = "ABC",
                 Location = "Hyderabad",
                 Remarks = "",
                 Role = "Sr. Developer",
                 Responsibilities = "Design & Development",
                 StartDate = DateTime.Now,
                 EndDate = DateTime.Now
            };

            candidateExperiences.Add(experience);
            dto.CandidateExperiences = candidateExperiences;


            List<CandidateEducationDTO> candidateEducations = new List<CandidateEducationDTO>();

            CandidateEducationDTO candidateEducation = new CandidateEducationDTO()
            {
                Degree = "MCA",
                Institution = "University of Kolkata",
                StartDate = DateTime.Now,
                EndDate = DateTime.Now
            };

            candidateEducations.Add(candidateEducation);
            dto.CandidateEducations = candidateEducations;


            List<CandidateCertificateDTO> candidateCertificates = new List<CandidateCertificateDTO>();

            CandidateCertificateDTO candidateCertificate = new CandidateCertificateDTO()
            {
                Authority = "Microsoft",
                Name = "MVP",
                Number = "1.0",
                Date = DateTime.Now
            };

            candidateCertificates.Add(candidateCertificate);
            dto.CandidateCertificates = candidateCertificates;

            var content = JsonConvert.SerializeObject(dto);
            var stringContent = new StringContent(content, Encoding.UTF8, "application/json");
            var response = await _client.PostAsync("/api/Candidate", stringContent).ConfigureAwait(false);
            response.EnsureSuccessStatusCode();

            Assert.NotNull(response);
        }
    }
}
