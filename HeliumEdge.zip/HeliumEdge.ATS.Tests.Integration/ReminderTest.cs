﻿using HeliumEdge.Services.ATS;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.TestHost;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System;
using Xunit;
using HeliumEdge.DataTransfer.ATS;

namespace HeliumEdge.ATS.Tests.Integration
{
    public class ReminderTest
    {
        private readonly HttpClient _client = new HttpClient();
        private readonly TestServer _server;

        public ReminderTest()
        {
            _server = new TestServer(new WebHostBuilder()
            .UseStartup<Startup>());
            _client = _server.CreateClient();
        }

        [Fact]
        public async Task Note_Get_All()
        {
            var response = await _client.GetAsync("http://localhost:62604/api/Reminders").ConfigureAwait(false);
            response.EnsureSuccessStatusCode();
            var responseString = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
            var result = JsonConvert.DeserializeObject<List<ReminderDTO>>(responseString);
            Assert.NotNull(result[0]);
        }

        [Fact]
        public async Task Note_Get_Specific()
        {
            var response = await _client.GetAsync("http://localhost:62604/api/Reminders/1").ConfigureAwait(false);
            response.EnsureSuccessStatusCode();
            var responseString = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
            var result = JsonConvert.DeserializeObject<ReminderDTO>(responseString);
            Assert.NotNull(result);
        }


        [Fact]
        public async Task Note_Insert()
        {
            var dto = new ReminderDTO
            {
                Date = new DateTime(),
                Description = "Reminder Description",
                RemindBefore = "15 mins",
                Title = "New Reminder",
                Tags = new List<TagDTO> {
                    new TagDTO {Type="Company",ReferenceIds=new int[]{1,2 } },
                    new TagDTO {Type="Contact",ReferenceIds=new int[]{1,2 } },
                    new TagDTO {Type="Candidate",ReferenceIds=new int[]{1,2 } }
                }
            };
            var content = JsonConvert.SerializeObject(dto);
            var stringContent = new StringContent(content, Encoding.UTF8, "application/json");
            var response = await _client.PostAsync("/api/Reminders", stringContent).ConfigureAwait(false);
            response.EnsureSuccessStatusCode();
            var responseString = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
            var result = JsonConvert.DeserializeObject<ReminderDTO>(responseString);
            Assert.NotNull(result);
            Assert.True(result.Id > 0);
        }
    }
}
