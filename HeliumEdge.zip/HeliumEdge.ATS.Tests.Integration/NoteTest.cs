﻿using HeliumEdge.DataObjects.ATS;
using HeliumEdge.DataTransfer.ATS;
using HeliumEdge.Services.ATS;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.TestHost;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace HeliumEdge.ATS.Tests.Integration
{
    public class NoteTest
    {
        private readonly HttpClient _client = new HttpClient();
        private readonly TestServer _server;

        public NoteTest()
        {
            _server = new TestServer(new WebHostBuilder()
            .UseStartup<Startup>());
            _client = _server.CreateClient();
        }

        [Fact]
        public async Task Note_Get_All()
        {
            var response = await _client.GetAsync("http://localhost:62604/api/Notes/").ConfigureAwait(false);
            response.EnsureSuccessStatusCode();
            var responseString = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
            var result = JsonConvert.DeserializeObject<List<NoteDTO>>(responseString);
            Assert.NotNull(result[0]);
        }

        [Fact]
        public async Task Note_Get_Specific()
        {
            var response = await _client.GetAsync("http://localhost:62604/api/Notes/1").ConfigureAwait(false);
            response.EnsureSuccessStatusCode();
            var responseString = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
            var result = JsonConvert.DeserializeObject<NoteDTO>(responseString);
            Assert.NotNull(result);
        }


        [Fact]
        public async Task Note_Insert()
        {
            var dto = new NoteDTO
            {
                TypeIds = new int[] { 257, 258 },
                Description = "Note Description",
                Tags = new List<TagDTO>
                {
                    new TagDTO { Type = "Company", ReferenceIds = new int[]{1,2 } },
                    new TagDTO { Type = "Contact", ReferenceIds = new int[]{1,2 } },
                    new TagDTO { Type = "Candidate", ReferenceIds = new int[]{1,2 } }
                }
            };
            var content = JsonConvert.SerializeObject(dto);
            var stringContent = new StringContent(content, Encoding.UTF8, "application/json");
            var response = await _client.PostAsync("/api/Notes", stringContent).ConfigureAwait(false);
            response.EnsureSuccessStatusCode();
            var responseString = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
            var result = JsonConvert.DeserializeObject<NoteDTO>(responseString);

            Assert.True(result.Id > 0);
        }
    }
}
