﻿using HeliumEdge.BusinessObjects.ATS;
using HeliumEdge.DataTransfer.ATS;
using HeliumEdge.Services.ATS;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.TestHost;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace HeliumEdge.ATS.Tests.Integration
{
    /// <summary>
    /// 
    /// </summary>
    public class JobTest
    {
        private readonly HttpClient _client = new HttpClient();
        private readonly TestServer _server;
        public JobTest()
        {
            _server = new TestServer(new WebHostBuilder()
            .UseStartup<Startup>());
            _client = _server.CreateClient();
        }

        [Fact]
        public async Task Jobs_Get_All()
        {
            var response = await _client.GetAsync("http://localhost:62604/api/Jobs").ConfigureAwait(false);
            response.EnsureSuccessStatusCode();
            var responseString = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
            var result = JsonConvert.DeserializeObject<List<JobDTO>>(responseString);
            Assert.NotNull(result);
        }

        [Fact]
        public async Task Job_Get_Specific()
        {
            var response = await _client.GetAsync("http://localhost:62604/api/Jobs/1").ConfigureAwait(false);
            response.EnsureSuccessStatusCode();
            var responseString = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
            var result = JsonConvert.DeserializeObject<JobDTO>(responseString);
            Assert.NotNull(result);
        }

        [Fact]
        public async Task Job_Create()
        {
            var dto = new JobDTO
            {
                OrderId = "01",
                Title = "Software Developer",
                CanTeleCommute = true,
                HiringCompanyId = 1,
                AccountManagerId = 1,
                EmploymentTypeIds = new List<int?>() { 1, 2 },
                NoOfOpenings = 5,
                StatusId = 1,
                PriorityId = 1,
                ExperienceLevelId = 1,
                SalaryFrom = 1500,
                SalaryTo = 2000,
                SalaryUnitId = 1,
                TravelRequirementId = 1,
                StartDate = DateTime.Now,
                Duration = 1.5F,
                DurationUnitId = 2,
                IndustryId = 1,
                DepartmentId = 1,
                PlacementFee = 20.5F,
                PlacementFeeTypeId = 1,
                Description = "Software Developer",
                Requirement = "Software Developer",
                Tags = new string[] { "tag1", "tag2" },
                Locations =   new List<LocationDTO> { 
                    new LocationDTO() { Location =  "Location1" },
                    new LocationDTO() { Location =  "Location2" }
                    },
                AssignedRecruiterIds = new int?[] { 1 },
                PrimaryContactIds = new int?[] { 1, 2 }
            };            
            var content = JsonConvert.SerializeObject(dto);
            var stringContent = new StringContent(content, Encoding.UTF8, "application/json");
            var response = await _client.PostAsync("/api/Jobs", stringContent).ConfigureAwait(false);
            response.EnsureSuccessStatusCode();
            var responseString = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
            var result = JsonConvert.DeserializeObject<bool>(responseString);

            Assert.True(result);
        }


        [Fact]
        public async Task DeleteJobs()
        {
            //var manager = new JobManager();
            //List<int> ids = new List<int>() { 8, 20, 21 };
            //var result = await manager.DeleteJobs(ids);
            //Assert.True(result);
        }

        [Fact]
        public async Task Status_Changes_Jobs()
        {

            var dto = new ChangeStatusDTO() { StatusId = 1, CategoryName = "Status", SelectedIds = new List<int> { 1, 2, 3 } };
            var content = JsonConvert.SerializeObject(dto);
            var stringContent = new StringContent(content, Encoding.UTF8, "application/json"); ;
            var response = await _client.PostAsync("http://localhost:62604/api/Jobs/Status", stringContent).ConfigureAwait(false);
            response.EnsureSuccessStatusCode();
            var responseString = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
            var result = JsonConvert.DeserializeObject<bool>(responseString);
            Assert.True(result);
        }
    }
}
