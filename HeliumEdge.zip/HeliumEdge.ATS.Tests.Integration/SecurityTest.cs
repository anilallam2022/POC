﻿using HeliumEdge.Common;
using HeliumEdge.Services;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json.Linq;
using System.IdentityModel.Tokens.Jwt;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace HeliumEdge.ATS.Tests.Integration
{
    public class SecurityTest
    {
        private readonly HttpClient _client = new HttpClient();
        private readonly TestServer _server;

        public SecurityTest()
        {
            var configuration = new ConfigurationBuilder()
            .SetBasePath(Path.GetFullPath(@"../../.."))
            .AddJsonFile("appsettings.json", optional: false)
            .Build();

            _server = new TestServer(new WebHostBuilder()
               .UseStartup<Startup>()
               .UseConfiguration(configuration));
            _client = _server.CreateClient();
        }

        [Fact]
        public async Task GetAllRecords()
        {
            string url = "http://localhost:62600/api/gateway";
            var bodyString = @"{userid: ""Zameer"", password: ""Zameer123"", domain: ""HeliumEdge.com""}";
            var result = await _client.PostAsync("/api/token", new StringContent(bodyString, Encoding.UTF8, "application/json"));

            var resultString = await result.Content.ReadAsStringAsync().ConfigureAwait(false);

            _client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", resultString);
            //var response = await _client.GetAsync("http://localhost:62600/api/gateway");
            var response = await _client.GetAsync(url);
            response.EnsureSuccessStatusCode();
            var responseString = await response.Content.ReadAsStringAsync();
            Assert.NotNull(responseString);
        }

        [Fact]
        public async Task GetUserPermissions()
        {
            var response = await _client.GetAsync("api/token?userId=Joydip");

            response.EnsureSuccessStatusCode();
            var responseString = await response.Content.ReadAsStringAsync();
            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        }

        [Fact]
        public async Task GetToken()
        {
            string baseUrl = "http://localhost:62604";
            const string bodyString = @"{userid: ""Joydip"", password: ""Joydip123"", domain: ""HeliumEdge.com""}";
            //var response = await _client.PostAsync("/api/token", new StringContent(bodyString, Encoding.UTF8, "application/json"));
            var response = await _client.PostAsync(baseUrl +"/api/token", new StringContent(bodyString, Encoding.UTF8, "application/json"));

            Assert.Equal(HttpStatusCode.OK, response.StatusCode);


            var responseString = await response.Content.ReadAsStringAsync();
            var responseJson = JObject.Parse(responseString);
            Assert.NotNull((string)responseJson["token"]);
        }

        [Fact]
        public async Task ValidateUserCredentialsTest()
        {
            const string bodyString = @"{userid: ""Joydip"", password: ""Joydip123"", domain: ""HeliumEdge.com""}";
            var response = await _client.PostAsync("/api/token/AuthenticateUser", new StringContent(bodyString, Encoding.UTF8, "application/json"));

            Assert.Equal(HttpStatusCode.OK, response.StatusCode);

            var responseString = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
            var responseJson = JObject.Parse(responseString);
            Assert.NotNull((string)responseJson["token"]);
        }

        [Fact]
        public void TokenValidation()
        {
            var securityKey = TokenHelper.GetSecretKey("Joydip", "Test");

            string token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9uYW1lIjoiS2FuamlsYWwsSm95ZGlwIiwiaHR0cDovL3NjaGVtYXMueG1sc29hcC5vcmcvd3MvMjAwNS8wNS9pZGVudGl0eS9jbGFpbXMvZW1haWxhZGRyZXNzIjoiam95ZGlwa2FuamlsYWxAb3V0bG9vay5jb20iLCJodHRwOi8vc2NoZW1hcy5taWNyb3NvZnQuY29tL3dzLzIwMDgvMDYvaWRlbnRpdHkvY2xhaW1zL3JvbGUiOiJBZG1pbmlzdHJhdG9yIiwiZXhwIjoxNTI0ODQwNzQzLCJpc3MiOiJvZkFQcUVyT3JzOG14RFU5OUoxeHhZeWpPb2lWOTZjTjg5M3ZRTGJwaFRHa3pBSVRzVTlUc3cwWGlSbG5XdXAwM2I1ZnVId2RMMzBhM2Z5bFBJN1kyS3U5MXA3NlVJVGJuWjhLZFBuTGpxWHN2d3BMclFlSS9NYzhCelhUOXBTYXBuRytpOWRMVmQ4RTVUQ2RNTHBWY3lTU2tzS2psRzZUbkRxbnFBWmJoNU09IiwiYXVkIjoib2ZBUHFFck9yczhteERVOTlKMXh4WXlqT29pVjk2Y044OTN2UUxicGhUR2t6QUlUc1U5VHN3MFhpUmxuV3VwMDNiNWZ1SHdkTDMwYTNmeWxQSTdZMkt1OTFwNzZVSVRiblo4S2RQbkxqcVhzdndwTHJRZUkvTWM4QnpYVDlwU2FwbkcraTlkTFZkOEU1VENkTUxwVmN5U1Nrc0tqbEc2VG5EcW5xQVpiaDVNPSJ9.xJw_ClZ0ux46gk2be4naYCKoKu3kcG5ULVdnUxSuOu0";
            SecurityToken validatedToken;
            TokenValidationParameters validationParameters = new TokenValidationParameters();
            validationParameters.IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("HeliumEdgeSecretKey"));
            validationParameters.ValidAudience = "http://localhost:63939/";
            validationParameters.ValidIssuer = "http://localhost:63939/";
            validationParameters.ValidateIssuer = true;

            var principal = new JwtSecurityTokenHandler().ValidateToken(token, validationParameters, out validatedToken);
            var userName = principal.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name)?.Value;
            var role = principal.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Role)?.Value;
            var userEmailId = principal.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Email)?.Value;
            Assert.NotNull(validatedToken);
        }
    }
}
