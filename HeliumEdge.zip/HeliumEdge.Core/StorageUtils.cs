﻿using Microsoft.WindowsAzure.Storage;
using Microsoft.Extensions.Configuration;

namespace HeliumEdge.Core
{
    public class StorageUtils
    {
        readonly CloudStorageAccount storageAccount;
        IConfiguration Configuration { get; }
        public StorageUtils(IConfiguration configuration)
        {
            Configuration = configuration;
            string connectionString = Configuration["ConnectionStrings:StorageConnectionString"];
            CloudStorageAccount.TryParse(connectionString, out storageAccount);
        }
        public CloudStorageAccount StorageAccount
        {
            get
            {
                return storageAccount;
            }
        }
    }
}
