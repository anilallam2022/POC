﻿
namespace HeliumEdge.Core
{
    public class ResponseErrorMetadata : ResponseMetadata
    {
        public string ErrorMessage { get; set; }
        public object Errors { get; set; }
    }
}
