﻿using System.IO;
using System.Threading.Tasks;

namespace HeliumEdge.Core
{
    public interface IBlobService
    {
        Task<BlobAttributes> GetFileSasUrlAsync(string blobKey, string container,string folder);
        Task<byte[]> GetFileDataAsync(string blobKey, string container, string folder);
        Task<BlobAttributes> UploadFileAsync(byte[] fileToUpload, string fileName, string container);
        Task<BlobAttributes> UploadFileChunkAsync(int chunkIndex, byte[] chunkData, string fileName, string container, string directory, bool isCommitBlobBlocks = false);
        Task<bool> DeleteFileAsync(string fileName, string container);
    }
}
