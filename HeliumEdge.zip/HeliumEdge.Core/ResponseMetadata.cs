﻿using System;

namespace HeliumEdge.Core
{
    public class ResponseMetadata
    {
        public string Version { get; set; }
        public int StatusCode { get; set; }
        public object Content { get; set; }
        public DateTime Timestamp { get; set; }
        public long? Size { get; set; }
    }
}
