﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HeliumEdge.Core
{
    public class BlobAttributes
    {
        public string Path { get; set; }
        public string Name { get; set; }
    }
}
