﻿using Microsoft.Extensions.Configuration;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using System;
using System.IO;
using System.Threading.Tasks;
using System.Linq;
using System.Text;

namespace HeliumEdge.Core
{
    public class BlobService : IBlobService
    {
        readonly CloudStorageAccount account = null;
        public BlobService(IConfiguration configuration)
        {
            StorageUtils storageUtils = new StorageUtils(configuration);
            this.account = storageUtils.StorageAccount;
        }
    
        async Task<CloudBlobContainer> GetContainer(string container)
        {
            
            CloudStorageAccount storageAccount = account;
            CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();
            CloudBlobContainer cloudBlobContainer = blobClient.GetContainerReference(container?.ToLower());
            cloudBlobContainer = await CreateAndConfigureAsync(cloudBlobContainer);
            return cloudBlobContainer;
        }

        /// <summary>
        /// To create a container if not already there
        /// </summary>
        async Task<CloudBlobContainer> CreateAndConfigureAsync(CloudBlobContainer blobContainer)
        {
            if (await blobContainer.CreateIfNotExistsAsync())
            {
                await blobContainer.SetPermissionsAsync(
                   new BlobContainerPermissions
                   {
                       PublicAccess = BlobContainerPublicAccessType.Off
                   });
            }
            return blobContainer;
        }

        /// <summary>
        /// Make an attempt to delete the file
        /// </summary>
        /// <param name="fileName"></param>
        /// <returns></returns>
        public async Task<bool> DeleteFileAsync(string fileName, string container)
        {
            if (string.IsNullOrEmpty(fileName))
            {
                return false;
            }

            CloudBlobContainer blobContainer = await GetContainer(container);
            CloudBlockBlob blob = blobContainer.GetBlockBlobReference(fileName);
            await blob.DeleteIfExistsAsync();
            return true;
        }

        /// <summary>
        /// Uploads a file into blob container
        /// </summary>
        /// <param name="fileToUpload"></param>
        /// <returns></returns>
        public async Task<BlobAttributes> UploadFileAsync(byte[] fileToUpload,string fileName,string container)
        {
            BlobAttributes blobAttrs = new BlobAttributes();
            CloudBlobContainer blobContainer = await GetContainer(container);
            fileName = $"{Guid.NewGuid().ToString()}_{fileName}";
            CloudBlockBlob blob = blobContainer.GetBlockBlobReference(fileName);
            await blob.UploadFromByteArrayAsync(fileToUpload, 0, fileToUpload.Length);
            blobAttrs.Path = blob.Uri.ToString();
            blobAttrs.Name = blob.Name;
            return blobAttrs;
        }

        public async Task<BlobAttributes> UploadFileChunkAsync(int chunkIndex, byte[] chunkData, string fileName, string container, string directory, bool isCommitBlobBlocks = false)
        {
            //Azure storage structure will be Tenant (container) -> Module (folder) -> FileName (blob file)

            BlobAttributes blobAttrs = new BlobAttributes();
            CloudBlobContainer blobContainer = await GetContainer(container);
            var blobDirectory = blobContainer.GetDirectoryReference(directory);
            CloudBlockBlob blob = blobDirectory.GetBlockBlobReference(fileName);
            try
            {
                using (var chunkStream = new MemoryStream(chunkData, true))
                {
                    var blockId = Convert.ToBase64String(Encoding.UTF8.GetBytes($"{chunkIndex}_{Guid.NewGuid().ToString()}")); //append index first so that sorting of the blocks will be easy & accurate.

                    await blob.PutBlockAsync(
                        blockId,
                        chunkStream, null);
                }

                //TODO: check the total file size does not exceed the limit.
                if (isCommitBlobBlocks)
                {
                    var blobBlocks = await blob.DownloadBlockListAsync(BlockListingFilter.Uncommitted, 
                                            AccessCondition.GenerateEmptyCondition(),
                                            new BlobRequestOptions { },
                                            new OperationContext { });
                    var blockItemsNames = blobBlocks.ToDictionary(x => Convert.ToInt32(Encoding.UTF8.GetString(Convert.FromBase64String(x.Name)).Split('_').First()), x => x.Name).OrderBy(x=>x.Key).Select(x=>x.Value);
                    await blob.PutBlockListAsync(blockItemsNames);
                }
                //blobAttrs.Path = blob.Uri.ToString();
                blobAttrs.Name = blob.Name.Split("/").Last();
                return blobAttrs;
            }
            catch (StorageException e)
            {
                //TODO: handle exception
                throw;
            }
        }

        /// <summary>
        /// Returns the blob attributes for a given blob key
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="container"></param>
        /// <param name="folder"></param>
        /// <returns></returns>
        public async Task<byte[]> GetFileDataAsync(string blobKey, string container, string folder)
        {
            CloudBlobContainer blobContainer = await GetContainer(container);
            var blobDirectory = blobContainer.GetDirectoryReference(folder);
            CloudBlockBlob blob = blobDirectory.GetBlockBlobReference(blobKey);
            if (blob != null)
            {
                Byte[] bytes;
                using (var stream = new MemoryStream())
                {
                    await blob.DownloadToStreamAsync(stream);
                    bytes = stream.ToArray();
                }                    
                return bytes;
            }
            return null;
        }

        /// <summary>
        /// Returns the blob attributes for a given blob key
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="container"></param>
        /// <returns></returns>
        public async Task<BlobAttributes> GetFileSasUrlAsync(string blobKey, string container, string folder)
        {
            BlobAttributes blobAttrs = null;
            CloudBlobContainer blobContainer = await GetContainer(container);
            var blobDirectory = blobContainer.GetDirectoryReference(folder);
            CloudBlockBlob blob = blobDirectory.GetBlockBlobReference(blobKey);
            if (blob != null)
            {
                string sasContainerToken = GenerateSharedAccessSignature(blob, SharedAccessBlobPermissions.Read);

                blobAttrs = new BlobAttributes
                {
                    Path = blob.Uri.ToString() + sasContainerToken,
                    Name = blob.Name
                };
            }

            return blobAttrs;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="blob"></param>
        /// <param name="permissions"></param>
        /// <param name="expiryTimeInMinutes"></param>
        /// <returns></returns>
        private string GenerateSharedAccessSignature(CloudBlockBlob blob, SharedAccessBlobPermissions permissions, int expiryTimeInMinutes=1)
        {
            var sasConstraints = new SharedAccessBlobPolicy();
            sasConstraints.SharedAccessExpiryTime = DateTimeOffset.UtcNow.AddMinutes(expiryTimeInMinutes);
            sasConstraints.Permissions = permissions;

            //Generate the shared access signature on the container, setting the constraints directly on the signature.
            string sasContainerToken = blob.GetSharedAccessSignature(sasConstraints);
            return sasContainerToken;
        }
    }
}
