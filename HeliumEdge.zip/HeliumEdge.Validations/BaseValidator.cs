﻿using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;
using HeliumEdge.Exception;
using HeliumEdge.DataTransfer.ATS;
using HeliumEdge.Common.ValidationAttributes;
using System.Linq;

namespace HeliumEdge.Validations
{
    public abstract class BaseValidator : IBaseValidator
    {
        protected ICollection<ValidationResult> validationResult;
        private Dictionary<string,string> _errors;
        public bool ValidateAttributes(object obj)
        {
            ValidationContext validationContext = new ValidationContext(obj);
            validationResult = new List<ValidationResult>();
            return Validator.TryValidateObject(obj, validationContext, validationResult, true);            
        }

        public abstract void Validate(BaseDTO obj);

        protected void ThrowErrors(BaseDTO obj)
        {
            ParseErrors();
            throw new CustomValidationException("Validation Error!!", _errors, obj);
        }
        protected void ThrowErrors()
        {
            ParseErrors();
            throw new CustomValidationException("Validation Error!!", _errors);
        }
        private void ParseErrors()
        {
            _errors = new Dictionary<string, string>();

            foreach (var result in validationResult)
            {
                if (result.GetType() == typeof(ValidationResult))
                {
                    foreach (var member in result.MemberNames)
                    {
                        _errors.TryAdd(member, result.ErrorMessage);
                    }
                }
                if (result.GetType() == typeof(CompositeValidationResult))
                {
                    var compResult = (CompositeValidationResult)result;
                    foreach (var error in compResult.Errors)
                    {
                        _errors.TryAdd(error.Key, error.Value);
                    }
                }
            }
        }
    }
}
