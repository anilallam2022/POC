﻿using HeliumEdge.DataTransfer.ATS;
using System;
using System.Collections.Generic;
using System.Text;

namespace HeliumEdge.Validations
{
    public class ValidatorProvider
    {
        private static readonly IDictionary<Type, IBaseValidator> ValidatorMappers = new Dictionary<Type, IBaseValidator>()
        {
            {typeof(CompanyDTO), new CompanyValidator() },
            {typeof(ContactDTO), new ContactValidator() },
            {typeof(JobDTO), new JobValidator() },
            {typeof(CandidateDTO), new CandidateValidator() },
            {typeof(NoteDTO), new NoteValidator() },
            {typeof(ReminderDTO), new ReminderValidator() },
            {typeof(TaskDTO), new TaskValidator() },
            {typeof(EventDTO), new EventValidator() },

        };
        public static IBaseValidator GetValidatorInstance<T>() where T : BaseDTO
        {
            return ValidatorMappers[typeof(T)];
        }

    }
}
