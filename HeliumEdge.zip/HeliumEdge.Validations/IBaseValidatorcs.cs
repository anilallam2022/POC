﻿using System;
using System.Collections.Generic;
using System.Text;
using HeliumEdge.DataTransfer.ATS;

namespace HeliumEdge.Validations
{
    public interface IBaseValidator
    {
        void Validate(BaseDTO obj);
    }
}
