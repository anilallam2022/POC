﻿using HeliumEdge.DataTransfer.ATS;

namespace HeliumEdge.Validations
{
    public class TaskValidator : BaseValidator
    {
        public TaskValidator()
        {
            
        }
        public override void Validate(BaseDTO obj)
        {
            ValidateAttributes(obj);
            //Queue your custom validation methods here
            if (validationResult.Count > 0)
                ThrowErrors();
        }


    }
}
