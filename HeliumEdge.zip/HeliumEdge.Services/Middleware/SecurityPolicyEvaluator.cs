﻿using HeliumEdge.Common;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authorization.Policy;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Caching.Memory;
using Newtonsoft.Json.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace HeliumEdge.Services.Middleware
{
    public class SecurityPolicyEvaluator : IPolicyEvaluator
    {
        private readonly IMemoryCache cache;

        public SecurityPolicyEvaluator(IMemoryCache cache)
        {
            this.cache = cache;
        }
        public virtual async Task<AuthenticateResult> AuthenticateAsync(AuthorizationPolicy policy, HttpContext context)
        {
            var authorizationHeader = context.Request.Headers["Authorization"].ToString();
            var authorizationHeaderArray = authorizationHeader.Split(" ");
            var responseJson = JObject.Parse(authorizationHeaderArray[1]);
            var token = (string)responseJson["token"];
            var securityKey = cache.Get<string>(token);
            var role = TokenHelper.GetRoleFromToken(token, securityKey);

            //TODO: Decode JWT to get the claims object.


            var claimsIdentity = new ClaimsIdentity(
                new Claim[] {
                    new Claim(ClaimTypes.Role, string.IsNullOrEmpty(role) ? string.Empty: role)
                },
                "DefaultScheme");

            var principal = new ClaimsPrincipal();
            principal.AddIdentity(claimsIdentity);

            context.User.AddIdentity(claimsIdentity);

            return AuthenticateResult.Success(new AuthenticationTicket(principal,
                new AuthenticationProperties(), "DefaultScheme"));
        }

        public virtual async Task<PolicyAuthorizationResult> AuthorizeAsync(AuthorizationPolicy policy, AuthenticateResult authenticationResult, HttpContext context, object resource)
        {
            foreach(var claim in authenticationResult.Principal.Claims)
            {
                var p = claim.Value;
            }
            
            return PolicyAuthorizationResult.Success();
        }

        public virtual async Task<PolicyAuthorizationResult> AuthorizeAsync(AuthorizationPolicy policy, AuthenticateResult authenticationResult, HttpContext context)
        {
            return PolicyAuthorizationResult.Success();
        }
    }
}
