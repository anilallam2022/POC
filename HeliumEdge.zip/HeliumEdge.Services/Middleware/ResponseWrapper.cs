﻿using HeliumEdge.Core;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System;
using System.IO;
using System.Threading.Tasks;

namespace HeliumEdge.Services.Middleware
{
    public class ResponseWrapper
    {
        private readonly RequestDelegate _next;
        public ResponseWrapper(RequestDelegate next)
        {
            _next = next;
        }
        public async Task Invoke(HttpContext context)
        {
            var currentBody = context.Response.Body;

            using (var memoryStream = new MemoryStream())
            {
                context.Response.Body = memoryStream;
                await _next(context).ConfigureAwait(false);

                context.Response.Body = currentBody;
                memoryStream.Seek(0, SeekOrigin.Begin);

                var readToEnd = new StreamReader(memoryStream).ReadToEnd();
                var objResult = JsonConvert.DeserializeObject(readToEnd);

                var result = new ResponseMetadata()
                {
                    Version = "1.0",
                    Content = objResult,
                    Timestamp = DateTime.UtcNow,
                    StatusCode = context.Response.StatusCode,
                    Size = context.Response.ContentLength
                };
                
                await context.Response.WriteAsync(JsonConvert.SerializeObject(result)).ConfigureAwait(false);
            }
        }
    }
    public static class ResponseWrapperExtensions
    {
        public static IApplicationBuilder UseResponseWrapper(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<ResponseWrapper>();
        }
    }
}
