﻿using HeliumEdge.BusinessObjects.ATS;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;

namespace HeliumEdge.Services.Controllers
{
    [Produces("application/json")]
    [Route("api/Gateway")]
    public class GatewayController : Controller
    {
        //private readonly IHostingEnvironment _hostingEnvironment;
        private readonly SecurityManager securityManager;
        private readonly CandidateManager candidateManager;

        public GatewayController(SecurityManager securityManager)
        {
            this.securityManager = securityManager;
        }

        [Authorize(Policy = "RequireAdministratorRole")]
        [HttpGet(Name = "GetAllRecords")]
        public IEnumerable<string> GetAllRecords()
        {
            var currentUser = HttpContext.User;

            if (currentUser.HasClaim(c => c.Type == ClaimTypes.Role))
            {
                var role = currentUser.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Role).Value;

                if (role.Equals("Administrator"))
                    return new string[] { "HeliumEdge", "This is an Admin user." };
            }

            return new string[] { "HeliumEdge", "This is a normal user." };
        }
    }
}
