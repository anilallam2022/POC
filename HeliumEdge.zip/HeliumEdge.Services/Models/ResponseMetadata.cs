﻿////using System;
////using System.Net;

////namespace HeliumEdge.Services.Models
////{
////    public class ResponseMetadata
////    {
////        public string Version { get; set; }
////        public int StatusCode { get; set; }
////        public string ErrorMessage { get; set; }
////        public object Content { get; set; }
////        public DateTime Timestamp { get; set; }
////        public long? Size { get; set; }
////    }
////}
