﻿using System.Collections.Generic;

namespace HeliumEdge.Services.Models
{
    //public class SecurityModel
    //{
    //    public string Token { get; set; }
    //    public List<string> Roles { get; set; }
    //}
}
