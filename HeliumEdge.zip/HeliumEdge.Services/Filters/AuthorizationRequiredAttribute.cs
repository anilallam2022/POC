﻿using Microsoft.AspNetCore.Mvc.Filters;
using System.Threading.Tasks;

namespace HeliumEdge.Services.Filters
{
    public class AuthorizationRequiredAttribute : IAsyncActionFilter
    {
        public async Task OnActionExecutionAsync(ActionExecutingContext context,
            ActionExecutionDelegate next)
        {
            //To do : before the action executes  
            await next().ConfigureAwait(false);
            //To do : after the action executes  
        }
    }
}
