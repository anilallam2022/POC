﻿
////namespace HeliumEdge.Services.Security
////{
////    using Microsoft.AspNetCore.Authorization;
////    public class AdministratorRoleRequirement : IAuthorizationRequirement
////    {
////        public string Role { get; private set; }

////        public AdministratorRoleRequirement(string role)
////        {
////            Role = role;
////        }
////    }
////}
