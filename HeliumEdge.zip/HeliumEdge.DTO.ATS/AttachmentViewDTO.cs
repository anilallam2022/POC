﻿namespace HeliumEdge.DataTransfer.ATS
{
    public class AttachmentViewDTO
    {
        public string FileName { get; set; }
        public byte[] Content { get; set; }
    }

}
