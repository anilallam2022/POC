﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HeliumEdge.DataTransfer.ATS
{
    //TODO: may need to change the class name to some meaningful name
    public class EntitiesStatusDTO
    {
        public IEnumerable<int> EntityIds { get; set; }
        public int NewStatusId { get; set; }
    }
}
