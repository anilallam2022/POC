﻿namespace HeliumEdge.DataTransfer.ATS
{
    public class ListPageColumnDTO
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string DisplayText { get; set; }
        public bool IsLocked { get; set; }
    }
}
