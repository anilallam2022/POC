﻿using System.ComponentModel.DataAnnotations;
namespace HeliumEdge.DataTransfer.ATS
{
    public class PhoneNumberDTO 
    {
        public int Id { get; set; }
        public string CountryCode { get; set; }
        [Phone]
        public string PhoneNumber { get; set; }
        public string Extension { get; set; }
        public int? TypeId { get; set; }
    }
}
