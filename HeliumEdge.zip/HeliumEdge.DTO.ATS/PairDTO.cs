﻿namespace HeliumEdge.DataTransfer.ATS
{
    public class PairDTO
    {        
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
