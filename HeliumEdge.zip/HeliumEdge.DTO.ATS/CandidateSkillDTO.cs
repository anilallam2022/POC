﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HeliumEdge.DataTransfer.ATS
{
    public class CandidateSkillDTO
    {
        public int Id { get; set; }
        public string Skill { get; set; }
        public int YearsOfExp { get; set; }
    }
}
