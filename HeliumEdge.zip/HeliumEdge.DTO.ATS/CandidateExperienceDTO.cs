﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HeliumEdge.DataTransfer.ATS
{
    public class CandidateExperienceDTO
    {
        public int Id { get; set; }
        public string Employer { get; set; }
        public string Role { get; set; }
        public string Responsibilities { get; set; }
        public string Remarks { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string Location { get; set; }
        public bool CurrentlyWorking { get; set;}
    }
}
