﻿using System;
using System.Collections.Generic;

namespace HeliumEdge.DataTransfer.ATS
{
    public class ContactViewDTO : ContactBaseDTO
    {
        public int? CompanyId { get; set; }
        public string CompanyName { get; set; }
        public string ContactOwner { get; set; }
        public string Types { get; set; }
        public string PreferredMethodOfContact { get; set; }
        public string Department { get; set; }
        public int? DepartmentId { get; set; }
        public string Suorce { get; set; }
        public int? SourceId { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public AttachmentDTO Photo { get; set; }
        public ICollection<PhoneNumberViewDTO> PhoneNumbers { get; set; }
        public ICollection<EmailViewDTO> Emails { get; set; }
        public ICollection<WebAddressViewDTO> WebAddresses { get; set; } 
        public ICollection<AddressViewDTO> Addresses { get; set; }
        public string RoleName { get; set; }
    }
}
