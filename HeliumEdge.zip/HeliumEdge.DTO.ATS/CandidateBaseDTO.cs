﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace HeliumEdge.DataTransfer.ATS
{
    public abstract class CandidateBaseDTO: BaseDTO
    {
        public int Id { get; set; }
        private int TenantId { get; set; }
        [MaxLength(50, ErrorMessage = "The field First Name must be a string type with a maximum length of '50'.")]
        public string FirstName { get; set; }
        [MaxLength(50, ErrorMessage = "The field Middle Name must be a string with a maximum length of '50'.")]
        public string MiddleName { get; set; }
        [MaxLength(50, ErrorMessage = "The field Last Name must be a string with a maximum length of '50'.")]
        public string LastName { get; set; }
        [MaxLength(200, ErrorMessage = "The field Profile Title must be a string with a maximum length of '200'.")]
        public string ProfileTitle { get; set; }        
        public string Fax { get; set; }        
        public string LinkedInId { get; set; }
        public string SkypeId { get; set; }
        public string FacebookId { get; set; }
        public int? Rating { get; set; }
        public string RatingComment { get; set; }
        public bool Relocate { get; set; }
        
        public string DesiredEmploymentTypes { get; set; }
        public double? DesiredSalary { get; set; }
        public string DesiredLocation { get; set; }

        public int? ExperienceLevelId { get; set; }
        public int? VisaStatusId { get; set; }
        public int? AvailabilityId { get; set; }
        public int? CandidateSourceId { get; set; }
        public int? CandidateOwnerId { get; set; }
        public int? TravelPreferencesId { get; set; }        
        
        public ICollection<string> Tags { get; set; }
        public string Description { get; set; }
    }
}
