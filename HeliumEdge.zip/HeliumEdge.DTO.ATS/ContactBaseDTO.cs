﻿using System.Collections.Generic;

namespace HeliumEdge.DataTransfer.ATS
{
    public abstract class ContactBaseDTO : BaseDTO
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string PreferredTimeToContact { get; set; }
        public bool IsPrivateContact { get; set; }
        public string LinkedInId { get; set; }
        public string SkypeId { get; set; }
        public string FacebookId { get; set; }
        public string Description { get; set; }
        public int? ContactOwnerId { get; set; }
        public ICollection<string> Tags { get; set; }
    }
}
