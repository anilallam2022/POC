﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using HeliumEdge.Common.ValidationAttributes;

namespace HeliumEdge.DataTransfer.ATS
{
    public class CompanyDTO : BaseDTO
    {
        public int Id { get; set; }
        //private int TenantId { get; set; }
        [Required]
        public string CompanyName { get; set; }
        public int? IndustryId { get; set; }
        public string WebsiteUrl { get; set; }
        public string LinkedInId { get; set; }
        public string FacebookId { get; set; }
        public bool Priority { get; set; }
        public int[] EmploymentTypeIds { get; set; }
        public int? PaymentTermsId { get; set; }
        public decimal PlacementFee { get; set; }
        public int? FeeTypeId { get; set; }
        public int[] CompanyTypeIds { get; set; }
        public int? AccountOwnerId { get; set; }
        public string Description { get; set; }
        public int? StatusId { get; set; }
        public ICollection<string> Tags { get; set; }
        public ICollection<CompanyContactDTO> CompanyContact { get; set; }
        public ICollection<AddressDTO> Addresses { get; set; }
        [ValidateObject]
        public ICollection<EmailDTO> Emails { get; set; }
        public ICollection<PhoneNumberDTO> PhoneNumbers { get; set; }
        public AttachmentDTO Logo { get; set; }

    }
    
}
