﻿namespace HeliumEdge.DataTransfer.ATS
{
    public class WebAddressDTO
    {
        public int Id { get; set; }
        public string Url { get; set; }
        public int? TypeId { get; set; }
    }
}
