﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HeliumEdge.DataTransfer.ATS
{
    public class CompanyViewDTO
    {
        public string CompanyName { get; set; }
        public string CompanyLogo { get; set; }
        public string Location { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string Website { get; set; }
        public string PaymentTerms { get; set; }
        public decimal PlacementFee { get; set; }
        public string PlacementFeeType { get; set; }
        public string PrimaryContact { get; set; }
        public string Status { get; set; }
        public string FacebookId { get; set; }
        public string LinkedinId { get; set; }
        public ICollection<string> EmployementTypes { get; set; }
        public ICollection<string> CompanyTypes { get; set; }
        public ICollection<string> Tags { get; set; }
    }
}
