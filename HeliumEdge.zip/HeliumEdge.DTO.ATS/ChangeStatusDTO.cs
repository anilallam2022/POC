﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HeliumEdge.DataTransfer.ATS
{
    public class ChangeStatusDTO
    {
        public List<int> SelectedIds { get; set; }
        public int StatusId { get; set; }
        public string CategoryName { get; set; }
        public string Reason { get; set; }

    }
}
