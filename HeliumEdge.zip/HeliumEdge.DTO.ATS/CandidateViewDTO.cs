﻿using System.Collections.Generic;

namespace HeliumEdge.DataTransfer.ATS
{
    public class CandidateViewDTO : CandidateBaseDTO
    {
        public ICollection<EmailViewDTO> Emails { get; set; }
        public ICollection<PhoneNumberViewDTO> PhoneNumbers { get; set; }
        public ICollection<AddressViewDTO> Addresses { get; set; }
        public string CandidateSource { get; set; }
        public string CandidateOwner { get; set; }
        public string VisaStatus { get; set; }
        public string ExperienceLevel { get; set; }
        public string Availability { get; set; }
        public string TravelPreferences { get; set; }
        public AttachmentDTO Photo { get; set; }
        public AttachmentDTO Resume { get; set; }
        public ICollection<WebAddressViewDTO> WebAddresses { get; set; }
        public ICollection<CandidateEducationDTO> Educations { get; set; }
        public ICollection<CandidateSkillDTO> Skills { get; set; }
        public ICollection<CandidateCertificateDTO> Certifications { get; set; }
    }
}
