﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace HeliumEdge.DataTransfer.ATS
{
    public class JobDTO: BaseDTO
    {
        public int Id { get; set; }
        private int? TenantId { get; set; }
        public string OrderId { get; set; }
        public bool CanTeleCommute { get; set; }
        public int? HiringCompanyId { get; set; }
        [MaxLength(100, ErrorMessage = "The field Title must be a string type with a maximum length of '100'.")]
        public string Title { get; set; }
        public string Description { get; set; }
        public string Requirement { get; set; }
        public ICollection<int?> EmploymentTypeIds { get; set; }
        [Range(1,99,ErrorMessage = "The field No. of openings must be between 1 and 99")]
        public int? NoOfOpenings { get; set; }
        public int? StatusId { get; set; }
        public int? PriorityId { get; set; }
        public int? ExperienceLevelId { get; set; }
        public double? SalaryFrom { get; set; }
        public double? SalaryTo { get; set; }
        public int? SalaryUnitId { get; set; }
        public int? TravelRequirementId { get; set; }
        public DateTime? StartDate { get; set; }
        public float? Duration { get; set; }
        public int? DurationUnitId { get; set; }
        public int? IndustryId { get; set; }
        public int? DepartmentId { get; set; }
        public double? PlacementFee { get; set; }
        public int? PlacementFeeTypeId { get; set; }
        public ICollection<string> Tags { get; set; }
        public ICollection<LocationDTO> Locations { get; set; }
        public ICollection<int?> PrimaryContactIds { get; set; }
        public ICollection<int?> AssignedRecruiterIds { get; set; }
        public int? AccountManagerId { get; set; }
    }
}

public class LocationDTO   
{
    public string Location { get; set; }
}