﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HeliumEdge.DataTransfer.ATS
{
    public class CandidateDTO : CandidateBaseDTO
    {
        public AttachmentDTO Resume { get; set; }
        public ICollection<AddressDTO> Addresses { get; set; }
        public ICollection<EmailDTO> Emails { get; set; }
        public ICollection<PhoneNumberDTO> PhoneNumbers { get; set; }        
        public AttachmentDTO Photo { get; set; }
        public ICollection<WebAddressDTO> WebAddresses { get; set; }  //TODO: Why ContactAddressDTO refered here?
        public ICollection<CandidateCertificateDTO> CandidateCertificates { get; set; }
        public ICollection<CandidateEducationDTO> CandidateEducations { get; set; }
        public ICollection<CandidateExperienceDTO> CandidateExperiences { get; set; }
        public ICollection<CandidateSkillDTO> CandidateSkills { get; set; }
    }    
}
