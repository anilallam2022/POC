﻿namespace HeliumEdge.DataTransfer.ATS
{
    public class EmailViewDTO : EmailDTO
    {
        public string Type { get; set; }
    }

}
