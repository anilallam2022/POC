﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace HeliumEdge.DataTransfer.ATS
{
    public class CompanyContactDTO
    {
        public int Id { get; set; }
        public int? CompanyId { get; set; }
        public int? ContactId { get; set; }
        public string Role { get; set; }
        public int? DepartmentId { get; set; }        
    }
}
