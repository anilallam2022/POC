﻿namespace HeliumEdge.DataTransfer.ATS
{
    public class WebAddressViewDTO : WebAddressDTO
    {
        public string Type { get; set; }
    }

}
