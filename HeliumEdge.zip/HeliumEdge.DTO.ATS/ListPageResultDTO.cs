﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HeliumEdge.DataTransfer.ATS
{
    public class ListPageResultDTO
    {
        public int TotalRecordsCount { get; set; }
        public ICollection<dynamic> FieldData { get; set; }

        public dynamic Header { get; set; }
    }
}
