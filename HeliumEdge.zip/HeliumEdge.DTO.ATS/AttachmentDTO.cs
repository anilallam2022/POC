﻿
using Newtonsoft.Json;

namespace HeliumEdge.DataTransfer.ATS
{
    public class AttachmentDTO
    {
        public int Id { get; set; }
        public string FileName { get; set; }
        [JsonIgnore]
        public string Type { get; set; }
        public string StorageFileName { get; set; }
        [JsonIgnore]
        public string FilePath { get; set; }
    }
}
