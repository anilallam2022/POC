﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HeliumEdge.DataTransfer.ATS
{
    public class JobViewDTO
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public int? CompanyId { get; set; }//
        public string CompanyName { get; set; }
        public int? NoOfOpenings { get; set; }
        public string Status { get; set; }//
        public string Priority { get; set; }//
        public DateTime? StartDate { get; set; }
        public  string Duration { get; set; }//
        public ICollection<string> Locations { get; set; }
        public ICollection<string> EmploymentTypes { get; set; }//
        public string ExperienceLevel { get; set; }//
        public bool TeleCommute { get; set; }
        public double? SalaryFrom { get; set; }
        public double? SalaryTo { get; set; }
        public string SalaryUnit { get; set; }//
        public ICollection<string> PrimaryContactNames { get; set; }//
    }
}
