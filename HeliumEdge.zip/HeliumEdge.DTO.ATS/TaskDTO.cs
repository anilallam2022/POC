﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HeliumEdge.DataTransfer.ATS
{
    public abstract class TaskBaseDTO: BaseDTO
    {
        public int Id { get; set; }
        public int? TypeId { get; set; }
        public string Title { get; set; }
        public int? AssignedToUserId { get; set; }
        public int? PriorityId { get; set; }
        public DateTime? TaskDateTime { get; set; }
        public bool IsRepeat { get; set; }
        public int? RepeatFrequencyId { get; set; }
        public int?[] WeekDays { get; set; }
        public int? WeekFrequency { get; set; }
        public int?[] MonthDates { get; set; }
        public int?[] YearMonths { get; set; }
        public int?[] YearMonthDates { get; set; }
        public DateTime? EndDate { get; set; }
        public int? ReminderInMinutesId { get; set; }
        public string Description { get; set; }
        public ICollection<AttachmentDTO> Attachments { get; set; }
    }

    public class TaskDTO : TaskBaseDTO
    {
        public ICollection<TagDTO> Tags { get; set; }
    }
    public class TaskViewDTO : TaskBaseDTO
    {
        public ICollection<TagViewDTO> Tags { get; set; }
    }
}
