﻿using System.Collections.Generic;

namespace HeliumEdge.DataTransfer.ATS
{
    public class ContactDTO : ContactBaseDTO
    {
        public int[] ContactTypeIds { get; set; }
        public int[] PreferredMethodOfContactIds { get; set; }
        public int? ContactSourceId { get; set; }
        public ICollection<AddressDTO> Addresses { get; set; }
        public ICollection<PhoneNumberDTO> PhoneNumbers { get; set; }
        public ICollection<WebAddressDTO> WebAddresses { get; set; }
        public ICollection<EmailDTO> Emails { get; set; }
        public CompanyContactDTO CompanyContact { get; set; }
        public AttachmentDTO Photo { get; set; }
        public int? StatusId { get; set; }
    }
}
