﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HeliumEdge.DataTransfer.ATS
{
    public abstract class ReminderBaseDTO : BaseDTO
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public DateTime Date { get; set; }
        public string RemindBefore { get; set; }
        public string Description { get; set; }
    }
    public class ReminderDTO : ReminderBaseDTO
    {
        public ICollection<TagDTO> Tags { get; set; }
    }
    public class ReminderViewDTO : ReminderBaseDTO
    {
        public ICollection<TagViewDTO> Tags { get; set; }
    }
}
