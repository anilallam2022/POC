﻿namespace HeliumEdge.DataTransfer.ATS
{
   public class AddressDTO
    {
        public int Id { get; set; }
        public string Address { get; set; }
        public int? TypeId { get; set; }       
    }
}
