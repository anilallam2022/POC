﻿using System.Collections.Generic;

namespace HeliumEdge.DataTransfer.ATS
{
    public class TagViewDTO
    {
        public int Id { get; set; }
        public string Type { get; set; }  //TODO: make sure to validate this property during model validation
        public IEnumerable<PairDTO> ReferenceItems { get; set; }
    }
}
