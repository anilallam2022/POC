﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HeliumEdge.DataTransfer.ATS
{
    public abstract class NoteBaseDTO: BaseDTO
    {
        public int Id { get; set; }
        public int[] TypeIds { get; set; }
        public string Description { get; set; }
        public ICollection<AttachmentDTO> Attachments { get; set; }
    }

    public class NoteDTO : NoteBaseDTO
    {
        public ICollection<TagDTO> Tags { get; set; }
    }

    public class NoteViewDTO: NoteBaseDTO
    {
        public ICollection<TagViewDTO> Tags { get; set; }
    }
}
