﻿namespace HeliumEdge.DataTransfer.ATS
{
    public class ListPageRequestDTO
    {
        /// <summary>
        /// Id of user specific list view. Send 0 if no view Id avaialble
        /// </summary>
        public int ViewId { get; set; }
        /// <summary>
        /// Entity name
        /// </summary>
        private string Entity { get; set; }
        /// <summary>
        /// Number of items per page
        /// </summary>
        public int? PageSize { get; set; } = 10;
        /// <summary>
        /// Page number to view
        /// </summary>
        public int? PageNumber { get; set; } = 0;
        /// <summary>
        /// Field name on which need to perform sorting
        /// </summary>
        public string SortColumn { get; set; }
        /// <summary>
        /// Sort order to perform - Options should be ASC or DESC
        /// </summary>
        public string SortOrder { get; set; }
        public void SetEntityType(string name)
        {
            this.Entity = name;
        }
        public string GetEntityType()
        {
            return Entity;
        }
    }
}
