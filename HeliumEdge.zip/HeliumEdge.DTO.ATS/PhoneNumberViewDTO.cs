﻿namespace HeliumEdge.DataTransfer.ATS
{
    public class PhoneNumberViewDTO : PhoneNumberDTO
    {
        public string Type { get; set; }
    }

}
