﻿namespace HeliumEdge.DataTransfer.ATS
{
    public class AddressViewDTO : AddressDTO
    {
        public string Type { get; set; }
    }

}
