﻿using System.ComponentModel.DataAnnotations;

namespace HeliumEdge.DataTransfer.ATS
{
    public class EmailDTO
    {
        public int Id { get; set; }
        [EmailAddress]
        public string Email { get; set; }
        public int? TypeId { get; set; }
    }
}
