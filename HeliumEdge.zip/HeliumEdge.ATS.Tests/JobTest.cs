﻿using HeliumEdge.BusinessObjects.ATS;
using HeliumEdge.DataTransfer.ATS;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HeliumEdge.ATS.Tests
{
    [TestClass]
    public class JobTest
    {
        JobManager manager = new JobManager(new DataAccess.ATS.JobRepository(DbContextTestHelper.Instance));
        [TestMethod]
        public async Task GetAllJobsTest()
        {
            
            var jobFilter = new ListPageRequestDTO { PageNumber = 1, PageSize = 10 };
            jobFilter.SetEntityType("Jobs");
            var result = await manager.GetAllAsync(jobFilter).ConfigureAwait(false);
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task GetSpecificJobTest()
        {
            int jobId = 1;
            var result = await manager.GetAsync(jobId).ConfigureAwait(false);

            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task CreateJobTest()
        {
            JobDTO dto = new JobDTO
            {
                OrderId = "01",
                Title = "Software Developer",
                CanTeleCommute = true,
                HiringCompanyId = 1,
                AccountManagerId = 1,
                EmploymentTypeIds = new List<int?>() {1, 2 },
                NoOfOpenings = 5,
                StatusId = 1,
                PriorityId = 1,
                ExperienceLevelId = 1,
                SalaryFrom = 1500,
                SalaryTo = 2000,
                SalaryUnitId = 1,
                TravelRequirementId = 1,
                StartDate = DateTime.Now,
                Duration = 1.5F,
                DurationUnitId = 1,
                IndustryId = 1,
                DepartmentId = 1,
                PlacementFee = 20.5F,
                PlacementFeeTypeId = 1,
                Description = "Software Developer",
                Requirement = "Software Developer",
                Tags = new string[] { "tag1", "tag2" },
                Locations =   new List<LocationDTO> { 
                    new LocationDTO() { Location =  "Location1" },
                    new LocationDTO() { Location =  "Location2" }
                    },
                AssignedRecruiterIds = new int?[] { 2, 3 },
                PrimaryContactIds = new int?[] { 4, 5 }
            };

            var result = await manager.CreateAsync(dto).ConfigureAwait(false);

            Assert.IsTrue(result);
        }

        [TestMethod]
        public async Task DeleteJobs()
        {
            List<int> ids = new List<int>() { 8, 20, 21 };
            var result = await manager.Delete(ids).ConfigureAwait(false);
            Assert.IsTrue(result);
        }

        [TestMethod]
        public async Task GetJobList()
        {
            ListPageRequestDTO listPage = new ListPageRequestDTO() { PageNumber = 1, PageSize = 86, SortColumn = "Id", SortOrder = "ASC", ViewId = 1 };
            listPage.SetEntityType("Job");
            var result = await manager.GetAllAsync(listPage).ConfigureAwait(false);
            Assert.IsNotNull(result);
        }

        
        [TestMethod]
        public async Task GetViewListItems()
        {
            var result = await manager.GetViewListItems(4).ConfigureAwait(false);
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task GetDuplicateCheck()
        {
            var result = await manager.GetDuplicateCheckAsync("Job title new", 8).ConfigureAwait(false);
            Assert.IsTrue(result);
        }


        [TestMethod]
        public async Task GetClone()
        {
            var result = await manager.GetCloneAsync(8).ConfigureAwait(false);
            Assert.IsNull(result);
        }


        [TestMethod]
        public async Task StatusJobs()
        {
            ChangeStatusDTO changestatus = new ChangeStatusDTO();
            changestatus.SelectedIds = new List<int>() { 8, 20, 21 };
            changestatus.CategoryName = "Status";
            changestatus.StatusId = 1;
            var result = await manager.Status(changestatus).ConfigureAwait(false);
            Assert.IsTrue(result);
        }

        [TestMethod]
        public async Task GetContactsByCompany()
        {
            var result = await manager.GetCompanyDetailsById(1).ConfigureAwait(false);
            Assert.IsNull(result);
        }

        [TestMethod]
        public async Task GetJobView()
        {
            var result = await manager.GetView(1).ConfigureAwait(false);
            Assert.IsNull(result);
        }
    }
}
