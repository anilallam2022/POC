﻿using HeliumEdge.BusinessObjects.ATS;
using HeliumEdge.DataObjects.ATS;
using HeliumEdge.DataTransfer.ATS;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace HeliumEdge.ATS.Tests
{
    public class TaskTest
    {
        TaskManager manager;

        public TaskTest()
        {
            manager = new TaskManager(new DataAccess.ATS.TaskRepository(DbContextTestHelper.Instance), null);
        }

        [Fact]
        public async Task GetAllTasksTest()
        {
            var result = await manager.GetAllAsync().ConfigureAwait(false);
            Assert.NotNull(result);
        }

        [Fact]
        public async Task GetSpecificTaskTest()
        {
            var result = await manager.GetAsync(50).ConfigureAwait(false);
            Assert.NotNull(result);
        }

        [Fact]
        public async Task CreateTaskTest()
        {
            var dto = new TaskDTO
            {
                Title = "Task",
                TypeId = 361,
                AssignedToUserId = 1,
                PriorityId = 50,
                IsRepeat = false,
                TaskDateTime = DateTime.Now,
                ReminderInMinutesId = 355,
                Description = "Task Description",
                EndDate = Convert.ToDateTime("01/01/1900"),
                Tags = new List<TagDTO> {
                    new TagDTO { Type="Company",ReferenceIds=new int[]{1,2 } },
                    new TagDTO { Type="Contact",ReferenceIds=new int[]{1,2 } },
                    new TagDTO { Type="Candidate",ReferenceIds=new int[]{1,2 } }
                }
            };
            var result = await manager.CreateAsync(dto).ConfigureAwait(false);
            Assert.True(result);
        }

        [Fact]
        public async Task CreateTaskTestWithRepeatOn()
        {
            var dto = new TaskDTO
            {
                Title = "Task",
                TypeId = 361,
                AssignedToUserId = 1,
                PriorityId = 50,
                IsRepeat = true,
                TaskDateTime = Convert.ToDateTime("01/01/1900"),
                ReminderInMinutesId = 355,
                Description = "Task Description",
                RepeatFrequencyId = 3, //Monthly
                WeekDays = null,
                MonthDates = new int?[] { 1, 3, 25, 26, 30 }, // Need to handle February date stuff from code.
                YearMonths = null,
                YearMonthDates = null,
                EndDate = Convert.ToDateTime("01/01/2019"),
                Tags = new List<TagDTO>
                {
                    new TagDTO { Type="Company",ReferenceIds=new int[]{1,2 } },
                    new TagDTO { Type="Contact",ReferenceIds=new int[]{1,2 } },
                    new TagDTO { Type="Candidate",ReferenceIds=new int[]{1,2 } }
                }
            };
            var result = await manager.CreateAsync(dto).ConfigureAwait(false);
            Assert.True(result);
        }
    }
}
