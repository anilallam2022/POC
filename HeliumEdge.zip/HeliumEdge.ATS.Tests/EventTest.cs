﻿using HeliumEdge.BusinessObjects.ATS;
using HeliumEdge.DataTransfer.ATS;
using System;
using System.Collections.Generic;
using Xunit;

namespace HeliumEdge.ATS.Tests
{
    public class EventTest
    {
        EventManager manager = new EventManager(new DataAccess.ATS.EventRepository(DbContextTestHelper.Instance));
        [Fact]
        public async void GetAllEventsTest()
        {
            var result = await manager.GetAllAsync().ConfigureAwait(false);

            Assert.NotNull(result);
        }

        [Fact]
        public async void GetSpecificEventTest()
        {
            int eventId = 7;
            var result = await manager.GetAsync(eventId).ConfigureAwait(false);
            Assert.NotNull(result);
        }

        [Fact]
        public async void AddEventTest()
        {
            var dto = new EventDTO
            {
                Title = "New Event",
                EventTypeId= 1159,
                InterviewTypeId=0,
                Description = "New Event Description",
                StartDate = DateTime.Now,
                EndDate = DateTime.Now,
                Tags = new List<TagDTO> {
                    new TagDTO { Type="Company",ReferenceIds=new int[]{1,2 } },
                    new TagDTO { Type="Contact",ReferenceIds=new int[]{1,2 } },
                    new TagDTO { Type="Candidate",ReferenceIds=new int[]{1,2 } }
                }
            };

            var result = await manager.CreateAsync(dto).ConfigureAwait(false);
            Assert.NotNull(result);
        }
    }
}
