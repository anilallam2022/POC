﻿using HeliumEdge.BusinessObjects.ATS;
using HeliumEdge.DataObjects.ATS;
using HeliumEdge.DataTransfer.ATS;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeliumEdge.ATS.Tests
{
    [TestClass]
    public class CompanyTest
    {
        CompanyManager manager = new CompanyManager(new DataAccess.ATS.CompanyRepository(DbContextTestHelper.Instance), new DataAccess.ATS.MasterDataRepository(DbContextTestHelper.Instance));

        [TestMethod]
        public async Task GetCompanyListTest()
        {
            var compFilter = new ListPageRequestDTO { PageNumber = 1, PageSize = 10, ViewId = 0, SortColumn = "Id", SortOrder = "DESC" };
            compFilter.SetEntityType("Company");
            var result = await manager.GetAllAsync(compFilter).ConfigureAwait(false);
            Assert.IsNotNull(result.FieldData.ToList());
        }

        [TestMethod]
        public async Task GetSpecificCompanyTest()
        {
            int Id = 1;
            var result = await manager.GetAsync(Id).ConfigureAwait(false);

            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task AddCompanyTest()
        {
            var dto = new CompanyDTO
            {
                AccountOwnerId = 1,
                CompanyTypeIds = new int[] { 70, 71 },
                CompanyName = "HeliumEdge",
                Description = "Description",
                EmploymentTypeIds = new int[] { 168, 169 },
                FacebookId = "Facebook!",
                FeeTypeId = 186,
                IndustryId = 195,
                LinkedInId = "Lindin!",
                PlacementFee = Convert.ToDecimal(78.00),
                PaymentTermsId = 264,
                Priority = true,
                Tags = new string[] { "sad", "asd", "asda" },
                WebsiteUrl = "wwww.ggoggg.ccom",
                PhoneNumbers = new List<PhoneNumberDTO>
                {
                    new PhoneNumberDTO() { CountryCode="91", PhoneNumber = "2312", Extension = "223", TypeId=275},
                    new PhoneNumberDTO() { CountryCode="91", PhoneNumber = "2312123", Extension = "33", TypeId=274 }
                },
                Emails = new List<EmailDTO>
                {
                    new EmailDTO(){ Email = "abc@gmail.com", TypeId = 2, },
                    new EmailDTO(){ Email = "xyz@yahoo.com", TypeId = 2, }
                },
                Addresses = new List<AddressDTO>
                {
                    new AddressDTO(){ Address = "Address1"},
                    new AddressDTO(){ Address = "Address1" }
                }

            };
            var result = await manager.CreateAsync(dto).ConfigureAwait(false);

            Assert.IsTrue(result);
        }

        [TestMethod]
        public async Task DeleteCompany()
        {
            List<int> ids = new List<int>() { 1, 2, 3 };
            var result = await manager.Delete(ids).ConfigureAwait(false);
            Assert.IsTrue(result);
        }

        [TestMethod]
        public async Task GetPlacementFee()
        {
            int id = 1;
            var result = await manager.GetPlacementFee(id).ConfigureAwait(false);
            Assert.IsTrue(result > 0 || result != null);
        }

        [TestMethod]
        public async Task ChangeStatus()
        {
            EntitiesStatusDTO dto = new EntitiesStatusDTO
            {
                EntityIds = new List<int> { 18, 31 },
                NewStatusId = 1490
            };
            var result = await manager.ChangeStatusAsync(dto).ConfigureAwait(false);
            Assert.IsTrue(result);
        }

    }
}
