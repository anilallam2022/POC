﻿using HeliumEdge.BusinessObjects.ATS;
using HeliumEdge.DataObjects.ATS;
using HeliumEdge.DataTransfer.ATS;
using System.Collections.Generic;
using Xunit;

namespace HeliumEdge.ATS.Tests
{
    public class NoteTest
    {
        NoteManager manager;
        public NoteTest()
        {
            manager = new NoteManager(new DataAccess.ATS.NoteRepository(DbContextTestHelper.Instance), null);
        }

        [Fact]
        public async void GetAllNotesTest()
        {
            var result = await manager.GetAllAsync().ConfigureAwait(false);
            Assert.NotNull(result);
        }

        [Fact]
        public async void GetSpecificNoteTest()
        {
            var result = await manager.GetAsync(15).ConfigureAwait(false);
            Assert.NotNull(result);
        }

        [Fact]
        public async void CreateNoteTest()
        {
            var dto = new NoteDTO
            {
                TypeIds = new int[] { 257, 258 },
                Description = "Note Description",
                Tags = new List<TagDTO>
                {
                    new TagDTO { Type = "Company", ReferenceIds = new int[]{1,2 } },
                    new TagDTO { Type = "Contact", ReferenceIds = new int[]{1,2 } },
                    new TagDTO { Type = "Candidate", ReferenceIds = new int[]{1,2 } }
                }
            };
            var result = await manager.CreateAsync(dto).ConfigureAwait(false); //TODO
            Assert.True(result);
        }
    }
}
