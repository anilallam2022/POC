﻿using HeliumEdge.DataAccess.ATS;
using System;
using System.Collections.Generic;
using System.Text;

namespace HeliumEdge.ATS.Tests
{
    public static class DbContextTestHelper
    {
        public static IDbContext Instance { get
            {
                return new DbContext("Server=tcp:heldev.database.windows.net,1433;Initial Catalog=HeliumEdgeDev;Persist Security Info=False;User ID=Heldev;Password=Helium01;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;");
            }
        }
    }
}
