﻿using HeliumEdge.BusinessObjects.ATS;
using HeliumEdge.DataObjects.ATS;
using HeliumEdge.DataTransfer.ATS;
using System;
using System.Collections.Generic;
using Xunit;

namespace HeliumEdge.ATS.Tests
{
    public class ReminderTest
    {
        ReminderManager manager;
        public ReminderTest()
        {
            manager = new ReminderManager(new DataAccess.ATS.ReminderRepository(DbContextTestHelper.Instance));
        }

        [Fact]
        public async void GetAllRemindersTest()
        {
            var result = await manager.GetAllAsync().ConfigureAwait(false);
            Assert.NotNull(result);
        }

        [Fact]
        public async void GetSpecificReminderTest()
        {
            var result = await manager.GetAsync(34).ConfigureAwait(false);
            Assert.NotNull(result);
        }

        [Fact]
        public async void CreateReminderTest()
        {
            var dto = new ReminderDTO
            {
                Date = DateTime.Now,
                Description = "Reminder Description",
                RemindBefore = "15 mins",
                Title = "New Reminder",
                Tags = new List<TagDTO> {
                    new TagDTO { Type="Company",ReferenceIds=new int[]{1,2 } },
                    new TagDTO { Type="Contact",ReferenceIds=new int[]{1,2 } },
                    new TagDTO { Type="Candidate",ReferenceIds=new int[]{1,2 } }
                }
            };
            var result = await manager.CreateAsync(dto).ConfigureAwait(false);
            Assert.True(result);
        }
    }
}
