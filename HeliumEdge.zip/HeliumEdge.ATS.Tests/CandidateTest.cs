using HeliumEdge.BusinessObjects.ATS;
using HeliumEdge.DataTransfer.ATS;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HeliumEdge.ATS.Tests
{
    [TestClass]
    public class CandidateTest
    {
        CandidateManager manager = new CandidateManager(new DataAccess.ATS.CandidateRepository(DbContextTestHelper.Instance));

        [TestMethod]
        public async Task GetAllCandidatesTest()
        {

            var candidateFilter = new ListPageRequestDTO { PageNumber = 1, PageSize = 10 };
            candidateFilter.SetEntityType("Candidates");
            var result = await manager.GetAllAsync(candidateFilter).ConfigureAwait(false);
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task GetSpecificCandidateTest()
        {
            int candidateId = 5;
            var result = await manager.GetAsync(candidateId).ConfigureAwait(false);

            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task CreateCandidateTest()
        {
            var dto = new CandidateDTO();

            dto.FirstName = "Joydip";
            dto.MiddleName = "";
            dto.LastName = "Kanjilal";
            dto.ProfileTitle = "Developer";
            dto.ExperienceLevelId = 1;
            dto.VisaStatusId = 1;
            dto.DesiredEmploymentTypes = "2|3";
            dto.DesiredSalary = 6000;
            dto.DesiredLocation = "Hyderabad";
            dto.Rating = 5;
            dto.RatingComment = "NA";
            dto.TravelPreferencesId = 1;

            List<CandidateSkillDTO> candidateSkills = new List<CandidateSkillDTO>();
            CandidateSkillDTO skill = new CandidateSkillDTO()
            {
                Skill = "ASP.NET",
                YearsOfExp = 5
            };
            candidateSkills.Add(skill);
            dto.CandidateSkills = candidateSkills;

            List<CandidateExperienceDTO> candidateExperiences = new List<CandidateExperienceDTO>();

            CandidateExperienceDTO experience = new CandidateExperienceDTO()
            {
                Employer = "ABC",
                Location = "Hyderabad",
                Remarks = "",
                Role = "Sr. Developer",
                Responsibilities = "Design & Development",
                StartDate = DateTime.Now,
                EndDate = DateTime.Now
            };

            candidateExperiences.Add(experience);
            dto.CandidateExperiences = candidateExperiences;


            List<CandidateEducationDTO> candidateEducations = new List<CandidateEducationDTO>();

            CandidateEducationDTO candidateEducation = new CandidateEducationDTO()
            {
                Degree = "MCA",
                Institution = "University of Kolkata",
                StartDate = DateTime.Now,
                EndDate = DateTime.Now
            };

            candidateEducations.Add(candidateEducation);
            dto.CandidateEducations = candidateEducations;


            List<CandidateCertificateDTO> candidateCertificates = new List<CandidateCertificateDTO>();

            CandidateCertificateDTO candidateCertificate = new CandidateCertificateDTO()
            {
                Authority = "Microsoft",
                Name = "MVP",
                Number = "1.0",
                Date = DateTime.Now
            };

            candidateCertificates.Add(candidateCertificate);
            dto.CandidateCertificates = candidateCertificates;

            var result = await manager.CreateAsync(dto).ConfigureAwait(false);

            Assert.IsTrue(result);
        }

        [TestMethod]
        public async Task DeleteCandidates()
        {
            List<int> ids = new List<int>() { 2, 3, 4 };
            var result = await manager.Delete(ids).ConfigureAwait(false);
            Assert.IsTrue(result);
        }
    }
}
