﻿using HeliumEdge.BusinessObjects.ATS;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Threading.Tasks;
using HeliumEdge.DataAccess.ATS;

namespace HeliumEdge.ATS.Tests
{
    [TestClass]
    public class SecurityTest
    {
        [TestMethod]
        public async Task GetUserAsyncTest()
        {
            SecurityManager manager = new SecurityManager(new SecurityRepository(DbContextTestHelper.Instance), new RoleRepository(DbContextTestHelper.Instance));
            var result = await manager.GetUserAsync(1);

            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task GetUserPermissionsAsyncTest()
        {
            SecurityManager manager = new SecurityManager(new SecurityRepository(DbContextTestHelper.Instance), new RoleRepository(DbContextTestHelper.Instance));
            var result = await manager.GetUserPermissionsAsync(1);

            Assert.IsNotNull(result);
        }
    }
}
