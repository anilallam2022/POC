﻿using System;
using System.ComponentModel.DataAnnotations;

namespace HeliumEdge.DataObjects.ATS
{
    public class CandidateCertificate : BaseEntity
    {
        public int CandidateId { get; set; }
        public string Name { get; set; }
        public string Number { get; set; }
        public DateTime? Date { get; set; }
        public string Authority { get; set; }
    }
}
