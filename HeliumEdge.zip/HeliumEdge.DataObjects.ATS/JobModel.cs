﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HeliumEdge.DataObjects.ATS
{
    public class JobModel
    {
        public Job Job { get; set; }
        public ICollection<JobDetails> JobDetails { get; set; }
    }
    
}
