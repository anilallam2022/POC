﻿using System;
using System.Collections.Generic;

namespace HeliumEdge.DataObjects.ATS
{
    public class CompanyModel
    {
        public Company Company { get; set; }
        public ICollection<CompanyDetails> CompanyDetails { get; set; }
        public ICollection<CompanyContact> CompanyContact { get; set; }
    }

    public class Company : BaseEntity
    {
        public string CompanyName { get; set; }
        public int? IndustryId { get; set; }
        public string WebsiteUrl { get; set; }
        public string LinkedInId { get; set; }
        public string FacebookId { get; set; }
        public bool Priority { get; set; }
        public string EmploymentTypeIds { get; set; }
        public int? PaymentTermsId { get; set; }
        public decimal PlacementFee { get; set; }
        public int? FeeTypeId { get; set; }
        public string CompanyTypeIds { get; set; }
        public int? AccountOwnerId { get; set; }
        public string Description { get; set; }
        public string Tags { get; set; }
        public int? StatusId { get; set; }
        public bool IsDeleted { get; set; }
        public Attachment Logo { get; set; }
    }

    public class CompanyMapperExtension : DapperExtensions.Mapper.ClassMapper<Company>
    {
        public CompanyMapperExtension()
        {
            Table(nameof(Company));           
            Map(m => m.Logo).Ignore();
            AutoMap();
        }
    }
}
