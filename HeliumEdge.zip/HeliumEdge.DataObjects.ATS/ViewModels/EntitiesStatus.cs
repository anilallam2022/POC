﻿using System.Collections.Generic;

namespace HeliumEdge.DataObjects.ATS.ViewModels
{
    public class EntitiesStatus
    {
        public IEnumerable<int> EntityIds { get; set; }
        public int NewStatusId { get; set; }
    }
}
