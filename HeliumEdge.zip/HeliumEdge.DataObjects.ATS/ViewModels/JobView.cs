﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HeliumEdge.DataObjects.ATS.ViewModels
{
    public class JobView
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public int? CompanyId { get; set; }
        public string CompanyName { get; set; }//
        public int? NoOfOpenings { get; set; }
        public string Status { get; set; }//
        public string Priority { get; set; }//
        public DateTime? StartDate { get; set; }
        public string Duration { get; set; }//
        public string Locations { get; set; }
        public string EmploymentTypes { get; set; }//
        public string ExperienceLevel { get; set; }//
        public bool TeleCommute { get; set; }
        public double? SalaryFrom { get; set; }
        public double? SalaryTo { get; set; }
        public string SalaryUnit { get; set; }//
        public string PrimaryContactNames { get; set; }//
    }
}
