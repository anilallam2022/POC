﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HeliumEdge.DataObjects.ATS.ViewModels
{
    public class CompanyView
    {
        public int Id { get; set; }
        public string CompanyName { get; set; }
        public string CompanyLogo { get; set; }
        public string Location { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string WebsiteUrl { get; set; }
        public string EmploymentTypes { get; set; }
        public string PaymentTerms { get; set; }
        public decimal PlacementFee { get; set; }
        public string FeeType { get; set; }
        public string PrimaryContact { get; set; }
        public string Status { get; set; }
        public string CompanyTypes { get; set; }
        public string Tags { get; set; }
        public string FacebookId { get; set; }
        public string LinkedinId { get; set; }
    }
}
