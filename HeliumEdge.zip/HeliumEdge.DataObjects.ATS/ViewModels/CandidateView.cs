﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HeliumEdge.DataObjects.ATS.ViewModels
{
    public class CandidateView
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string ProfileTitle { get; set; }
        public string Fax { get; set; }
        public string LinkedInId { get; set; }
        public string SkypeId { get; set; }
        public string FacebookId { get; set; }
        public int? Rating { get; set; }
        public bool Relocate { get; set; }

        
        public string DesiredEmploymentTypes { get; set; }
        public double? DesiredSalary { get; set; }
        public string DesiredLocation { get; set; }

        public int? ExperienceLevelId { get; set; }
        public int? VisaStatusId { get; set; }
        public int? AvailabilityId { get; set; }
        public int? SourceId { get; set; }
        public int? OwnerId { get; set; }
        public int? TravelPreferencesId { get; set; }

        public string Source { get; set; }
        public string Owner { get; set; }
        public string VisaStatus { get; set; }
        public string ExperienceLevel { get; set; }
        public string Availability { get; set; }
        public string TravelPreferences { get; set; }
        public string Tags { get; set; }
        public string Emails { get; set; }
        public string PhoneNumbers { get; set; }
        public string Addresses { get; set; }
        public string WebAddresses { get; set; }
        public string Educations { get; set; }
        public string Skills { get; set; }
        public string Certificates { get; set; }
        public string Photo { get; set; }
        public string Resume { get; set; }
    }
}
