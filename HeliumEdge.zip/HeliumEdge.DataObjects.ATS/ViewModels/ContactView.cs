﻿using System;
using System.Collections.Generic;

namespace HeliumEdge.DataObjects.ATS.ViewModels
{
    public class ContactView
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string Description { get; set; }
        public string LastName { get; set; }
        public int? CompanyId { get; set; }
        public string CompanyName { get; set; }
        public int? OwnerId { get; set; }
        public string Owner { get; set; }
        public int? SourceId { get; set; }
        public string Source { get; set; }
        public string Addresses { get; set; }        
        public bool IsPrivateContact { get; set; }        
        public string LinkedInId { get; set; }
        public string SkypeId { get; set; }
        public string FacebookId { get; set; }
        public string Department { get; set; }
        public int? DepartmentId { get; set; }
        public string Types { get; set; }
        public string PreferredMethodOfContact { get; set; }
        public string PreferredTimeToContact { get; set; }              
        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public string Tags { get; set; }
        public string Photo { get; set; }
        public string PhoneNumbers { get; set; }
        public string Emails { get; set; }
        public string WebAddresses { get; set; }
        public string RoleName { get; set; }
    }
}
