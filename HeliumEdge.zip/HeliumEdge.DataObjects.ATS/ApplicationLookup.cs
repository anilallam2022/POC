﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HeliumEdge.DataObjects.ATS
{
    public class ApplicationLookup : BaseEntity
    {
        public string Type { get; set; }
        public string Description { get; set; }
        public string ModuleName { get; set; }
        public bool IsActive { get; set; }
        public bool IsDefault { get; set; }
        public int? OrderId { get; set; }
    }
}
