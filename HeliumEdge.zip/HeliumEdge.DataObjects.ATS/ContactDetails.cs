﻿
namespace HeliumEdge.DataObjects.ATS
{
    public class ContactDetails : BaseEntity
    {
        public int ContactId { get; set; }
        public string CountryCode { get; set; }
        public string PhoneNumber { get; set; }
        public string PhoneExtension { get; set; }
        public int? PhoneTypeId { get; set; }
        public string Address { get; set; }
        public int? AddressTypeId { get; set; }
        public string Email { get; set; }
        public int? EmailTypeId { get; set; }
        public string WebAddress { get; set; }
        public int? WebAddressTypeId { get; set; }        
    }
}
