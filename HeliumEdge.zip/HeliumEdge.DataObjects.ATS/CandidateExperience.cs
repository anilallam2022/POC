﻿using System;

namespace HeliumEdge.DataObjects.ATS
{
    public class CandidateExperience : BaseEntity
    {
        public int CandidateId { get; set; }
        public string Employer { get; set; }
        public string Role { get; set; }
        public string Responsibilities { get; set; }
        public string Remarks { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string Location { get; set; }
        public bool? CurrentlyWorking { get; set; }
    }
}
