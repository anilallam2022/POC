﻿using System.Collections.Generic;

namespace HeliumEdge.DataObjects.ATS
{
    public class Note : BaseEntity
    {
        public string TypeIds { get; set; }
        public string Description { get; set; }
        public ICollection<Tag> Tags { get; set; }
        public ICollection<Attachment> Attachments { get; set; }
    }

    //public class NoteModel
    //{
    //    public Note Note { get; set; }
    //    public ICollection<Tag> Tags { get; set; }
    //}

    public class NoteMapper : DapperExtensions.Mapper.ClassMapper<Note>
    {
        public NoteMapper()
        {
            Table(nameof(Note));
            Map(m => m.Attachments).Ignore();
            Map(m => m.Tags).Ignore();
            AutoMap();
        }
    }
}
