﻿using System;
using System.Collections.Generic;

namespace HeliumEdge.DataObjects.ATS
{
    public class Job : BaseEntity
    {
        public string OrderId { get; set; }
        public bool CanTeleCommute { get; set; }
        public int? HiringCompanyId { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string Requirement { get; set; }
        public int? AccountManagerId { get; set; }
        public int? NoOfOpenings { get; set; }
        public int? StatusId { get; set; }
        public int? PriorityId { get; set; }
        public int? ExperienceLevelId { get; set; }
        public double? SalaryFrom { get; set; }
        public double? SalaryTo { get; set; }
        public int? SalaryUnitId { get; set; }
        public int? TravelRequirementId { get; set; }
        public DateTime? StartDate { get; set; }
        public float? Duration { get; set; }
        public int? DurationUnitId { get; set; }
        public int? IndustryId { get; set; }
        public int? DepartmentId { get; set; }
        public double? PlacementFee { get; set; }
        public int? PlacementFeeTypeId { get; set; }
        public string Tags { get; set; }
        public bool IsDeleted { get; set; }
        public string Reason { get; set; }
    }
     public class JobMapper : DapperExtensions.Mapper.ClassMapper<Job>
    {
        public JobMapper()
        {
            Table(nameof(Job));
            Map(m => m.OrderId).Ignore();           
            Map(m => m.Reason).Ignore();
            AutoMap();
        }
    }
}
