﻿using System;
using System.Collections.Generic;

namespace HeliumEdge.DataObjects.ATS
{
    public class Contact : BaseEntity
    {
        //public int SalutationId { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public bool IsPrivateContact { get; set; }
        public int? ContactOwnerId { get; set; }
        public int? ContactSourceId { get; set; }
        public string ContactTypeIds { get; set; }
        public string LinkedInId { get; set; }
        public string SkypeId { get; set; }
        public string FacebookId { get; set; }
        public string PreferredMethodOfContactIds { get; set; }
        public string PreferredTimeToContact { get; set; }
        public string Description { get; set; }
        public string Tags { get; set; }
        public Attachment Photo { get; set; }
        public ICollection<ContactDetails> ContactDetails { get; set; }
        public CompanyContact CompanyContact { get; set; }
        public bool IsDeleted { get; set; }
        public Int16? TypeId { get; set; } //This represents contact is whether it is a candidate contact. Should be 1 for candidate
        public int? StatusId { get; set; }
    }


    public class ContactMapper : DapperExtensions.Mapper.ClassMapper<Contact>
    {
        public ContactMapper()
        {
            Table(nameof(Contact));
            Map(m => m.ContactDetails).Ignore();           
            Map(m => m.CompanyContact).Ignore();
            Map(m => m.Photo).Ignore();
            AutoMap();
        }
    }
}
