﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HeliumEdge.DataObjects.ATS
{
    public class TaskModel
    {
        public TaskEntity TaskEntity { get; set; }
        public ICollection<Tag> Tags { get; set; }
        public ICollection<Attachment> Attachments { get; set; }
    }

    public class TaskEntity : BaseEntity
    {
        public int? TypeId { get; set; }
        public string Title { get; set; }
        public int? AssignedToUserId { get; set; }
        public int? PriorityId { get; set; }
        public DateTime? TaskDateTime { get; set; }
        public bool IsRepeat { get; set; }
        public int? RepeatFrequencyId { get; set; }
        public string WeekDays { get; set; }
        public int? WeekFrequency { get; set; }
        public string MonthDates { get; set; }
        public string YearMonths { get; set; }
        public string YearMonthDates { get; set; }
        public DateTime? EndDate { get; set; }
        public int? ReminderInMinutesId { get; set; }
        public string Description { get; set; }
    }
}
