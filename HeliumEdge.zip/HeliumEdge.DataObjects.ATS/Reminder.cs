﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HeliumEdge.DataObjects.ATS
{
    public class Reminder : BaseEntity
    {
        public string Title { get; set; }
        public DateTime Date { get; set; }
        public string RemindBefore { get; set; }
        public string Description { get; set; }
    }

    public class ReminderModel
    {
        public Reminder Reminder { get; set; }
        public ICollection<Tag> Tags { get; set; }
    }
}
