﻿namespace HeliumEdge.DataObjects.ATS
{
    public class CandidateSkill : BaseEntity
    {
        public int CandidateId { get; set; }
        public string Skill { get; set; }
        public int YearsOfExp { get; set; }
    }
}
