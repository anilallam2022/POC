﻿using System;
using System.Collections.Generic;

namespace HeliumEdge.DataObjects.ATS
{
    public class Event : BaseEntity
    {
        public int? EventTypeId { get; set; }
        public int? InterviewTypeId { get; set; }
        public string Title { get; set; }
        public bool IsPersonal { get; set; }                
        //public bool IsAllDayEvent { get; set; }
        public string Location { get; set; }
        public string PhoneNumber { get; set; }
        public string WebAddress { get; set; }
        public string Description { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string TimeZone { get; set; }
        public bool IsRepeat { get; set; }
        public int? RepeatFrequencyId { get; set; }
        public string WeekDays { get; set; }
        public int? WeekFrequency { get; set; }
        public string MonthDates { get; set; }
        public string YearMonths { get; set; }
        public string YearMonthDates { get; set; }   
        public string Attendies { get; set; }
        public int ReminderInMinutes { get; set; }
        public int? OrganizerId { get; set; }
    }

    public class EventModel
    {
        public Event Event { get; set; }
        public ICollection<Tag> Tags { get; set; }
    }
}
