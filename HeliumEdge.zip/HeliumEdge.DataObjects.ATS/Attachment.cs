﻿
namespace HeliumEdge.DataObjects.ATS
{
    public class Attachment : BaseEntity
    {
        public string FileName { get; set; }
        public string Type { get; set; }
        public string StorageFileName { get; set; }
        public string ReferencedEntityName { get; set; }
        public int ReferencedEntityId { get; set; } 
        //Folder Path of the file
        public string FilePath { get; set; }
    }

    public class AttachmentMapper : DapperExtensions.Mapper.ClassMapper<Attachment>
    {
        public AttachmentMapper()
        {
            Table(nameof(Attachment));          
            AutoMap();
        }
    }
}
