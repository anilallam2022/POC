﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HeliumEdge.DataObjects.ATS
{
    public class JobDetails : BaseEntity
    {
        public int JobId { get; set; }
        public string Location { get; set; }
        public int? PrimaryContactId { get; set; }
        public int? AssignedRecruiterId { get; set; }
        public int? EmploymentTypeId { get; set; }
    }
}
