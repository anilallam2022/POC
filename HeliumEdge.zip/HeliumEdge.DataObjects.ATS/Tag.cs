﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HeliumEdge.DataObjects.ATS
{
    public class Tag : BaseEntity
    {
        public string ReferenceEntityName { get; set; }
        public int ReferenceEntityId { get; set; }
        public string Type { get; set; }
        public string Tags { get; set; }
    }
    public class TagView : Tag
    {

    }
}
