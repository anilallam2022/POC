﻿using System;

namespace HeliumEdge.DataObjects.ATS
{
    public class CandidateEducation: BaseEntity
    {
        public int CandidateId { get; set; }
        public string Degree { get; set; }
        public string Institution { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string Location { get; set; }
        public bool CurrentlyAttending { get; set; }
    }
}
