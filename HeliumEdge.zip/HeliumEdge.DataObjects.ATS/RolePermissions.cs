﻿namespace HeliumEdge.DataObjects.ATS
{
    public class RolePermissions
    {
        public int RoleId { get; set; }
        public string Screen { get; set; }
        public string Rights { get; set; }
    }
}
