﻿using System.Collections.Generic;

namespace HeliumEdge.DataObjects.ATS
{
    public class CandidateModel
    {
        public Candidate Candidate { get; set; }
        public Contact Contact { get; set; }
        public List<CandidateCertificate> CandidateCertificates { get; set; }
        public List<CandidateEducation> CandidateEducations { get; set; }
        public List<CandidateExperience> CandidateExperiences { get; set; }
        public List<CandidateSkill> CandidateSkills { get; set; }
    }
}
