﻿namespace HeliumEdge.DataObjects.ATS
{
    public class Candidate : BaseEntity
    {
        public string ProfileTitle { get; set; }
        public int? ExperienceLevelId { get; set; }
        public int? VisaStatusId { get; set; }
        public int? AvailabilityId { get; set; }
        public int? Rating { get; set; }
        public string RatingComment { get; set; }
        public int? TravelPreferencesId { get; set; }
        public string DesiredEmploymentTypes { get; set; }
        public int? CandidateSourceId { get; set; }
        public double? DesiredSalary { get; set; }
        public string DesiredLocation { get; set; }
        public int ContactId { get; set; }
        public Attachment Resume { get; set; }
        public bool IsDeleted { get; set; }
        public string Fax { get; set; }
        public bool Relocate { get; set; }
    }

    public class CandidateMapper : DapperExtensions.Mapper.ClassMapper<Candidate>
    {
        public CandidateMapper()
        {
            Table(nameof(Candidate));
            Map(m => m.Resume).Ignore();
            AutoMap();
        }
    }
}


