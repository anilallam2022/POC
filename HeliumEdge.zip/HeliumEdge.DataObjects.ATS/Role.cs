﻿
namespace HeliumEdge.DataObjects.ATS
{
    public class Role : BaseEntity
    {
        public string Name { get; set; }
    }
}
