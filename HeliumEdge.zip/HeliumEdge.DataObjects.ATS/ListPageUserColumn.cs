﻿namespace HeliumEdge.DataObjects.ATS
{
    public class ListPageUserColumn : BaseEntity
    {
        public int UserId { get; set; }
        public string Entity { get; set; }
        public string ColumnIds { get; set; }
        public string ListName { get; set; }
    }

    public class ListPageUserColumnMapper : DapperExtensions.Mapper.ClassMapper<ListPageUserColumn>
    {
        public ListPageUserColumnMapper()
        {
            Table("ListPageUserColumns");
            AutoMap();
        }
    }
}
