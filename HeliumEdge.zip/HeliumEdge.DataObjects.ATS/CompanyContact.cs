﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HeliumEdge.DataObjects.ATS
{
    public class CompanyContact : BaseEntity
    {
        public int? CompanyId { get; set; }
        public int? ContactId { get; set; }
        public string Role { get; set; }
        public int? DepartmentId { get; set; }
    }
}
