﻿namespace HeliumEdge.DataObjects.ATS
{
    public class ListPageColumn : BaseEntity
    {
        public string ColumnName { get; set; }
        public string DisplayText { get; set; }
        public string Entity { get; set; }
        public bool IsDefault { get; set; }
        public bool IsLocked { get; set; }
    }

    public class ListPageColumnMapper : DapperExtensions.Mapper.ClassMapper<ListPageColumn>
    {
        public ListPageColumnMapper()
        {
            Table("ListPageColumns");           
            AutoMap();
        }
    }
}
