﻿using System;

public interface IDbContext
{
    IDbConnection Connection { get; }
}

public class DbContext : IDbContext
{
    private readonly string connectionString;
    public DbContext(string connectionString)
    {
        this.connectionString = connectionString;
    }

    public IDbConnection Connection
    {
        get
        {
            return new SqlConnection(connectionString);
        }
    }
}
