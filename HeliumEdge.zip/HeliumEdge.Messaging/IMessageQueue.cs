﻿using System.Collections.Generic;

namespace HeliumEdge.Messaging
{
    /// <summary>
    /// IMessageQueue interface that contains the declarations of the
    /// various supported operations
    /// </summary>
    public interface IMessageQueue
    {
        void Initialize(string queue);
        List<T> Receive<T>(string queue) where T : class;
        void Send<T>(string queue, T data);
        void Purge(string queue);
        void Delete(string queue);
    }
}
