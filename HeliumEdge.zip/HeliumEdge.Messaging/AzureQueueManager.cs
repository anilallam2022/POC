﻿using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Queue;
using Newtonsoft.Json;
using System.Threading.Tasks;

namespace HeliumEdge.Messaging
{
    public static class AzureQueueManager
    {
        static string connectionString = "";

        public static async Task AddMessage(string queueName, string text)
        {
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(connectionString);
            CloudQueueClient queueClient = storageAccount.CreateCloudQueueClient();
            CloudQueue messageQueue = queueClient.GetQueueReference(queueName);
            await messageQueue.CreateIfNotExistsAsync().ConfigureAwait(false);
            CloudQueueMessage message = new CloudQueueMessage(text);
            await messageQueue.AddMessageAsync(message).ConfigureAwait(false);
        }

        public static async Task<T> GetMessage<T>(string queueName)
        {
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(connectionString);
            CloudQueueClient queueClient = storageAccount.CreateCloudQueueClient();
            CloudQueue messageQueue = queueClient.GetQueueReference(queueName);
            await messageQueue.CreateIfNotExistsAsync().ConfigureAwait(false);

            CloudQueueMessage retrievedMessage = await messageQueue.GetMessageAsync().ConfigureAwait(false);

            if (retrievedMessage != null)
            {
                T data = JsonConvert.DeserializeObject<T>(retrievedMessage.AsString);
                await messageQueue.DeleteMessageAsync(retrievedMessage).ConfigureAwait(false);
                return data;
            }

            return default(T);
        }
    }
}
