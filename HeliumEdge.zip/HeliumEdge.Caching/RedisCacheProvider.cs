﻿using System;

namespace HeliumEdge.Caching
{
    internal class RedisCacheProvider : ICacheProvider
    {
        //RedisEndpoint _endPoint;
        private string Host
        {
            get; set;
        }

        private string Port
        {
            get; set;
        }

        public void Initialize(string host, string port)
        {
            this.Host = host;
            this.Port = port;
        }
        public RedisCacheProvider()
        {
            //_endPoint = new RedisEndpoint(RedisConfigurationManager.Config.Host, RedisConfigurationManager.Config.Port, RedisConfigurationManager.Config.Password, RedisConfigurationManager.Config.DatabaseID);

            if(string.IsNullOrEmpty(Host))
                Host = "localhost";
        }

        public void Set<T>(string key, T value)
        {
            Set(key, value, TimeSpan.FromSeconds(600));
        }

        public void Set<T>(string key, T value, TimeSpan timeout)
        {
            Set<T>(key, value, timeout);
        }

        public T Get<T>(string key)
        {
            return Get<T>(key);
        }

        public bool Remove(string key)
        {
            return Remove(key);
        }

        public bool IsInCache(string key)
        {
            return IsInCache(key);
        }
    }
}
