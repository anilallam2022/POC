﻿using System;

namespace HeliumEdge.Caching
{
    public static class CacheManager
    {
        private static readonly ICacheProvider _cacheProvider = new RedisCacheProvider();
 
        public static void Initialize(string host, string port)
        {
            _cacheProvider.Initialize(host, port);
        }
        public static void Insert<T>(string key, T value)
        {
            try
            {
                _cacheProvider.Set(key, value, TimeSpan.FromSeconds(600));
            }
            catch { }
            
        }
        public static void Insert<T>(string key, T value, Int32 seconds)
        {
            try
            {
                _cacheProvider.Set(key, value, TimeSpan.FromSeconds(seconds));
            }
            catch { }
        }
        public static T Get<T>(string key)
        {
            try
            {
                return _cacheProvider.Get<T>(key);
            }
            catch
            {
                return default(T);
            }
        }

        public static bool Remove(string key)
        {
            try
            {
                return _cacheProvider.Remove(key);
            }
            catch
            {
                return false;
            }
        }
        public static bool IsInCache(string key)
        {
            try
            {
                return _cacheProvider.IsInCache(key);
            }
            catch
            {
                return false;
            }
        }
    }
}
