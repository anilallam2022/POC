﻿namespace HeliumEdge.Caching
{
    public class MemoryCacheProvider
    {
              
    }
}
