﻿using System;
using System.Collections;
using System.Security.Cryptography;
using System.Text;

namespace HeliumEdge.Common
{
    public static class AsymmetricEncryption
    {
        #region "Private members"
        private static bool _optimalAsymmetricEncryptionPadding = false;
        #endregion

        #region "Public members"
        public static bool OptimalAsymmetricEncryptionPadding
        {
            get { return _optimalAsymmetricEncryptionPadding; }
            set { _optimalAsymmetricEncryptionPadding = value; }
        }
        #endregion

        #region "Public methods"
        public static AsymmetricKeyPair GenerateKeys(int keySize)
        {
            if (!IsKeySizeValid(keySize)) throw new ArgumentException("The provided key size is invalid.", "keySize");
            using (var provider = new RSACryptoServiceProvider(keySize))
            {
                return new AsymmetricKeyPair(provider.ConvertToXmlString(), provider.ConvertToXmlString());
            }
        }
        public static string EncryptText(string text, string publicKeyXml, int keySize)
        {
            int byteKeySize = keySize / 8;
            byte[] bytes = Encoding.UTF32.GetBytes(text);
            int maxLength = byteKeySize - 42;
            int dataLength = bytes.Length;
            int iterations = dataLength / maxLength;
            StringBuilder stringBuilder = new StringBuilder();

            if (!IsKeySizeValid(keySize)) throw new ArgumentException("The provided key size is invalid.", "keySize");
            if (String.IsNullOrEmpty(publicKeyXml)) throw new ArgumentException("The provided key is null or empty", "publicKeyXml");

            RSACryptoServiceProvider rsaCryptoServiceProvider = new RSACryptoServiceProvider(keySize);
            rsaCryptoServiceProvider.ConvertFromXmlString(publicKeyXml);

            for (int counter = 0; counter <= iterations; counter++)
            {
                byte[] tempBytes = new byte[(dataLength - maxLength * counter > maxLength) ? maxLength : dataLength - maxLength * counter];
                Buffer.BlockCopy(bytes, maxLength * counter, tempBytes, 0, tempBytes.Length);
                byte[] encryptedBytes = rsaCryptoServiceProvider.Encrypt(tempBytes, true);
                Array.Reverse(encryptedBytes);
                stringBuilder.Append(Convert.ToBase64String(encryptedBytes));
            }
            return stringBuilder.ToString();
        }
    
        public static string DecryptText(string text, string publicAndPrivateKeyXml, int keySize)
        {

            RSACryptoServiceProvider rsaCryptoServiceProvider = new RSACryptoServiceProvider(keySize);
            rsaCryptoServiceProvider.ConvertFromXmlString(publicAndPrivateKeyXml);

            int base64BlockSize = ((keySize / 8) % 3 != 0) ? (((keySize / 8) / 3) * 4) + 4 : ((keySize / 8) / 3) * 4;
            int iterations = text.Length / base64BlockSize;
            var arrayList = new ArrayList();

            for (int i = 0; i < iterations; i++)
            {
                byte[] encryptedBytes = Convert.FromBase64String(text.Substring(base64BlockSize * i, base64BlockSize));
                Array.Reverse(encryptedBytes);
                arrayList.AddRange(rsaCryptoServiceProvider.Decrypt(encryptedBytes, true));
            }
            return Encoding.UTF32.GetString(arrayList.ToArray(Type.GetType("System.Byte")) as byte[]);

        }

        #endregion

        #region "Private methods"
        private static bool IsKeySizeValid(int keySize)
        {
            return keySize >= 384 &&
                   keySize <= 16384 &&
                   keySize % 8 == 0;
        }

        private static int GetMaxDataLength(int keySize)
        {
            if (OptimalAsymmetricEncryptionPadding)
            {
                return ((keySize - 384) / 8) + 7;
            }
            return ((keySize - 384) / 8) + 37;
        }
        #endregion
    }
}
