﻿using Microsoft.IdentityModel.Tokens;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;

namespace HeliumEdge.Common
{
    public static class TokenHelper
    {
        public static string GetRoleFromToken(string token, string securityKey)
        {
            try
            {
                SecurityToken validatedToken;
                var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(securityKey));
                TokenValidationParameters validationParameters = new TokenValidationParameters();
                validationParameters.IssuerSigningKey = key;
                validationParameters.ValidAudience = securityKey;
                validationParameters.ValidIssuer = securityKey;
                validationParameters.ValidateIssuer = true;

                var principal = new JwtSecurityTokenHandler().ValidateToken(token, validationParameters, out validatedToken);
                var userName = principal.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name)?.Value;
                var role = principal.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Role)?.Value;
                var userEmailId = principal.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Email)?.Value;
                return role;
            }
            catch (Exception ex)
            {
                string msg = ex.Message;
            }
            return null;
        }



        public static string GetSecretKey(string userName, string password)
        {
            //TODO
            var keys = AsymmetricEncryption.GenerateKeys(1024); //Symmetric key
            string text = userName + password;
            return AsymmetricEncryption.EncryptText(text, keys.PublicKey, 1024);
        }
    }
}
