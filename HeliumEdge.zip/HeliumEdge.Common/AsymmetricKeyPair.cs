﻿namespace HeliumEdge.Common
{
    public class AsymmetricKeyPair
    {
        private readonly string _publicKey;
        private readonly string _privateKey;

        public AsymmetricKeyPair(string publicKey, string privateKey)
        {
            _publicKey = publicKey;
            _privateKey = privateKey;
        }

        /// <summary>
        /// Asymmetric private RSA key.
        /// </summary>
        public string PrivateKey
        {
            get { return _privateKey; }
        }

        /// <summary>
        /// Asymmetric public RSA key.
        /// </summary>
        public string PublicKey
        {
            get { return _publicKey; }
        }
    }
}
