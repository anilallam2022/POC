﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace HeliumEdge.Common.ValidationAttributes
{
    public class ValidateObjectAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object obj, ValidationContext validationContext)
        {
            if (obj == null || (obj != null && (obj.GetType().IsValueType || obj.GetType() == typeof(string))))
                return ValidationResult.Success;
            
            CompositeValidationResult compositeValidationResult = null;
            ValidationContext context = null;
            List<ValidationResult> results = null;

            if (obj.GetType().IsGenericType || obj.GetType().IsArray)
            {
                var objEnumerable = obj as IEnumerable;
                int i = 0;
                foreach (var currentObj in objEnumerable)
                {
                    //Please un-comment this part, if we need to validate Icollection or Array of value types or string
                    if (currentObj.GetType().IsValueType || currentObj.GetType() == typeof(string))
                        return ValidationResult.Success;

                    results = new List<ValidationResult>();
                    context = new ValidationContext(currentObj, null, null);
                    context.MemberName = validationContext.MemberName + "[" + i.ToString() + "]";
                    
                    Validator.TryValidateObject(currentObj, context, results, true);

                    if (results.Count != 0)
                    {
                        if (compositeValidationResult == null)
                            compositeValidationResult = new CompositeValidationResult("Invalid " + validationContext.MemberName, new string[] { validationContext.MemberName });
                        foreach (var r in results)
                        {
                            if (r.GetType() == typeof(CompositeValidationResult))
                            {
                                foreach (var error in ((CompositeValidationResult)r).Errors)
                                {
                                    ValidationResult vr = new ValidationResult(error.Value, new List<string>() { context.MemberName + "." + error.Key });
                                    //compositeValidationResult.AddResult(vr);
                                    compositeValidationResult.AddError(vr.MemberNames.ToList()[0], vr.ErrorMessage);
                                }
                            }
                            else
                            {
                                ValidationResult vr = new ValidationResult(r.ErrorMessage, r.MemberNames.Select(x => x = x.Replace(x, context.MemberName + "." + x)).ToList());
                                //compositeValidationResult.AddResult(vr);
                                compositeValidationResult.AddError(vr.MemberNames.ToList()[0], vr.ErrorMessage);
                            }
                        }

                    }
                    i++;
                }
            }
            else if(obj.GetType().IsClass)
            {
                context = new ValidationContext(obj, null, null);
                results = new List<ValidationResult>();
                Validator.TryValidateObject(obj, context, results, true);
            }
            if (compositeValidationResult?.Errors.Count() > 0)
            {
                return compositeValidationResult;
            }
            return ValidationResult.Success;
        }

    }

    public class CompositeValidationResult : ValidationResult
    {
        //private readonly List<ValidationResult> _results = new List<ValidationResult>();
        //public IEnumerable<ValidationResult> Results
        //{
        //    get
        //    {
        //        return _results;
        //    }
        //}
        //public void AddResult(ValidationResult validationResult)
        //{
        //    _results.Add(validationResult);
        //}

        private readonly Dictionary<string, string> _errors = new Dictionary<string, string>();
        public Dictionary<string, string> Errors
        {
            get
            {
                return _errors;
            }
        }
        public CompositeValidationResult(string errorMessage) : base(errorMessage) { }
        public CompositeValidationResult(string errorMessage, IEnumerable<string> memberNames) : base(errorMessage, memberNames) { }
        protected CompositeValidationResult(ValidationResult validationResult) : base(validationResult) { }
        public void AddError(string key, string message)
        {
            _errors.Add(key, message);
        }
    }


}
