using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ATS.Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            var p = "sss";

            Assert.IsNull(p);
        }
    }
}
