﻿using System.Runtime.Serialization;

namespace HeliumEdge.Exception
{
    public class ApiException : BaseException
    {
        public ApiException()
        {
        }

        public ApiException(string message)
            : base(message)
        {
        }

        public ApiException(string message,
            System.Exception innerException)
            : base(message, innerException)
        {
        }

        protected ApiException(SerializationInfo info,
            StreamingContext context)
            : base(info, context)
        {

        }

        public string EndPoint
        {
            get;
            set;
        }

        public override void GetObjectData(SerializationInfo info,
            StreamingContext context)
        {
            base.GetObjectData(info, context);

            if (info != null)
            {
                info.AddValue("EndPoint", this.EndPoint);
            }
        }
    }
}
