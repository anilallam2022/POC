﻿using System;
using HeliumEdge.Core;
using System.Net;


namespace HeliumEdge.Exception
{
    public static class ExceptionExtension
    {
        private static ResponseErrorMetadata responseErrorMetadata;
        public static ResponseMetadata HandleExceptionResponse(this System.Exception ex)
        {
            var exceptionType = ex.GetType();
            //TODO - ADD custom exception handlers

            if (exceptionType == typeof(CustomValidationException))
            {
                responseErrorMetadata = new ResponseErrorMetadata
                {
                    Version = "1.0",
                    ErrorMessage = ex.Message,
                    Errors = ((CustomValidationException)ex).ValidationResult,
                    Content = ((CustomValidationException)ex).Model,
                    Timestamp = DateTime.UtcNow,
                    StatusCode = (int)HttpStatusCode.BadRequest,
                    Size = null
                };
            }
            else
            {
                responseErrorMetadata = new ResponseErrorMetadata
                {
                    Version = "1.0",
                    Content = null,
                    ErrorMessage = ex.Message,
                    Errors = string.Empty,
                    Timestamp = DateTime.UtcNow,
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Size = null
                };
            }
            return responseErrorMetadata;
        }
    }
}
