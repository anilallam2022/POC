﻿using System;
using System.Runtime.Serialization;

namespace HeliumEdge.Exception
{
    /// <summary>
    /// Serializable DAL Exception Class
    /// </summary>
    [Serializable]
    public sealed class DALException : BaseException
    {
        public string Module
        {
            get;
            set;
        }

        public string Screen
        {
            get;
            set;
        }
        public DALException()
        {
        }

        public DALException(string message)
            : base(message)
        {
        }

        public DALException(string message,
            System.Exception innerException)
            : base(message, innerException)
        {
        }

        protected DALException(SerializationInfo info,
            StreamingContext context)
            : base(info, context)
        {
            
        }

        public override void GetObjectData(SerializationInfo info,
            StreamingContext context)
        {
            base.GetObjectData(info, context);

            if (info != null)
            {
                info.AddValue("MessageId", this.ExceptionMessage);
                info.AddValue("Message", this.ExceptionMessageId);
            }
        }
    }
}
