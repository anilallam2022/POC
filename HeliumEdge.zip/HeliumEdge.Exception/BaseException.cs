﻿using System;
using System.Runtime.Serialization;

namespace HeliumEdge.Exception
{
    /// <summary>
    /// Abstract Exception Base Class
    /// </summary>
    [Serializable]
    public abstract class BaseException : System.Exception
    {
        /// <summary>
        /// ExceptionMessage property
        /// </summary>
        protected String ExceptionMessage
        {
            get;
            set;
        }

        /// <summary>
        /// ExceptionMessageId property
        /// </summary>
        public int ExceptionMessageId
        {
            get;
            set;
        }

        /// <summary>
        /// Protected Constructor
        /// </summary>
        protected BaseException()
        {
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
         public BaseException(string message)
            : base(message)
        {
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        public BaseException(string message, int messageId)
           : base(message)
        {
            this.ExceptionMessageId = messageId;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        /// <param name="innerException"></param>
        public BaseException(string message,
            System.Exception innerException)
            : base(message, innerException)
        {
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="info"></param>
        /// <param name="context"></param>
        protected BaseException(SerializationInfo info,
            StreamingContext context)
            : base(info, context)
        {
            
        }
    }
}
