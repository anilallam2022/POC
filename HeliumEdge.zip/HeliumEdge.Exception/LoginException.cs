﻿using System;
using System.Runtime.Serialization;

namespace HeliumEdge.Exception
{
    /// <summary>
    /// Serializable Login Exception Class
    /// </summary>
    [Serializable]
    public sealed class LoginException : BaseException
    {
        public int UserId
        {
            get;
            set;
        }
        public string UserName
        {
            get;
            set;
        }

        public LoginException()
        {
        }

        public LoginException(string message)
            : base(message)
        {
        }

        public LoginException(string message,
            System.Exception innerException)
            : base(message, innerException)
        {
        }

        protected LoginException(SerializationInfo info,
            StreamingContext context)
            : base(info, context)
        {
            if (info != null)
            {
                this.UserId = info.GetInt32("UserId");
                this.UserName = info.GetString("UserName");
            }
        }

        public override void GetObjectData(SerializationInfo info,
            StreamingContext context)
        {
            base.GetObjectData(info, context);

            if (info != null)
            {
                info.AddValue("UserName", this.UserName);
                info.AddValue("UserId", this.UserId);
            }
        }
    }
}
