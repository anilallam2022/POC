﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HeliumEdge.Exception
{
    public class CustomValidationException : BaseException
    {
        private object _ValidationResult;
        private object _Model;
        public object ValidationResult
        {
            get
            {
                return _ValidationResult;
            }
        }
        public object Model
        {
            get
            {
                return _Model;
            }
        }
        public CustomValidationException()
        {
          
        }

        public CustomValidationException(string message)
            : base(message)
        {
        }

        public CustomValidationException(string message,
            System.Exception innerException)
            : base(message, innerException)
        {
        }

        public CustomValidationException(string message,
            object validationResult, object model)
            : base(message)
        {
            _ValidationResult = validationResult;
            _Model = model;

        }

        public CustomValidationException(string message,
            object validationResult)
            : base(message)
        {
            _ValidationResult = validationResult;            
        }
        public CustomValidationException(string message,
            System.Exception innerException, object validationResult, object model)
            : base(message, innerException)
        {
            _ValidationResult = validationResult;
            _Model = model;

        }
    }
}
