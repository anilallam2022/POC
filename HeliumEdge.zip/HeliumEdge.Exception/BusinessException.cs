﻿namespace HeliumEdge.Exception
{
    public class BusinessException : BaseException
    {
        public BusinessException(string message, int statusCode): base(message, statusCode)
        {
        }
    }
}
