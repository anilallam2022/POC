﻿namespace HeliumEdge.Security
{
    using Microsoft.AspNetCore.Authorization;

    public class UserRoleRequirement : IAuthorizationRequirement
    {
        public string Role { get; private set; }

        public UserRoleRequirement(string role)
        {
            Role = role;
        }
    }
}
