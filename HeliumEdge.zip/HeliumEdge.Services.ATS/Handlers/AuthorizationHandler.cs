﻿using HeliumEdge.Security;
using Microsoft.AspNetCore.Authorization;
using System.Threading.Tasks;
using System.Linq;

namespace HeliumEdge.Services.ATS.Handlers
{
    public class AuthorizationHandler : AuthorizationHandler<UserRoleRequirement>
    {
        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, UserRoleRequirement requirement)
        {
            if (context.User.Claims.Where(x =>x.Type == "Role").FirstOrDefault()?.Value == requirement.Role)
            {
                context.Succeed(requirement);
            }
            return Task.FromResult(0);
        }
    }
}
