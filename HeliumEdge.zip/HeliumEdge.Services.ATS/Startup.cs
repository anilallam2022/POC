﻿using HeliumEdge.BusinessObjects.ATS;
using HeliumEdge.Core;
using HeliumEdge.DataAccess.ATS;
using HeliumEdge.Logging;
using HeliumEdge.Security;
using HeliumEdge.Services.ATS.Filters;
using HeliumEdge.Services.ATS.Middleware;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Authorization;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using NLog.Extensions.Logging;
using NLog.Web;
using Swashbuckle.AspNetCore.Swagger;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace HeliumEdge.Services.ATS
{
    public class Startup
    {
        public IConfiguration configuration { get; }
        public Startup(IConfiguration configuration)
        {
            this.configuration = configuration;
        }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {

            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
            .AddJwtBearer(options =>
            {
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateLifetime = true,
                    ValidateIssuerSigningKey = true,
                    ValidIssuer = configuration["Jwt:Issuer"],
                    ValidAudience = configuration["Jwt:Audience"],
                    IssuerSigningKey = new SymmetricSecurityKey(
                        Encoding.UTF8.GetBytes(configuration["Jwt:Key"]))
                };

                // Use this events to check the error on token validation failed on local
                options.Events = new JwtBearerEvents
                {
                    OnAuthenticationFailed = context =>
                    {
                        return Task.CompletedTask;
                    }
                };
            });

            services.AddAuthorization(options =>
            {
                options.AddPolicy("RequireUserRole", policy => policy.Requirements.Add(new UserRoleRequirement("Recruiter")));
                options.AddPolicy("RequireAdministratorRole", policy => policy.Requirements.Add(new UserRoleRequirement("Administrator")));
            });

            services.AddSingleton<IAuthorizationHandler, Handlers.AuthorizationHandler>();


            // Adding CORS filter for the angular app
            services.AddCors(o => o.AddPolicy("AngularAppCORSPolicy", builder =>
            {
                builder.WithOrigins(
                    "http://localhost:4200",
                    "https://heldev.azurewebsites.net",
                    "http://dev.heliumats.com",
                    "https://dev.heliumats.com",
                    "https://qa.heliumats.com",
                    "http://qa.heliumats.com",
                    "https://helqaui.azurewebsites.net",
                    "http://helqaui.azurewebsites.net")
                       .AllowAnyMethod()
                       .AllowAnyHeader();
            }));

            // Dependency Injections
            services.AddScoped<IDbContext, DbContext>(ctx => new DbContext(configuration.GetConnectionString("HeliumEdgeDbConnection")));
            services.AddScoped<IBlobService, BlobService>();


            services.AddScoped<JobManager>();
            services.AddScoped<JobRepository>();

            services.AddScoped<ContactManager>();
            services.AddScoped<ContactRepository>();

            services.AddScoped<CandidateManager>();
            services.AddScoped<CandidateRepository>();

            services.AddScoped<CompanyManager>();
            services.AddScoped<CompanyRepository>();

            services.AddScoped<TaskManager>();
            services.AddScoped<TaskRepository>();

            services.AddScoped<EventManager>();
            services.AddScoped<EventRepository>();

            services.AddScoped<NoteManager>();
            services.AddScoped<NoteRepository>();

            services.AddScoped<ReminderManager>();
            services.AddScoped<ReminderRepository>();

            services.AddScoped<MasterDataManager>();
            services.AddScoped<MasterDataRepository>();

            services.AddScoped<ListPageColumnManager>();
            services.AddScoped<ListPageColumnRepository>();

            services.AddScoped<UserManager>();
            services.AddScoped<UserRepository>();

            services.AddScoped<SecurityManager>();
            services.AddScoped<SecurityRepository>();

            services.AddScoped<RoleManager>();
            services.AddScoped<RoleRepository>();

            services.AddSingleton<IAsyncLoggerFactory, NLogAsyncLoggerFactory>(ctx => new NLogAsyncLoggerFactory(ctx.GetRequiredService<ILoggerFactory>()));

            services.AddScoped<FileStorageManager>();
            services.AddScoped<FileStorageRepository>();

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Info
                {
                    Version = "v1",
                    Title = "Helium Edge API",
                    Description = "Helium Edge API",
                    TermsOfService = "None"
                });
                c.IncludeXmlComments("HeliumEdge.Services.ATS.xml");
                var security = new Dictionary<string, IEnumerable<string>>
                {
                    {"Bearer", new string[] { }},
                };

                c.AddSecurityDefinition("Bearer", new ApiKeyScheme
                {
                    Description = "JWT Authorization header using the Bearer scheme. Example: \"Bearer {token}\". Valid token can be retrieved from /api/Token/Login.",
                    Name = "Authorization",
                    In = "header",
                    Type = "apiKey"
                });
                c.AddSecurityRequirement(security);
            });

            services.AddMvc(options =>
            {
                options.Filters.Add(typeof(ExceptionFilter));
                var policy = new AuthorizationPolicyBuilder()
                .RequireAuthenticatedUser()
                .Build();
                options.Filters.Add(new AuthorizeFilter(policy));
            })
            .AddJsonOptions(option =>
            {
                option.SerializerSettings.ContractResolver = new Newtonsoft.Json.Serialization.CamelCasePropertyNamesContractResolver();
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory)
        {

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            //Add NLog coniguration
            env.ConfigureNLog("NLog.config");
            loggerFactory.AddNLog();

            // Enabling CORS for all the routes
            app.UseCors("AngularAppCORSPolicy");

            //Inject Helium Response middleware for all requests except Swagger requests & attachment download request
            app.UseWhen(context => !(context.Request.Path.StartsWithSegments("/api/attachments/download", System.StringComparison.InvariantCultureIgnoreCase) 
                        || context.Request.Path.StartsWithSegments("/swagger", System.StringComparison.InvariantCultureIgnoreCase)),
                            builder => { builder.UseResponseWrapper(); });
            
            app.UseAuthentication();
            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "Helium Edge API");
            });
            app.UseMvc();
        }
    }
}
