﻿using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HeliumEdge.Services.ATS.Helpers
{
    public static class RedisConnectionHelper
    {
        private static Lazy<ConnectionMultiplexer> connection = new Lazy<ConnectionMultiplexer>(() =>
        {
            return ConnectionMultiplexer.Connect("Heldev.redis.cache.windows.net:6380,password=a2dLV/MM/z72Fui8CFOsmvmTTzmmh2T5z8jXgUbSRZ4=,ssl=True,abortConnect=False");
        });

        public static ConnectionMultiplexer Instance { get { return connection.Value; } }
    }
}
