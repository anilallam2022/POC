﻿using System.Threading.Tasks;
using HeliumEdge.BusinessObjects.ATS;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.SwaggerGen;

namespace HeliumEdge.Services.ATS.Controllers
{
    /// <summary>
    /// Role Controller
    /// </summary>
    [Produces("application/json")]
    [Route("api/Roles")]
    public class RoleController : Controller    {

        private readonly RoleManager roleManager;

        /// <summary>
        ///  Constructor
        /// </summary>
        /// <param name="roleManager">role nanager</param>
        public RoleController(RoleManager roleManager)
        {
            this.roleManager = roleManager;
        }

        /// <summary>
        /// Search users by text
        /// </summary>
        /// <returns></returns>
        [SwaggerOperation(Tags = new[] { "Roles" })]
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var data = await roleManager.GetRoles();
            return Ok(data);
        }

    }
}
