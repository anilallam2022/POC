﻿using HeliumEdge.BusinessObjects.ATS;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Swashbuckle.AspNetCore.SwaggerGen;
using HeliumEdge.DataTransfer.ATS;
using StackExchange.Redis;
using HeliumEdge.Services.ATS.Helpers;
using System.Linq;
using System.Collections.Generic;
using System;
using Microsoft.AspNetCore.Authorization;

namespace HeliumEdge.Services.ATS.Controllers
{
    [Produces("application/json")]
    [Route("api/Notes")]
    public class NoteController : Controller
    {
        private readonly NoteManager noteManager;
        public NoteController(NoteManager noteManager)
        {
            this.noteManager = noteManager;
        }

        [SwaggerOperation(Tags = new[] { "Notes" })]
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var data = await noteManager.GetAllAsync();
            return Ok(data);
        }

        [SwaggerOperation(Tags = new[] { "Notes" })]
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(NoteViewDTO), 200)]
        public async Task<IActionResult> Get(int id)
        {
            var data = await noteManager.GetAsync(id);
            return Ok(data);
        }

        [SwaggerOperation(Tags = new[] { "Notes" })]
        [HttpPost]
        public async Task<IActionResult> Post([FromBody]NoteDTO model)
        {            
            var result = await noteManager.CreateAsync(model);
            return Ok(result);
        }
    }
}
