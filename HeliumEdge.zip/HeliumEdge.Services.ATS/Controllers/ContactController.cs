﻿using System;
using System.Threading.Tasks;
using HeliumEdge.BusinessObjects.ATS;
using HeliumEdge.DataTransfer.ATS;
using Microsoft.AspNetCore.Mvc;
using StackExchange.Redis;
using Swashbuckle.AspNetCore.SwaggerGen;
using System.Linq;
using HeliumEdge.Services.ATS.Helpers;
using System.Collections.Generic;

namespace HeliumEdge.Services.ATS.Controllers
{
    [Produces("application/json")]
    [Route("api/Contacts")]
    public class ContactController : Controller
    {
        private readonly ContactManager contactManager;
        public ContactController(ContactManager contactManager)
        {
            this.contactManager = contactManager;
        }

        /// <summary>
        /// Get contacts for list page
        /// </summary>
        /// <param name="filterDTO"></param>
        /// <returns></returns>
        [SwaggerOperation(Tags = new[] { "Contacts" })]
        [HttpPost(nameof(List))]
        public async Task<IActionResult> List([FromBody] ListPageRequestDTO filterDTO)
        {
            filterDTO.SetEntityType("Contact");
            var data = await contactManager.GetAllAsync(filterDTO);
            return Ok(data);
        }

        /// <summary>
        /// Get Contact details by Id
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        [SwaggerOperation(Tags = new[] { "Contacts" })]
        [HttpGet("{id:int}")]
        public async Task<IActionResult> Get(int id)
        {
            var contact = await contactManager.GetAsync(id);
            return Ok(contact);
        }

        /// <summary>
        /// Get Contact Basic View Details by id
        /// </summary>
        /// <param name="id">contact id</param>
        /// <returns></returns>
        [SwaggerOperation(Tags = new[] { "Contacts" })]
        [HttpGet("View/{id}")]
        [ProducesResponseType(typeof(ContactViewDTO), 200)]
        public async Task<IActionResult> GetContactView(int id)
        {
            var data = await contactManager.GetViewAsync(id);
            return Ok(data);
        }

        [SwaggerOperation(Tags = new[] { "Contacts" })]
        [HttpGet("{name}")]
        public async Task<IActionResult> GetByName(string name)
        {
            var contact = await contactManager.GetAllByNameAsync(name);
            return Ok(contact);
        }

        /// <summary>
        /// Searches for contact first name and last name with the provided search string and returns the matched records with Id and Name. This method is mainly useful for lookup data.
        /// </summary>
        /// <returns></returns>
        [SwaggerOperation(Tags = new[] { "Contacts" })]
        [HttpGet("Search")]
        public async Task<IActionResult> Search(string text)
        {
            var data = await contactManager.Search(text);
            return Ok(data);
        }

        /// <summary>
        /// Searches unassigned contact's first name and last name with the provided search string and returns the matched records with Id and Name. This method is mainly useful for lookup data.
        /// </summary>
        /// <returns></returns>
        [SwaggerOperation(Tags = new[] { "Contacts" })]
        [HttpGet("SearchUnassigned")]
        public async Task<IActionResult> SearchUnassigned(string text)
        {
            var data = await contactManager.SearchUnassigned(text);
            return Ok(data);
        }

        /// <summary>
        /// Create a new contact
        /// </summary>
        /// <param name="contact">Contact Object</param>
        /// <returns></returns>
        [SwaggerOperation(Tags = new[] { "Contacts" })]
        [HttpPost]
        public async Task<IActionResult> Post([FromBody]ContactDTO contact)
        {
            var result = await contactManager.CreateAsync(contact);
            return Ok(result);
        }

        /// <summary>
        /// Change one or more contacts status
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [SwaggerOperation(Tags = new[] { "Contacts" })]
        [HttpPost("ChangeStatus")]
        public async Task<IActionResult> ChangeStatus([FromBody] EntitiesStatusDTO model)
        {
            var result = await contactManager.ChangeStatusAsync(model);
            return Ok(result);
        }

        [SwaggerOperation(Tags = new[] { "Contacts" })]
        // POST: api/Company
        [HttpGet("GetContactList")]
        public async Task<IActionResult> GetContactList()
        {
            var data = await contactManager.GetContactList();
            return Ok(data);
        }

        [SwaggerOperation(Tags = new[] { "Contacts" })]
        // Delete: api/Job
        [HttpDelete("Delete")]
        public async Task<IActionResult> Delete(List<int> ids)
        {
            var data = await contactManager.Delete(ids);
            return Ok(data);
        }

        /// <summary>
        /// Searches for contact first name and last name with the provided search string and returns the matched records with Id and Name. This method is mainly useful for lookup data.
        /// </summary>
        /// <returns></returns>
        [SwaggerOperation(Tags = new[] { "Contacts" })]
        [HttpGet("SearchByCompanyId")]
        public async Task<IActionResult> SearchByCompanyId(int companyId, string text)
        {
            var data = await contactManager.SearchByCompanyId(companyId, text);
            return Ok(data);
        }
    }
}