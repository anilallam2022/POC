﻿using HeliumEdge.BusinessObjects.ATS;
using HeliumEdge.DataTransfer.ATS;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.SwaggerGen;
using System.Threading.Tasks;

namespace HeliumEdge.Services.ATS.Controllers
{
    [Produces("application/json")]
    [Route("api/Events")]
    public class EventController : Controller
    {
        private readonly EventManager eventManager;
        public EventController(EventManager eventManager)
        {
            this.eventManager = eventManager;
        }

        [SwaggerOperation(Tags = new[] { "Events" })]
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var data = await eventManager.GetAllAsync();
            return Ok(data);
        }

        [SwaggerOperation(Tags = new[] { "Events" })]
        // GET: api/Event/1
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(EventViewDTO), 200)]
        public async Task<IActionResult> Get(int id)
        {
            var data = await eventManager.GetAsync(id);
            return Ok(data);
        }

        [SwaggerOperation(Tags = new[] { "Events" })]
        // POST: api/Event
        [HttpPost]
        public async Task<IActionResult> Post([FromBody]EventDTO dto)
        {
            var data = await eventManager.CreateAsync(dto);
            return Ok(data);
        }
    }
}
