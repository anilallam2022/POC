﻿using HeliumEdge.BusinessObjects.ATS;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Swashbuckle.AspNetCore.SwaggerGen;
using HeliumEdge.DataTransfer.ATS;
using System.Collections.Generic;
using System.Linq;
using System;

namespace HeliumEdge.Services.ATS.Controllers
{
    [Produces("application/json")]
    [Route("api/Tasks")]
    public class TaskController : Controller
    {
        private readonly TaskManager taskManager;
        public TaskController(TaskManager taskManager)
        {
            this.taskManager = taskManager;
        }

        [SwaggerOperation(Tags = new[] { "Tasks" })]
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var data = await taskManager.GetAllAsync();
            return Ok(data);
        }

        [SwaggerOperation(Tags = new[] { "Tasks" })]
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(TaskViewDTO), 200)]
        public async Task<IActionResult> Get(int id)
        {
            var data = await taskManager.GetAsync(id);
            return Ok(data);
        }

        [SwaggerOperation(Tags = new[] { "Tasks" })]
        [HttpPost]
        public async Task<IActionResult> Post([FromBody]TaskDTO model)
        {
            var data = await taskManager.CreateAsync(model);            
            return Ok(data);
        }
    }
}