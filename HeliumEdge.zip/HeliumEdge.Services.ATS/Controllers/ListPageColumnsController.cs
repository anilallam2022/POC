﻿using HeliumEdge.BusinessObjects.ATS;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.SwaggerGen;
using System.Threading.Tasks;

namespace HeliumEdge.Services.ATS.Controllers
{
    [Produces("application/json")]
    [Route("api/ListPageColumns")]
    public class ListPageColumnsController : Controller
    {
        private readonly ListPageColumnManager listPageColumnManager;
        public ListPageColumnsController(ListPageColumnManager listPageColumnManager)
        {
            this.listPageColumnManager = listPageColumnManager;
        }

        [SwaggerOperation(Tags = new[] { "ListPageColumns" })]
        [HttpGet("")]
        public async Task<IActionResult> Get(string entity)
        {
            return Ok(await listPageColumnManager.GetColumnListByEntity(entity));
        }

        //[SwaggerOperation(Tags = new[] { "ListPageColumns" })]
        //[HttpGet("UserSaved")]
        //public async Task<IActionResult> UserColumns(string entity)
        //{
        //    int userId = 0;
        //    return Ok(await listPageColumnManager.GetUserColumnListByEntity(entity, userId));
        //}
    }
}