﻿using HeliumEdge.BusinessObjects.ATS;
using HeliumEdge.DataObjects.ATS;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Threading.Tasks;

namespace HeliumEdge.Services.ATS.Controllers
{
    /// <summary>
    /// Token Controller
    /// </summary>
    [Produces("application/json")]
    [Route("api/Token")]
    public class TokenController : Controller
    {
        private readonly SecurityManager securityManager;
        public IConfiguration configuration { get; }

        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="securityManager"></param>
        /// <param name="configuration"></param>
        public TokenController(SecurityManager securityManager, IConfiguration configuration)
        {
            this.securityManager = securityManager;
            this.configuration = configuration;
        }

        /// <summary>
        /// Returns User permissions
        /// </summary>
        /// <param name="id">user id</param>
        /// <returns></returns>
        [HttpGet]
        public IActionResult GetUserPermissions(int id)
        {
            var result = this.securityManager.GetUserPermissionsAsync(id).Result;
            return Ok(result);
        }

        /// <summary>
        /// Returns token if the credentials are correct
        /// </summary>
        /// <param name="login">login model</param>
        /// <returns></returns>
        [AllowAnonymous]
        [HttpPost("Login")]
        public async Task<IActionResult> Login([FromBody]LoginModel login)
        {
            var user = await securityManager.Authenticate(login);

            if (user != null)
            {
                var tokenString = securityManager.BuildToken(user, login.Email, login.Password, configuration["Jwt:Key"], configuration["Jwt:Issuer"], configuration["Jwt:Audience"], Convert.ToDouble(configuration["Jwt:TokenLifetimeMinutes"]));
                return Ok(new { Token = tokenString, Type = "Bearer" });
            }

            return BadRequest("Invalid credentials.");
        }
    }
}
