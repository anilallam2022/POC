﻿using HeliumEdge.BusinessObjects.ATS;
using HeliumEdge.DataTransfer.ATS;
using HeliumEdge.Logging;
using HeliumEdge.Services.ATS.Helpers;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.SwaggerGen;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HeliumEdge.Services.ATS.Controllers
{
    /// <summary>
    /// Candidate Controller
    /// </summary>
    [Produces("application/json")]
    [Route("api/Candidates")]
    public class CandidateController : Controller
    {
        private readonly CandidateManager candidateManager;
        private readonly IAsyncLogger<CandidateController> logger;
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="candidateManager"></param>
        /// <param name="asyncLoggerFactory"></param>
        public CandidateController(CandidateManager candidateManager, IAsyncLoggerFactory asyncLoggerFactory)
        {
            this.candidateManager = candidateManager;
            this.logger = asyncLoggerFactory.GetLogger<CandidateController>();
        }

        /// <summary>
        /// Get records for list page
        /// </summary>
        /// <param name="filterDTO"></param>
        /// <returns></returns>
        [SwaggerOperation(Tags = new[] { "Candidates" })]
        [HttpPost(nameof(List))]
        public async Task<IActionResult> List([FromBody] ListPageRequestDTO filterDTO)
        {
            logger.Info("Inside list method", new { Sample =1 });
            filterDTO.SetEntityType("Candidate");
            var data = await candidateManager.GetAllAsync(filterDTO);
            return Ok(data);
        }

        [SwaggerOperation(Tags = new[] { "Candidates" })]
        [HttpGet("GetViewListItems")]
        public async Task<IActionResult> GetViewListItems()
        {
            var data = await candidateManager.GetViewListItems();
            return Ok(data);
        }

        /// <summary>
        /// Searches for candidate first name, middle name and last name with the provided search string and returns the matched records with Id and Name. This method is mainly useful for lookup data.
        /// </summary>
        /// <returns></returns>
        [SwaggerOperation(Tags = new[] { "Candidates" })]
        [HttpGet("Search")]
        public async Task<IActionResult> Search(string text)
        {
            var data = await candidateManager.Search(text);
            return Ok(data);
        }

        /// <summary>
        /// Get Candidates by Candidate id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [SwaggerOperation(Tags = new[] { "Candidates" })]
        [HttpGet("{id}", Name = "GetCandidate")]
        [ProducesResponseType(typeof(CandidateDTO),200)]
        public async Task<IActionResult> GetCandidate(int id)
        {
            var data = await candidateManager.GetAsync(id);
            return Ok(data);
        }

        /// <summary>
        /// Get Candidate Basic View Details by id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [SwaggerOperation(Tags = new[] { "Candidates" })]
        [HttpGet("View/{id}")]
        [ProducesResponseType(typeof(CandidateViewDTO), 200)]
        public async Task<IActionResult> GetCandidateView(int id)
        {
            var data = await candidateManager.GetViewAsync(id);
            return Ok(data);
        }

        /// <summary>
        /// Save Candidate
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [SwaggerOperation(Tags = new[] { "Candidates" })]
        // POST: api/Candidate
        [HttpPost]
        public async Task<IActionResult> Post([FromBody]CandidateDTO model)
        {
            var data = await candidateManager.CreateAsync(model);
            return Ok(data);
        }

        /// <summary>
        /// Delete Candidates by Candidate Ids
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        [SwaggerOperation(Tags = new[] { "Candidates" })]
        // Delete: api/Job
        [HttpDelete("Delete")]
        public async Task<IActionResult> Delete(List<int> ids)
        {
            var data = await candidateManager.Delete(ids);
            return Ok(data);
        }

        /// <summary>
        /// Change one or more candidates status
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [SwaggerOperation(Tags = new[] { "Candidates" })]
        [HttpPost("ChangeStatus")]
        public async Task<IActionResult> ChangeStatus([FromBody] EntitiesStatusDTO model)
        {
            var result = await candidateManager.ChangeStatusAsync(model);
            return Ok(result);
        }
    }
}
