﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HeliumEdge.BusinessObjects.ATS;
using HeliumEdge.Core;
using HeliumEdge.Exception;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.SwaggerGen;

namespace HeliumEdge.Services.ATS.Controllers
{
    [Produces("application/json")]
    [Route("api/Attachments")]
    public class AttachmentsController : Controller
    {
        private readonly FileStorageManager fileStorageManager;
        private readonly IBlobService blobService;

        public AttachmentsController(FileStorageManager fileStorageManager, IBlobService blobService)
        {
            this.fileStorageManager = fileStorageManager;
            this.blobService = blobService;
        }

        /// <summary>
        /// Returns attachment path for a given attachment id
        /// </summary>
        /// <param name="id">Attachment ID</param>
        /// <returns></returns>
        [SwaggerOperation(Tags = new[] { "Attachments" })]
        [HttpGet("{id:int}", Name = "GetFile")]
        public async Task<IActionResult> Get(int id)
        {
            var tenant = "Tenant1"; //TODO: replace tenant from claims
            var data = await fileStorageManager.GetAsync(id);
            var blobAttributes = await blobService.GetFileSasUrlAsync(data.StorageFileName, tenant.ToLower(), data.FilePath.ToLower());
            return Ok(blobAttributes?.Path);
        }

        /// <summary>
        /// Returns attachment content bytes for a given attachment id
        /// </summary>
        /// <param name="id">Attachment ID</param>
        /// <returns></returns>
        [SwaggerOperation(Tags = new[] { "Attachments" })]
        [HttpGet("download/{id:int}", Name = "Download")]        
        public async Task<IActionResult> Download(int id)
        {
            try
            {
                var data = await fileStorageManager.GetAsync(id);
                var tenant = "Tenant1"; //TODO: replace tenant from claims
                var content = await blobService.GetFileDataAsync(data.StorageFileName, tenant.ToLower(), data.FilePath.ToLower());
                return File(content, "application/octet-stream", data.FileName);
            }
            catch (BusinessException ex)
            {
                return NotFound(ex.Message);
            }
            catch(System.Exception ex)
            {
                return new ObjectResult(ex.Message) { StatusCode = StatusCodes.Status500InternalServerError };
            }
        }

        /// <summary>
        /// Endpoint to upload file data (Base64Encoded) in chunks. Request header should contain parameters for "ChunkIndex", "TotalChunks", "Module", "FileName" and "StorageFileName". During the first chunk upload request FileReferenceName should be null and API will send back FileReferenceName in the API Response. For the next chunk uploading this FileReferenceName should be sent to API to append the content to the same file.
        /// </summary>
        /// <param name="content"></param>
        /// <returns></returns>
        [SwaggerOperation(Tags = new[] { "Attachments" })]
        [HttpPost]
        public async Task<IActionResult> Post([FromBody] string content)
        {
            //Read file details from Request Header
            if (!Request.Headers.TryGetValue("FileName", out var fileName) || !Request.Headers.TryGetValue("Module", out var module)
                    || !(Request.Headers.TryGetValue("chunkIndex", out var chunkIndexValue) && !string.IsNullOrWhiteSpace(chunkIndexValue) && int.TryParse(chunkIndexValue, out int chunkIndex))
                    || !(Request.Headers.TryGetValue("totalChunks", out var totalChunksValue) && !string.IsNullOrWhiteSpace(totalChunksValue) && int.TryParse(totalChunksValue, out int totalChunks) && totalChunks > 0 && chunkIndex < totalChunks)
                    || !(chunkIndex ==0 ||(chunkIndex > 0 && Request.Headers.TryGetValue("StorageFileName", out var uniqueFileName) && !string.IsNullOrWhiteSpace(uniqueFileName))))
            {
                return BadRequest("Invalid Request Headers");
            }

            content = content.Contains(";base64,") ? content.Split(";base64,")[1] : content;
            
            var tenant = "Tenant1"; //TODO: replace tenant from claims
            var blob = await blobService.UploadFileChunkAsync(chunkIndex, Convert.FromBase64String(content), 
                        (string.IsNullOrWhiteSpace(uniqueFileName) ? $"{Guid.NewGuid().ToString()}_{fileName}" : uniqueFileName.ToString()), 
                        tenant.ToLower(), module.ToString().ToLower(), chunkIndex == totalChunks - 1);

            return Ok(new { Status = true, StorageFileName = blob.Name });
        }
    }
}