﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HeliumEdge.BusinessObjects.ATS;
using HeliumEdge.DataTransfer.ATS;
using HeliumEdge.Services.ATS.Helpers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using StackExchange.Redis;
using Swashbuckle.AspNetCore.SwaggerGen;

namespace HeliumEdge.Services.ATS.Controllers
{
    [Produces("application/json")]
    [Route("api/Companies")]
    public class CompanyController : Controller
    {
        private readonly CompanyManager companyManager;

        public CompanyController(CompanyManager companyManager, ILogger<CompanyController> logger)
        {
            this.companyManager = companyManager;
        }

        /// <summary>
        /// Get the companies for list page
        /// </summary>
        /// <param name="filterDTO"></param>
        /// <returns></returns>
        [SwaggerOperation(Tags = new[] { "Companies" })]
        [HttpPost(nameof(List))]
        public async Task<IActionResult> List([FromBody]ListPageRequestDTO filterDTO)
        {
            filterDTO.SetEntityType("Company");
            var data = await companyManager.GetAllAsync(filterDTO);
            return Ok(data);
        }

        [SwaggerOperation(Tags = new[] { "Companies" })]
        [HttpGet("GetViewListItems")]
        public async Task<IActionResult> GetViewListItems()
        {
            var data = await companyManager.GetViewListItems();
            return Ok(data);
        }

        /// <summary>
        /// Get Company basic view details by Id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [SwaggerOperation(Tags = new[] { "Companies" })]
        [HttpGet("View/{id}")]
        [ProducesResponseType(typeof(CompanyViewDTO), 200)]
        public async Task<IActionResult> GetCompanyView(int id)
        {
            var data = await companyManager.GetViewAsync(id);
            if (data is null)
            {
                return NotFound("Record might have been deleted or doesn't exist");
            }
            return Ok(data);
        }

        /// <summary>
        /// Searches company name with the provided search string and returns the matched records with Id and Name. This method is mainly useful for lookup data.
        /// </summary>
        /// <returns></returns>
        [SwaggerOperation(Tags = new[] { "Companies" })]
        [HttpGet("Search")]
        public async Task<IActionResult> Search(string text)
        {
            var data = await companyManager.Search(text);
            return Ok(data);
        }

        [SwaggerOperation(Tags = new[] { "Companies" })]
        [HttpGet("{name}")]
        public async Task<IActionResult> GetByName(string name)
        {
            var contact = await companyManager.GetAllByNameAsync(name);
            return Ok(contact);
        }

        /// <summary>
        /// Get company details by Id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [SwaggerOperation(Tags = new[] { "Companies" })]
        [HttpGet("{id:int}", Name = "GetCompany")]
        public async Task<IActionResult> Get(int id)
        {
            var data = await companyManager.GetAsync(id);
            return Ok(data);
        }

        /// <summary>
        /// Create new Company
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [SwaggerOperation(Tags = new[] { "Companies" })]
        [HttpPost]
        public async Task<IActionResult> Post([FromBody]CompanyDTO model)
        {
            var data = await companyManager.CreateAsync(model);
            return Ok(data);
        }

        [SwaggerOperation(Tags = new[] { "Companies" })]
        [HttpGet("GetCompaninesList")]
        public async Task<IActionResult> GetCompaninesList()
        {
            var data = await companyManager.GetCompaniesList();
            return Ok(data);
        }

        /// <summary>
        /// Delete companies by the given Id(s).
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        [SwaggerOperation(Tags = new[] { "Companies" })]
        [HttpDelete("Delete")]
        public async Task<IActionResult> Delete(List<int> ids)
        {
            var data = await companyManager.Delete(ids);
            return Ok(data);
        }

        [SwaggerOperation(Tags = new[] { "Companies" })]
        [HttpGet("GetPlacementFee")]
        public async Task<IActionResult> GetPlacementFee(int id)
        {
            var data = await companyManager.GetPlacementFee(id).ConfigureAwait(false);
            return Ok(data);
        }

        [SwaggerOperation(Tags = new[] { "Companies" })]
        [HttpPost("ChangeStatus")]
        public async Task<IActionResult> ChangeStatus([FromBody] EntitiesStatusDTO model)
        {
            var data = await companyManager.ChangeStatusAsync(model);
            return Ok(data);
        }
    }
}