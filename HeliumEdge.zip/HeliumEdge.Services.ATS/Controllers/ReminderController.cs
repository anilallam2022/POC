﻿using HeliumEdge.BusinessObjects.ATS;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Swashbuckle.AspNetCore.SwaggerGen;
using HeliumEdge.DataTransfer.ATS;

namespace HeliumEdge.Services.ATS.Controllers
{
    [Produces("application/json")]
    [Route("api/Reminders")]
    public class ReminderController : Controller
    {
        private readonly ReminderManager reminderManager;
        public ReminderController(ReminderManager reminderManager)
        {
            this.reminderManager = reminderManager;
        }

        [SwaggerOperation(Tags = new[] { "Reminders" })]
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var data = await reminderManager.GetAllAsync();
            return Ok(data);
        }

        [SwaggerOperation(Tags = new[] { "Reminders" })]
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(ReminderViewDTO), 200)]
        public async Task<IActionResult> Get(int id)
        {
            var data = await reminderManager.GetAsync(id);
            return Ok(data);
        }

        [SwaggerOperation(Tags = new[] { "Reminders" })]
        [HttpPost]
        public async Task<IActionResult> Post([FromBody]ReminderDTO dto)
        {
            var data = await reminderManager.CreateAsync(dto);
            return Ok(data);
        }
    }
}
