﻿using HeliumEdge.BusinessObjects.ATS;
using HeliumEdge.DataTransfer.ATS;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.SwaggerGen;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HeliumEdge.Services.ATS.Controllers
{
    [Produces("application/json")]
    [Route("api/Jobs")]
    public class JobController : Controller
    {
        private readonly JobManager jobManager;
        public JobController(JobManager jobManager)
        {
            this.jobManager = jobManager;
        }

        /// <summary>
        /// Get Jobs for list page
        /// </summary>
        /// <param name="filterDTO"></param>
        /// <returns></returns>
        [SwaggerOperation(Tags = new[] { "Jobs" })]
        [HttpPost(nameof(List))]
        public async Task<IActionResult> List([FromBody] ListPageRequestDTO filterDTO)
        {
            filterDTO.SetEntityType("Job");
            var data = await jobManager.GetAllAsync(filterDTO);
            return Ok(data);
        }

        [SwaggerOperation(Tags = new[] { "Jobs" })]
        [HttpGet("GetViewListItems/{userId}")]
        public async Task<IActionResult> GetViewListItems(int userId)
        {
            var data = await jobManager.GetViewListItems(userId);
            return Ok(data);
        }

        /// <summary>
        /// Searches Job Title with the provided search string and returns the matched records with Id and Name. This method is mainly useful for lookup data.
        /// </summary>
        /// <returns></returns>
        [SwaggerOperation(Tags = new[] { "Jobs" })]
        [HttpGet("Search")]
        public async Task<IActionResult> Search(string text)
        {
            var data = await jobManager.Search(text);
            return Ok(data);
        }

        /// <summary>
        /// Get Job details by Id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [SwaggerOperation(Tags = new[] { "Jobs" })]
        // GET: api/Job/1
        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            var data = await jobManager.GetAsync(id);
            return Ok(data);
        }

        /// <summary>
        /// Create new Job
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [SwaggerOperation(Tags = new[] { "Jobs" })]
        // POST: api/Job
        [HttpPost("")]
        public async Task<IActionResult> Post([FromBody]JobDTO model)
        {
            var data = await jobManager.CreateAsync(model);
            return Ok(data);
        }

        [SwaggerOperation(Tags = new[] { "Jobs" })]
        // POST: api/Job
        [HttpDelete("Delete")]
        public async Task<IActionResult> Delete(List<int> ids)
        {
            var data = await jobManager.Delete(ids);
            return Ok(data);
        }

        [SwaggerOperation(Tags = new[] { "Jobs" })]
        // GET: api/DuplicateCheck
        [HttpGet("DuplicateCheck/{title}/{companyId}")]
        public async Task<IActionResult> DuplicateCheck(string title, int companyId)
        {
            var data = await jobManager.GetDuplicateCheckAsync(title, companyId);
            return Ok(data);
        }

        [SwaggerOperation(Tags = new[] { "Jobs" })]
        // GET: api/GetClone
        [HttpGet("GetClone")]
        public async Task<IActionResult> GetClone(int jobId)
        {
            var data = await jobManager.GetCloneAsync(jobId);
            return Ok(data);
        }


        [SwaggerOperation(Tags = new[] { "Jobs" })]
        // POST: api/Job
        [HttpPost("ChangeStatus")]
        public async Task<IActionResult> StatusAsync([FromBody] ChangeStatusDTO changeStatus)
        {
            var data = await jobManager.Status(changeStatus);
            return Ok(data);
        }


        [SwaggerOperation(Tags = new[] { "Jobs" })]
        // POST: api/Job
        [HttpGet("CompanyDetailsById/{companyId}")]
        public async Task<IActionResult> GetCompanyDetailsById(int companyId)
        {
            var data = await jobManager.GetCompanyDetailsById(companyId);
            return Ok(data);
        }

        [SwaggerOperation(Tags = new [] { "Jobs" })]
        [HttpGet("View/{jobId}")]
        public async Task<IActionResult> GetView(int jobId)
        {
            var data = await jobManager.GetView(jobId);
            return Ok(data);
        }
    }
}
