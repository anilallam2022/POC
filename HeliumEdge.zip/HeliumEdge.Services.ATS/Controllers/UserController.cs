﻿using System;
using System.Threading.Tasks;
using HeliumEdge.BusinessObjects.ATS;
using HeliumEdge.DataTransfer.ATS;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.SwaggerGen;

namespace HeliumEdge.Services.ATS.Controllers
{
    /// <summary>
    /// User Controller
    /// </summary>
    [Produces("application/json")]
    [Route("api/Users")]
    public class UserController : Controller
    {

        private readonly UserManager userManager;

        /// <summary>
        ///  Constructor
        /// </summary>
        /// <param name="userManager"></param>
        public UserController(UserManager userManager)
        {
            this.userManager = userManager;
        }

        /// <summary>
        /// Search users by text
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        [SwaggerOperation(Tags = new[] { "Users" })]
        [HttpGet("Search")]
        public async Task<IActionResult> Search(string text)
        {
            var data = await userManager.Search(text);
            return Ok(data);
        }

        /// <summary>
        /// Registers the user in a tenant
        /// </summary>
        /// <param name="user">User DTO</param>
        /// <returns></returns>
        [SwaggerOperation(Tags = new[] { "Users" })]
        // POST: api/Users
        [HttpPost]
        [Authorize(Policy = "RequireAdministratorRole")]
        public async Task<IActionResult> Register([FromBody]UserDTO user)
        {
            try
            {
                var data = await userManager.Register(user);
                return Ok(data);
            }
            catch(System.Exception ex)
            {
                return BadRequest(ex.Message);
            }
            
        }

    }
}
