﻿using HeliumEdge.BusinessObjects.ATS;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.SwaggerGen;
using System.Threading.Tasks;

namespace HeliumEdge.Services.ATS.Controllers
{
    [Produces("application/json")]
    [Route("api/Lookup")]
    public class LookupController : Controller
    {
        private readonly MasterDataManager manager;
        public LookupController(MasterDataManager masterDataManager)
        {
            this.manager = masterDataManager;
        }
        
        [SwaggerOperation(Tags = new[] { "Lookup" })]
        [HttpGet("{moduleName}")]
        public async Task<IActionResult> GetLookupByModule(string moduleName)
        {
            var data = await manager.GetLookUpItemsByModule(moduleName);
            return Ok(data);
        }
    }
}