﻿using HeliumEdge.Core;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System;
using System.IO;
using System.Threading.Tasks;
using HeliumEdge.Exception;
using Microsoft.Extensions.Logging;
using HeliumEdge.Logging;

namespace HeliumEdge.Services.ATS.Middleware
{
    public class ResponseWrapper
    {
        private readonly RequestDelegate _next;
        private readonly IAsyncLogger<ResponseWrapper> _logger;               

        public ResponseWrapper(IAsyncLoggerFactory loggerFactory, RequestDelegate next)
        {
            _logger = loggerFactory.GetLogger<ResponseWrapper>();
            _next = next;
        }
        public async Task Invoke(HttpContext context)
        {
            //Inject the teant id here...
            //NLog.MappedDiagnosticsLogicalContext.Set("Tenant", "Tenant1");

            var currentBody = context.Response.Body;
            ResponseMetadata responseMetadata = null;
            using (var memoryStream = new MemoryStream())
            {
                context.Response.Body = memoryStream;
                try
                {
                    await _next.Invoke(context);

                    context.Response.Body = currentBody;
                    memoryStream.Seek(0, SeekOrigin.Begin);

                    var readToEnd = new StreamReader(memoryStream).ReadToEnd();
                    var objResult = JsonConvert.DeserializeObject(readToEnd);

                    responseMetadata = new ResponseMetadata()
                    {
                        Version = "1.0",
                        Content = objResult,
                        Timestamp = DateTime.UtcNow,
                        StatusCode = context.Response.StatusCode,
                        Size = context.Response.ContentLength
                    };
                }
                catch (System.Exception ex)
                {
                    _logger.Error(ex.Message, ex);
                    context.Response.ContentType = "application/json";
                    context.Response.Body = currentBody;
                    responseMetadata = ex.HandleExceptionResponse();
                }
                await context.Response.WriteAsync(JsonConvert.SerializeObject(responseMetadata));
            }
        }
    }

    public static class ResponseWrapperExtensions
    {
        public static IApplicationBuilder UseResponseWrapper(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<ResponseWrapper>();
        }
    }
    
}
