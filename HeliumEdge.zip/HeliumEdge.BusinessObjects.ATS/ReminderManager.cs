﻿using HeliumEdge.DataAccess.ATS;
using HeliumEdge.DataMappers.ATS;
using HeliumEdge.DataTransfer.ATS;
using HeliumEdge.Validations;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HeliumEdge.BusinessObjects.ATS
{
    public class ReminderManager
    {
        private readonly ReminderRepository reminderRepository;
        public ReminderManager(ReminderRepository reminderRepository)
        {
            this.reminderRepository = reminderRepository;
        }

        public async Task<IEnumerable<ReminderViewDTO>> GetAllAsync()
        {
            return (await reminderRepository.GetAllAsync().ConfigureAwait(false))?.Select(model => model.ToDTO());
        }

        public async Task<ReminderViewDTO> GetAsync(int id)
        {
            return (await reminderRepository.GetAsync(id).ConfigureAwait(false))?.ToDTO();
        }

        public async Task<bool> CreateAsync(ReminderDTO dto)
        {
            var validator = ValidatorProvider.GetValidatorInstance<ReminderDTO>();
            validator.Validate(dto);

            var model = dto.ToDataObject();
            return await reminderRepository.CreateAsync(model).ConfigureAwait(false);
        }
    }
}
