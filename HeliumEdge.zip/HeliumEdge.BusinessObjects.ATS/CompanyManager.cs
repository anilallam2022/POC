﻿using HeliumEdge.Core;
using HeliumEdge.DataAccess.ATS;
using HeliumEdge.DataMappers.ATS;
using HeliumEdge.DataObjects.ATS;
using HeliumEdge.DataObjects.ATS.ViewModels;
using HeliumEdge.DataTransfer.ATS;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HeliumEdge.Validations;
using HeliumEdge.Exception;
using System.ComponentModel.DataAnnotations;

namespace HeliumEdge.BusinessObjects.ATS
{
    public class CompanyManager
    {
        private readonly CompanyRepository companyRepository;
        private readonly MasterDataRepository masterDataRepository;
        public CompanyManager(CompanyRepository companyRepository, MasterDataRepository masterDataRepository)
        {
            this.companyRepository = companyRepository;
            this.masterDataRepository = masterDataRepository;
        }

        public async Task<ListPageResultDTO> GetAllAsync(ListPageRequestDTO inputDTO)
        {
            var result = await companyRepository.GetAllAsync(new ListPageCriteria { ViewId = inputDTO.ViewId, Entity = inputDTO.GetEntityType(), PageNumber = inputDTO.PageNumber, PageSize = inputDTO.PageSize, SortColumn = inputDTO.SortColumn, SortOrder = inputDTO.SortOrder }).ConfigureAwait(false);
            if (result.TotalRecordCount > 0)
            {
                foreach (var company in result.FieldData)
                {
                    FormatDynamicData(company);
                }
            }
            return new ListPageResultDTO { TotalRecordsCount = result.TotalRecordCount, FieldData = result.FieldData, Header = result.Headers };
        }

        public async Task<dynamic> GetViewListItems()
        {
            return await companyRepository.GetViewListItems().ConfigureAwait(false); ;
        }

        public async Task<CompanyViewDTO> GetViewAsync(int id)
        {
            return (await companyRepository.GetViewById(id).ConfigureAwait(false))?.ToViewDTO();
        }

        public async Task<dynamic> Search(string text)
        {
            return string.IsNullOrWhiteSpace(text) ? (dynamic)new List<dynamic>() : (await companyRepository.Search(text).ConfigureAwait(false));
        }

        public async Task<CompanyDTO> GetAsync(int id)
        {
            return (await companyRepository.GetAsync(id).ConfigureAwait(false))?.ToDTO();
        }

        public async Task<IEnumerable<CompanyDTO>> GetAllByNameAsync(string name)
        {
            return (await companyRepository.GetAllByNameAsync(name).ConfigureAwait(false))?.Select(model => model.ToDTO());
        }
        public async Task<bool> CreateAsync(CompanyDTO dto)
        {
            var validator = ValidatorProvider.GetValidatorInstance<CompanyDTO>();
            validator.Validate(dto);

            var model = dto?.ToDataObject();
            model = await PopulateDefaults(model).ConfigureAwait(false);
            return await companyRepository.CreateAsync(model).ConfigureAwait(false);

        }

        private async Task<CompanyModel> PopulateDefaults(CompanyModel model)
        {
            var defaultStatusId = await masterDataRepository.GetDefaultLookupIdAsync("Company", "Status").ConfigureAwait(false); //TODO. Need to create a constants class to avoid hardcording
            if (defaultStatusId > 0)
            {
                model.Company.StatusId = defaultStatusId;
            }
            return model;
        }

        public async Task<dynamic> GetCompaniesList()
        {
            return await companyRepository.GetCompaniesList().ConfigureAwait(false);
        }


        public async Task<bool> Delete(List<int> Ids)
        {
            return await companyRepository.DeleteAsync(Ids).ConfigureAwait(false);
        }
        private void FormatDynamicData(dynamic company)
        {
            if (company.Email != null && !string.IsNullOrWhiteSpace(company.Email))
            {
                company.Email = ((string)company.Email).Split('|').Select(x =>
                {
                    var emailDetails = x.Split('^');
                    return new
                    {
                        Email = emailDetails[0],
                        Type = emailDetails.Length > 1 ? emailDetails[1] : string.Empty
                    };
                });
            }
            if (company.Location != null && !string.IsNullOrWhiteSpace(company.Location))
            {
                company.Location = ((string)company.Location).Split('|').Select(x =>
                {
                    var addressDetails = x.Split('^');
                    return new
                    {
                        address = addressDetails[0]
                    };
                });
            }
            if (company.Phone != null && !string.IsNullOrWhiteSpace(company.Phone))
            {
                company.Phone = ((string)company.Phone).Split('|').Select(x =>
                {
                    var phoneDetails = x.Split('^');
                    return new
                    {
                        CountryCode = phoneDetails[0],
                        PhoneNumber = phoneDetails.Length > 1 ? phoneDetails[1] : string.Empty,
                        Extension = phoneDetails.Length > 2 ? phoneDetails[2] : string.Empty,
                        Type = phoneDetails.Length > 3 ? phoneDetails[3] : string.Empty,
                    };
                });
            }
            if (company.Contact != null && !string.IsNullOrWhiteSpace(company.Contact))
            {
                company.Contact = ((string)company.Contact).Split('|').Select(x =>
                {
                    var contactDetails = x.Split('^');
                    return new
                    {
                        FirstName = contactDetails[0],
                        LastName = contactDetails[1],
                        Role = contactDetails[2]
                    };
                });
            }
            if (company.CompanyTypes != null && !string.IsNullOrWhiteSpace(company.CompanyTypes))
            {
                company.CompanyTypes = ((string)company.CompanyTypes).Split('|');

            }
        }

        public async Task<decimal?> GetPlacementFee(int Id)
        {
            return await companyRepository.GetPlacementFee(Id).ConfigureAwait(false);
        }
        public async Task<bool> ChangeStatusAsync(EntitiesStatusDTO dto)
        {
            var entitiesToChangeStatus = new EntitiesStatus { EntityIds = dto.EntityIds, NewStatusId = dto.NewStatusId };
            return (await companyRepository.ChangeStatusAsync(entitiesToChangeStatus).ConfigureAwait(false));
        }
    }
}
