﻿using HeliumEdge.DataAccess.ATS;
using HeliumEdge.DataMappers.ATS;
using HeliumEdge.DataObjects.ATS.ViewModels;
using HeliumEdge.DataTransfer.ATS;
using HeliumEdge.Validations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HeliumEdge.BusinessObjects.ATS
{
    public class JobManager
    {
        private readonly JobRepository jobRepository;

        public JobManager(JobRepository jobRepository)
        {
            this.jobRepository = jobRepository;
        }

        public async Task<ListPageResultDTO> GetAllAsync(ListPageRequestDTO inputDTO)
        {
            var result = await jobRepository.GetAllAsync(new ListPageCriteria { ViewId = inputDTO.ViewId, Entity = inputDTO.GetEntityType(), PageNumber = inputDTO.PageNumber, PageSize = inputDTO.PageSize, SortColumn = inputDTO.SortColumn, SortOrder = inputDTO.SortOrder }).ConfigureAwait(false);
            if (result.TotalRecordCount > 0)
            {
                foreach (var job in result.FieldData)
                {
                    FormatDynamicData(job);
                }
            }
            return new ListPageResultDTO { TotalRecordsCount = result.TotalRecordCount, FieldData = result.FieldData, Header = result.Headers };
        }

        public async Task<dynamic> GetViewListItems(int userId)
        {
            return await jobRepository.GetViewListItems(userId).ConfigureAwait(false);
        }
        public async Task<JobDTO> GetAsync(int id)
        {
            return (await jobRepository.GetAsync(id).ConfigureAwait(false))?.ToDTO();
        }

        public async Task<bool> CreateAsync(JobDTO dto)
        {
            var validator = ValidatorProvider.GetValidatorInstance<JobDTO>();
            validator.Validate(dto);

            var model = dto?.ToDataObject();
            return await jobRepository.CreateAsync(model).ConfigureAwait(false);
        }

        public async Task<dynamic> Search(string text)
        {
            return string.IsNullOrWhiteSpace(text) ? (dynamic)new List<dynamic>() : (await jobRepository.Search(text).ConfigureAwait(false));
        }

        private void FormatDynamicData(dynamic job)
        {

            if (job.Location != null && !string.IsNullOrWhiteSpace(job.Location.ToString()))
            {
                job.Location = ((string)job.Location).Split('|').Select(x =>
                {
                    return new
                    {
                        Address = x
                    };
                });
            }
            if (job.Salary != null && !string.IsNullOrWhiteSpace(job.Salary.ToString()))
            {
                var salaryDetails = job.Salary.ToString().Split('|');
                job.Salary = new { From = salaryDetails[0], To = salaryDetails.Length > 1 ? salaryDetails[1] : null, Unit = salaryDetails.Length > 2 ? salaryDetails[2] : null };
            }
            if (job.AssignedRecruiter != null && !string.IsNullOrWhiteSpace(job.AssignedRecruiter.ToString()))
            {
                job.AssignedRecruiter = job.AssignedRecruiter.ToString().Split('|');
            }
        }

        public async Task<bool> Delete(List<int> Ids)
        {
            return await jobRepository.DeleteAsync(Ids).ConfigureAwait(false);
        }

        public async Task<bool> GetDuplicateCheckAsync(string title, int companyId)
        {
            return await jobRepository.GetDuplicateCheckAsync(title, companyId).ConfigureAwait(false);
        }

        public async Task<JobDTO> GetCloneAsync(int jobId)
        {
            return (await jobRepository.GetCloneAsync(jobId).ConfigureAwait(false))?.ToDTO();
        }

        public async Task<bool> Status(ChangeStatusDTO changeStatus)
        {
            if (changeStatus.SelectedIds.Count == 0 || changeStatus.StatusId == 0 || changeStatus.CategoryName == string.Empty)
                return false;
            return await jobRepository.StatusAsync(changeStatus.SelectedIds, changeStatus.StatusId, changeStatus.CategoryName, changeStatus.Reason).ConfigureAwait(false);
        }

        public async Task<dynamic> GetCompanyDetailsById(int companyId)
        {
            return await jobRepository.GetCompanyDetailsById(companyId).ConfigureAwait(false);
        }

        public async Task<JobViewDTO> GetView(int jobId)
        {
            var viewData = await jobRepository.GetView(jobId).ConfigureAwait(false);
            return viewData.ToViewDTO();
        }
    }
}
