﻿using HeliumEdge.DataAccess.ATS;
using System.Linq;
using System.Collections.Generic;
using System.Threading.Tasks;
using HeliumEdge.DataMappers.ATS;
using HeliumEdge.DataTransfer.ATS;
using HeliumEdge.Core;
using HeliumEdge.Validations;

namespace HeliumEdge.BusinessObjects.ATS
{
    public class NoteManager
    {
        private readonly NoteRepository noteRepository;
        private readonly IBlobService blobService;
        public NoteManager(NoteRepository noteRepository,IBlobService blobService)
        {
            this.noteRepository = noteRepository;
            this.blobService = blobService;
        }

        public async Task<IEnumerable<NoteViewDTO>> GetAllAsync()
        {
            return (await noteRepository.GetAllAsync().ConfigureAwait(false))?.Select(note => note.ToDTO());
        }

        public async Task<NoteViewDTO> GetAsync(int id)
        {
            return (await noteRepository.GetAsync(id).ConfigureAwait(false))?.ToDTO();
        }

        public async Task<bool> CreateAsync(NoteDTO dto)
        {
            var validator = ValidatorProvider.GetValidatorInstance<NoteDTO>();
            validator.Validate(dto);

            var note = dto.ToDataObject();
            return await noteRepository.CreateAsync(note).ConfigureAwait(false);
        }

    }
}
