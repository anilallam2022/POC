﻿using HeliumEdge.Common;
using HeliumEdge.DataAccess.ATS;
using HeliumEdge.DataMappers.ATS;
using HeliumEdge.DataObjects.ATS;
using HeliumEdge.DataTransfer.ATS;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace HeliumEdge.BusinessObjects.ATS
{
    public class SecurityManager
    {
        private readonly SecurityRepository securityRepository;
        private readonly RoleRepository roleRepository;

        public SecurityManager(SecurityRepository securityRepository, RoleRepository roleRepository)
        {
            this.securityRepository = securityRepository;
            this.roleRepository = roleRepository;
        }
        public async Task<UserDTO> GetUserAsync(int id)
        {
            return (await securityRepository.GetUserAsync(id).ConfigureAwait(false))?.ToDTO();
        }

        public async Task<List<RolePermissions>> GetUserPermissionsAsync(int id)
        {
            return (await securityRepository.GetUserPermissionsAsync(id));
        }

        public async Task<UserModel> Authenticate(LoginModel login)
        {
            var user = ValidateUserCredentialsAsync(login.Email, login.Password).Result;

            if (null != user)
            {
                var role = await roleRepository.GetRole(user.RoleId);
                return new UserModel { Id = user.Id, FirstName = user.FirstName, LastName = user.LastName, Email = user.Email, Role = role.Name, TenantId = user.TenantId };
            }
            return null;
        }

        public string BuildToken(UserModel user, string userName, string password, string secretKey, string issuer, string audience, double tokenLifeTime)
        {
            var claims = new List<Claim> {
                new Claim("FirstName", user.FirstName),
                new Claim("LastName", user.LastName),
                new Claim("Email", user.Email),
                new Claim("TenantId", user.TenantId.ToString()),
                new Claim("Id", user.Id.ToString()),
                new Claim("Role", user.Role)
               };
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(secretKey));
            var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
            var token = new JwtSecurityToken(issuer, audience, claims, expires: DateTime.Now.AddMinutes(tokenLifeTime), signingCredentials: credentials);
            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        private async Task<User> ValidateUserCredentialsAsync(string email, string password)
        {
            var user = await securityRepository.GetUserByEmailAsync(email).ConfigureAwait(false);
            if (PasswordHasher.VerifyHashedPassword(user.Password, password))
                return user;
            return null;
        }
    }
}
