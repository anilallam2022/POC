﻿using HeliumEdge.Core;
using HeliumEdge.DataAccess.ATS;
using HeliumEdge.DataMappers.ATS;
using HeliumEdge.DataObjects.ATS;
using HeliumEdge.DataObjects.ATS.ViewModels;
using HeliumEdge.DataTransfer.ATS;
using HeliumEdge.Exception;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Threading.Tasks;

namespace HeliumEdge.BusinessObjects.ATS
{
    public class FileStorageManager
    {
        private readonly FileStorageRepository fileStorageRepository;

        public FileStorageManager(FileStorageRepository fileStorageRepository)
        {
            this.fileStorageRepository = fileStorageRepository;
        }

        public async Task<AttachmentDTO> GetAsync(int id)
        {
            AttachmentDTO attachmentDTO = null;
            var attachment = await fileStorageRepository.GetAsync(id).ConfigureAwait(false);
            if(attachment != null)
            {
                attachmentDTO = new AttachmentDTO
                {
                    StorageFileName = attachment.StorageFileName,
                    FileName = attachment.FileName,
                    Type = attachment.Type,
                    FilePath = attachment.FilePath,
                    Id = attachment.Id
                };
                return attachmentDTO;
            }
            throw new BusinessException("Record not found", 404);
        }

    }
}
