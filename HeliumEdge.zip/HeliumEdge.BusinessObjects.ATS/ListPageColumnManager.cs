﻿using HeliumEdge.DataAccess.ATS;
using HeliumEdge.DataTransfer.ATS;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using HeliumEdge.DataMappers.ATS;

namespace HeliumEdge.BusinessObjects.ATS
{
    public class ListPageColumnManager
    {
        private readonly ListPageColumnRepository listPageColumnRepository;
        public ListPageColumnManager(ListPageColumnRepository listPageColumnRepository)
        {
            this.listPageColumnRepository = listPageColumnRepository;
        }

        public async Task<IEnumerable<ListPageColumnDTO>> GetColumnListByEntity(string entity)
        {
            return (await listPageColumnRepository.GetColumnListByEntity(entity).ConfigureAwait(false))?.Select(item=> item.ToDTO());
        }

        public async Task<IEnumerable<ListPageColumnDTO>> GetUserColumnListByEntity(string entity, int userId)
        {
            return (await listPageColumnRepository.GetUserColumnListByEntity(entity, userId).ConfigureAwait(false))?.Select(item => item.ToDTO());
        }
    }
}
