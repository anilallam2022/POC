﻿using HeliumEdge.DataAccess.ATS;
using HeliumEdge.DataMappers.ATS;
using HeliumEdge.DataObjects.ATS.ViewModels;
using HeliumEdge.DataTransfer.ATS;
using HeliumEdge.Validations;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Threading.Tasks;

namespace HeliumEdge.BusinessObjects.ATS
{
    public class CandidateManager
    {
        private readonly CandidateRepository candidateRepository;

        public CandidateManager(CandidateRepository candidateRepository)
        {
            this.candidateRepository = candidateRepository;
        }

        public async Task<ListPageResultDTO> GetAllAsync(ListPageRequestDTO inputDTO)
        {
            var result = await candidateRepository.GetAllAsync(new ListPageCriteria { ViewId = inputDTO.ViewId, Entity = inputDTO.GetEntityType(), PageNumber = inputDTO.PageNumber, PageSize = inputDTO.PageSize, SortColumn = inputDTO.SortColumn, SortOrder = inputDTO.SortOrder })
                                                  .ConfigureAwait(false);
            if (result.TotalRecordCount > 0)
            {
                foreach (var candidate in result.FieldData)
                {
                    FormatDynamicData(candidate);
                }
            }
            return new ListPageResultDTO { TotalRecordsCount = result.TotalRecordCount, FieldData = result.FieldData, Header = result.Headers };
        }

        private void FormatDynamicData(dynamic candidate)
        {
            if (candidate.Location != null && !string.IsNullOrWhiteSpace(candidate.Location.ToString()))
            {
                candidate.Location = ((string)candidate.Location).Split('|').Select(x => {
                    var locationDetails = x.Split('^');
                    return new
                    {
                        Address = locationDetails[0],
                        Type = locationDetails.Length > 1 ? locationDetails[1] : string.Empty
                    };
                });
            }
            if (candidate.Email != null && !string.IsNullOrWhiteSpace(candidate.Email.ToString()))
            {
                candidate.Email = ((string)candidate.Email).Split('|').Select(email =>
                {
                    var emailDetails = email.Split('^');
                    return new { Email = emailDetails[0], Type = emailDetails.Length > 1 ? emailDetails[1] : string.Empty };
                });
            }
            if (candidate.Phone != null && !string.IsNullOrWhiteSpace(candidate.Phone))
            {
                candidate.Phone = ((string)candidate.Phone).Split('|').Select(x => {
                    var phoneDetails = x.Split('^');
                    return new
                    {
                        CountryCode = phoneDetails[0],
                        PhoneNumber = phoneDetails.Length > 1 ? phoneDetails[1] : string.Empty,
                        Extension = phoneDetails.Length > 2 ? phoneDetails[2] : string.Empty,
                        Type = phoneDetails.Length > 3 ? phoneDetails[3] : string.Empty,
                    };
                });
            }
        }

        public async Task<dynamic> GetViewListItems()
        {
            return await candidateRepository.GetViewListItems().ConfigureAwait(false);
        }

        public async Task<dynamic> Search(string text)
        {
            return string.IsNullOrWhiteSpace(text) ? (dynamic)new List<dynamic>() : (await candidateRepository.Search(text).ConfigureAwait(false));
        }

        public async Task<bool> ChangeStatusAsync(EntitiesStatusDTO model)
        {
            var entitiesToChangeStatus = new EntitiesStatus { EntityIds = model.EntityIds, NewStatusId = model.NewStatusId };
            return (await candidateRepository.ChangeStatusAsync(entitiesToChangeStatus).ConfigureAwait(false));
        }

        public async Task<CandidateDTO> GetAsync(int id)
        {
            return (await candidateRepository.GetAsync(id).ConfigureAwait(false))?.ToDTO();
        }

        public async Task<CandidateViewDTO> GetViewAsync(int id)
        {
            return (await candidateRepository.GetViewById(id).ConfigureAwait(false))?.ToViewDTO();
        }

        public async Task<bool> CreateAsync(CandidateDTO dto)
        {
            var validator = ValidatorProvider.GetValidatorInstance<CandidateDTO>();
            validator.Validate(dto);

            var model = dto?.ToDataObject();
            return await candidateRepository.CreateAsync(model).ConfigureAwait(false);
        }

        public async Task<bool> Delete(List<int> Ids)
        {
            return await candidateRepository.DeleteAsync(Ids).ConfigureAwait(false);
        }
    }
}
