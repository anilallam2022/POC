﻿using HeliumEdge.DataAccess.ATS;
using HeliumEdge.DataObjects.ATS;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HeliumEdge.BusinessObjects.ATS
{
    public class RoleManager
    {
        private readonly RoleRepository roleRepository;

        public RoleManager(RoleRepository roleRepository)
        {
            this.roleRepository = roleRepository;
        }

        public Task<IEnumerable<Role>> GetRoles()
        {
            return roleRepository.GetRoles();
        }
    }
}
