﻿using HeliumEdge.DataAccess.ATS;
using System.Threading.Tasks;

namespace HeliumEdge.BusinessObjects.ATS
{
    public class MasterDataManager
    {
        private readonly MasterDataRepository repository;
        public MasterDataManager(MasterDataRepository masterDataRepository)
        {
            this.repository = masterDataRepository;
        }

        public async Task<object> GetLookUpItemsByModule(string moduleName)
        {
            return await repository.GetLookUpItemsByModule(moduleName).ConfigureAwait(false);
        }

        public async Task<dynamic> GetActiveUsers()
        {
            return await repository.GetActiveUsers().ConfigureAwait(false);
        }
    }
}
