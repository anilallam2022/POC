﻿using HeliumEdge.DataAccess.ATS;
using HeliumEdge.DataObjects.ATS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HeliumEdge.DataTransfer.ATS;
using HeliumEdge.DataMappers.ATS;
using HeliumEdge.DataObjects.ATS.ViewModels;
using HeliumEdge.Validations;
using HeliumEdge.Core;

namespace HeliumEdge.BusinessObjects.ATS
{
    public class ContactManager
    {
        private readonly ContactRepository contactRepository;
        public ContactManager(ContactRepository contactRepository)
        {
            this.contactRepository = contactRepository;
        }

        public async Task<ListPageResultDTO> GetAllAsync(ListPageRequestDTO inputDTO)
        {
            var result = await contactRepository.GetAllAsync(new ListPageCriteria { ViewId = inputDTO.ViewId, Entity = inputDTO.GetEntityType(), PageNumber = inputDTO.PageNumber, PageSize = inputDTO.PageSize, SortColumn = inputDTO.SortColumn, SortOrder = inputDTO.SortOrder }).ConfigureAwait(false);
            if (result.TotalRecordCount > 0)
            {
                foreach (var job in result.FieldData)
                {
                    FormatDynamicData(job);
                }
            }
            return new ListPageResultDTO { TotalRecordsCount = result.TotalRecordCount, FieldData = result.FieldData, Header = result.Headers };
        }

        private void FormatDynamicData(dynamic contact)
        {
            if (contact.Location != null && !string.IsNullOrWhiteSpace(contact.Location.ToString()))
            {
                contact.Location = ((string)contact.Location).Split('|').Select(x =>
                {
                    var locationDetails = x.Split('^');
                    return new
                    {
                        Address = locationDetails[0],
                        Type = locationDetails.Length > 1 ? locationDetails[1] : string.Empty
                    };
                });
            }
            if (contact.ContactSources != null && !string.IsNullOrWhiteSpace(contact.ContactSources.ToString()))
            {
                contact.ContactSources = ((string)contact.ContactSources).Split('|');
            }
            if (contact.ContactTypes != null && !string.IsNullOrWhiteSpace(contact.ContactTypes.ToString()))
            {
                contact.ContactTypes = ((string)contact.ContactTypes).Split('|');
            }
            if (contact.Email != null && !string.IsNullOrWhiteSpace(contact.Email.ToString()))
            {
                contact.Email = ((string)contact.Email).Split('|').Select(email =>
                {
                    var emailDetails = email.Split('^');
                    return new { Email = emailDetails[0], Type = emailDetails.Length > 1 ? emailDetails[1] : string.Empty };
                });
            }
            if (contact.Phone != null && !string.IsNullOrWhiteSpace(contact.Phone))
            {
                contact.Phone = ((string)contact.Phone).Split('|').Select(x =>
                {
                    var phoneDetails = x.Split('^');
                    return new
                    {
                        CountryCode = phoneDetails[0],
                        PhoneNumber = phoneDetails.Length > 1 ? phoneDetails[1] : string.Empty,
                        Extension = phoneDetails.Length > 2 ? phoneDetails[2] : string.Empty,
                        Type = phoneDetails.Length > 3 ? phoneDetails[3] : string.Empty,
                    };
                });
            }
        }

        public async Task<dynamic> SearchUnassigned(string text)
        {
            return string.IsNullOrWhiteSpace(text) ? (dynamic)new List<dynamic>() : (await contactRepository.SearchUnassigned(text).ConfigureAwait(false));
        }

        public async Task<ContactDTO> GetAsync(int id)
        {
            return (await contactRepository.GetAsync(id).ConfigureAwait(false))?.ToDTO();
        }

        public async Task<ContactViewDTO> GetViewAsync(int id)
        {
            return (await contactRepository.GetViewById(id).ConfigureAwait(false))?.ToViewDTO();
        }

        public async Task<IEnumerable<ContactDTO>> GetAllByNameAsync(string name)
        {
            return (await contactRepository.GetAllByNameAsync(name).ConfigureAwait(false))?.Select(model => model.ToDTO());
        }

        public async Task<dynamic> Search(string text)
        {
            return string.IsNullOrWhiteSpace(text) ? (dynamic)new List<dynamic>() : (await contactRepository.Search(text).ConfigureAwait(false));
        }

        public async Task<bool> ChangeStatusAsync(EntitiesStatusDTO model)
        {
            var entitiesToChangeStatus = new EntitiesStatus { EntityIds = model.EntityIds, NewStatusId = model.NewStatusId };
            return (await contactRepository.ChangeStatusAsync(entitiesToChangeStatus).ConfigureAwait(false));
        }

        public async Task<dynamic> GetContactList()
        {
            return (await contactRepository.GetContactList().ConfigureAwait(false));
        }

        public async Task<bool> CreateAsync(ContactDTO dto)
        {
            var validator = ValidatorProvider.GetValidatorInstance<ContactDTO>();
            validator.Validate(dto);

            var contact = dto.ToDataObject();
            return await contactRepository.CreateAsync(contact).ConfigureAwait(false);
        }

        public async Task<bool> Delete(List<int> Ids)
        {
            return await contactRepository.DeleteAsync(Ids).ConfigureAwait(false);
        }

        public async Task<dynamic> SearchByCompanyId(int companyId, string text)
        {
            return string.IsNullOrWhiteSpace(text) ? (dynamic)new List<dynamic>() : (await contactRepository.SearchByCompanyId(companyId, text).ConfigureAwait(false));
        }
    }
}
