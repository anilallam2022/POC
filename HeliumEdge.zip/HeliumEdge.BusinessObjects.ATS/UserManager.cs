﻿using HeliumEdge.DataAccess.ATS;
using HeliumEdge.DataMappers.ATS;
using HeliumEdge.DataObjects.ATS;
using HeliumEdge.DataTransfer.ATS;
using System.Collections.Generic;
using System.Threading.Tasks;
using HeliumEdge.Common;

namespace HeliumEdge.BusinessObjects.ATS
{
    public class UserManager
    {
        private readonly UserRepository userRepository;

        public UserManager(UserRepository userRepository)
        {
            this.userRepository = userRepository;
        }

        public async Task<dynamic> Search(string text)
        {
            return string.IsNullOrWhiteSpace(text) ? (dynamic)new List<dynamic>() : (await userRepository.Search(text).ConfigureAwait(false));
        }

        public async Task<int> Register(UserDTO dto)
        {
            User model = dto?.ToDataObject();
            model.Password = PasswordHasher.HashPassword(model.Password);
            return await userRepository.CreateUserAsync(model).ConfigureAwait(false);
        }
    }
}
