﻿using HeliumEdge.DataAccess.ATS;
using HeliumEdge.DataObjects.ATS;
using HeliumEdge.DataTransfer.ATS;
using System.Collections.Generic;
using System.Threading.Tasks;
using HeliumEdge.DataMappers.ATS;
using System.Linq;
using HeliumEdge.Validations;

namespace HeliumEdge.BusinessObjects.ATS
{
    public class EventManager
    {
        private readonly EventRepository eventRepository;

        public EventManager(EventRepository eventRepository)
        {
            this.eventRepository = eventRepository;
        }

        public async Task<IEnumerable<EventViewDTO>> GetAllAsync()
        {
            return (await eventRepository.GetAllAsync().ConfigureAwait(false))?.Select(model => model.ToDTO());
        }

        public async Task<EventViewDTO> GetAsync(int id)
        {
            return (await eventRepository.GetAsync(id).ConfigureAwait(false))?.ToDTO();
        }

        public async Task<bool> CreateAsync(EventDTO dto)
        {
            var validator = ValidatorProvider.GetValidatorInstance<EventDTO>();
            validator.Validate(dto);

            var model = dto.ToDataObject();
            return await eventRepository.CreateAsync(model).ConfigureAwait(false);
        }
    }
}
