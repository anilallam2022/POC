﻿using HeliumEdge.DataAccess.ATS;
using HeliumEdge.DataMappers.ATS;
using HeliumEdge.DataTransfer.ATS;
using System.Linq;
using System.Collections.Generic;
using System.Threading.Tasks;
using HeliumEdge.Core;
using HeliumEdge.Validations;

namespace HeliumEdge.BusinessObjects.ATS
{
    public class TaskManager
    {
        private readonly TaskRepository taskRepository;
        private readonly IBlobService blobService;
        public TaskManager(TaskRepository taskRepository,IBlobService blobService)
        {
            this.taskRepository = taskRepository;
            this.blobService = blobService;
        }

        public async Task<IEnumerable<TaskViewDTO>> GetAllAsync()
        {
            return (await taskRepository.GetAllAsync().ConfigureAwait(false))?.Select(task => task.ToDTO());
        }

        public async Task<TaskViewDTO> GetAsync(int id)
        {
            return (await taskRepository.GetAsync(id).ConfigureAwait(false))?.ToDTO();
        }

        public async Task<bool> CreateAsync(TaskDTO dto)
        {
            var validator = ValidatorProvider.GetValidatorInstance<TaskDTO>();
            validator.Validate(dto);

            var task = dto.ToDataObject();
            return await taskRepository.CreateAsync(task).ConfigureAwait(false);
        }

    }
}
